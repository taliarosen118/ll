import { useState } from "react";
import { Button } from "@/components/ui/button";

type Form = {
  studentName: string;
  disabilities: string[];
  grade: string;
  mathGrade: string;
  readingGrade: string;
  focus: number;
  prefersAudio: boolean;
  prefersVisual: boolean;
  needsLargeFont: boolean;
};

const defaultForm: Form = {
  studentName: "",
  disabilities: [],
  grade: "",
  mathGrade: "",
  readingGrade: "",
  focus: 3,
  prefersAudio: true,
  prefersVisual: true,
  needsLargeFont: false,
};

function mathLevelFromGrade(g: number) {
  if (g <= 1) return "emergent";
  if (g <= 3) return "basic";
  if (g <= 6) return "intermediate";
  return "advanced";
}

function readingLevelFromGrade(g: number) {
  if (g <= 1) return "emergent";
  if (g <= 3) return "basic";
  if (g <= 6) return "intermediate";
  return "proficient";
}

export default function PlacementQuiz({ onResult }: { onResult?: (r: any) => void }) {
  const [form, setForm] = useState<Form>(defaultForm);
  const [result, setResult] = useState<string | null>(null);
  const [plan, setPlan] = useState<string | null>(null);

  function toggleDisability(name: string) {
    setForm((f) => {
      const has = f.disabilities.includes(name);
      return { ...f, disabilities: has ? f.disabilities.filter((d) => d !== name) : [...f.disabilities, name] };
    });
  }

  function scorePlacement(values: Form) {
    // initialize scores with grade-based bias
    let f = 0; // Foundations
    let s = 0; // Skills
    let c = 0; // Career

    const mg = parseInt(values.mathGrade || values.grade || "0", 10);
    const rg = parseInt(values.readingGrade || values.grade || "0", 10);

    const mLevel = mathLevelFromGrade(isNaN(mg) ? 0 : mg);
    const rLevel = readingLevelFromGrade(isNaN(rg) ? 0 : rg);

    const g = parseInt(values.grade || "0", 10);
    if (!isNaN(g)) {
      if (g <= 2) f += 3;
      else if (g <= 6) s += 3;
      else c += 3;
    }

    // reading influence
    const rScoreMap: Record<string, number> = { emergent: 3, basic: 2, intermediate: 1, proficient: 0 };
    const rScore = rScoreMap[rLevel] ?? 2;
    // more weight towards foundations when reading is low
    f += rScore;
    // if proficient, boost career
    if (rLevel === "proficient") c += 2;
    if (rLevel === "intermediate") s += 1;

    // math influence
    const mScoreMap: Record<string, number> = { emergent: 3, basic: 2, intermediate: 1, advanced: 0 };
    const mScore = mScoreMap[mLevel] ?? 2;
    f += mScore;
    if (mLevel === "advanced") c += 2;
    if (mLevel === "intermediate") s += 1;

    // focus: lower attention -> foundations; high attention -> career
    if (values.focus <= 2) { f += 2; }
    else if (values.focus === 3) { s += 2; }
    else { c += 2; }

    // disabilities: certain flags
    if (values.disabilities.includes("Down syndrome")) f += 2;
    if (values.disabilities.includes("Dyslexia")) f += 1;
    if (values.disabilities.includes("ADHD")) s += 1;
    if (values.disabilities.includes("Autism (high-functioning)")) s += 1;

    // preferences and supports
    if (values.prefersAudio) s += 1;
    if (values.prefersVisual) f += 1;
    if (values.needsLargeFont) f += 2;

    // normalize and choose
    const placements = [
      { name: "Foundations", score: f },
      { name: "Skills Lab", score: s },
      { name: "Career Pathways", score: c },
    ];

    placements.sort((a, b) => b.score - a.score);

    // tie-breaker: prefer Skills Lab for mixed profiles
    if (placements[0].score === placements[1].score) {
      const names = [placements[0].name, placements[1].name];
      if (names.includes("Skills Lab")) placements[0].name = "Skills Lab";
    }

    const chosen = placements[0].name;

    // Build tailored plan label depending on chosen placement
    const supports: string[] = [];
    if (values.needsLargeFont || values.disabilities.includes("Dyslexia")) supports.push("large font");
    if (values.prefersAudio) supports.push("audio");
    if (values.prefersVisual) supports.push("visual supports");
    if (values.focus <= 2) supports.push("short sessions");

    const placementDescriptor =
      chosen === "Foundations"
        ? `${mLevel} foundation math, ${rLevel} foundation reading`
        : chosen === "Skills Lab"
        ? `${mLevel} skills lab math, ${rLevel} guided reading`
        : `${mLevel} career math, ${rLevel} workplace literacy`;

    const planLabel = `${supports.length ? supports.join(", ") + ", " : ""}${placementDescriptor}`;

    return { placement: chosen, mLevel, rLevel, planLabel };
  }

  function handleSubmit(e?: any) {
    if (e && e.preventDefault) e.preventDefault();
    if (!form.studentName) {
      alert("Please enter the student's name.");
      return;
    }
    const { placement, mLevel, rLevel, planLabel } = scorePlacement(form);
    const payload = { placement, planLabel, mLevel, rLevel, form, studentName: form.studentName, date: new Date().toISOString() };
    try {
      localStorage.setItem("ll_last_quiz", JSON.stringify(payload));
      const listRaw = localStorage.getItem("ll_quiz_results");
      const list = listRaw ? JSON.parse(listRaw) : [];
      list.push(payload);
      localStorage.setItem("ll_quiz_results", JSON.stringify(list));
    } catch {}
    setResult(placement);
    setPlan(planLabel);
    if (onResult) onResult(payload);
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-2xl rounded-xl border bg-card p-6">
      <h2 className="text-2xl font-bold">Placement Quiz</h2>
      <p className="mt-2 text-sm text-muted-foreground">Answer a few quick questions to find the best starting program.</p>

      <label className="mt-4 flex flex-col">
        <span className="font-semibold">Student name</span>
        <input type="text" value={form.studentName} onChange={(e) => setForm((f) => ({ ...f, studentName: e.target.value }))} className="mt-1 rounded-md border px-3 py-2" placeholder="Full name" />
      </label>

      <fieldset className="mt-4">
        <legend className="font-semibold">Disabilities / support needs</legend>
        <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {[
            "Autism (high-functioning)",
            "ADHD",
            "Down syndrome",
            "Dyslexia",
            "Visual impairment",
            "Hearing impairment",
            "Other",
          ].map((d) => (
            <label key={d} className="inline-flex items-center gap-2 rounded-md border px-2 py-1">
              <input
                type="checkbox"
                checked={form.disabilities.includes(d)}
                onChange={() => toggleDisability(d)}
                aria-label={d}
              />
              <span className="text-sm">{d}</span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <label className="flex flex-col">
          <span className="font-semibold">Current school grade</span>
          <input
            type="number"
            min={0}
            max={12}
            placeholder="e.g. 3"
            value={form.grade}
            onChange={(e) => setForm((f) => ({ ...f, grade: e.target.value }))}
            className="mt-1 rounded-md border px-3 py-2"
            aria-label="Grade"
          />
        </label>

        <label className="flex flex-col">
          <span className="font-semibold">Math grade level</span>
          <input type="number" min={0} max={12} value={form.mathGrade} onChange={(e) => setForm((f) => ({ ...f, mathGrade: e.target.value }))} className="mt-1 rounded-md border px-3 py-2" placeholder="e.g. 2" />
        </label>

        <label className="flex flex-col">
          <span className="font-semibold">Reading grade level</span>
          <input type="number" min={0} max={12} value={form.readingGrade} onChange={(e) => setForm((f) => ({ ...f, readingGrade: e.target.value }))} className="mt-1 rounded-md border px-3 py-2" placeholder="e.g. 1" />
        </label>

        <label className="flex flex-col">
          <span className="font-semibold">Focus / attention (1 = low, 5 = high)</span>
          <input
            type="range"
            min={1}
            max={5}
            value={form.focus}
            onChange={(e) => setForm((f) => ({ ...f, focus: parseInt(e.target.value, 10) }))}
            className="mt-3"
            aria-label="Focus level"
          />
        </label>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.prefersAudio} onChange={(e) => setForm((f) => ({ ...f, prefersAudio: e.target.checked }))} />
          <span className="text-sm">Prefers audio-first content</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.prefersVisual} onChange={(e) => setForm((f) => ({ ...f, prefersVisual: e.target.checked }))} />
          <span className="text-sm">Prefers visual supports (pictures, icons)</span>
        </label>
        <label className="inline-flex items-center gap-2">
          <input type="checkbox" checked={form.needsLargeFont} onChange={(e) => setForm((f) => ({ ...f, needsLargeFont: e.target.checked }))} />
          <span className="text-sm">Needs large font</span>
        </label>
      </div>

      <div className="mt-6 flex items-center gap-3">
        <Button type="submit" onClick={handleSubmit}>Find my placement</Button>
        <Button variant="outline" onClick={() => { setForm(defaultForm); setResult(null); setPlan(null); }}>Reset</Button>
      </div>

      {result && (
        <div className="mt-4 rounded-md border bg-background p-3">
          <p className="font-semibold">Suggested placement: {result}</p>
          <p className="text-sm mt-1">Personalized plan: {plan}</p>
          <p className="text-sm text-muted-foreground mt-1">Saved to Admin tab for review.</p>
        </div>
      )}
    </form>
  );
}

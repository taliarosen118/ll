import { Button } from "@/components/ui/button";
import { QuizResult } from "./Quiz";

interface QuizResultsProps {
  result: QuizResult;
  onRetake?: () => void;
  onClose?: () => void;
}

export default function QuizResults({ result, onRetake, onClose }: QuizResultsProps) {
  const scoreColor = result.passed ? "text-green-600" : "text-red-600";
  const scoreBackground = result.passed ? "bg-green-50" : "bg-red-50";

  const weakTopics = Object.entries(result.topicScores)
    .filter(([_, scores]) => scores.correct < scores.total)
    .sort((a, b) => (a[1].correct / a[1].total) - (b[1].correct / b[1].total));

  const strongTopics = Object.entries(result.topicScores)
    .filter(([_, scores]) => scores.correct === scores.total)
    .map(([topic]) => topic);

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Score Card */}
      <div className={`rounded-lg p-8 text-center ${scoreBackground}`}>
        <p className="text-sm font-medium text-muted-foreground mb-2">Your Score</p>
        <p className={`text-5xl font-bold ${scoreColor}`}>{result.score}%</p>
        <p className="mt-3 text-base">
          {result.correctAnswers} out of {result.totalQuestions} correct
        </p>
        <p className={`mt-2 text-sm font-medium ${result.passed ? "text-green-700" : "text-red-700"}`}>
          {result.passed ? "✓ You passed!" : "✗ Not quite there yet"}
        </p>
        {!result.passed && (
          <p className="mt-2 text-sm text-muted-foreground">
            Passing score: {result.passingScore}%
          </p>
        )}
      </div>

      {/* Topics Overview */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Topics Breakdown</h3>
        <div className="space-y-3">
          {Object.entries(result.topicScores).map(([topic, scores]) => {
            const topicScore = Math.round((scores.correct / scores.total) * 100);
            const isStrong = scores.correct === scores.total;
            const isWeak = scores.correct < scores.total;

            return (
              <div key={topic} className="rounded-lg border p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">{topic}</h4>
                    {isStrong && <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Strong</span>}
                    {isWeak && <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Review needed</span>}
                  </div>
                  <span className="text-sm font-semibold">{scores.correct}/{scores.total}</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all ${isStrong ? "bg-green-500" : isWeak ? "bg-yellow-500" : "bg-blue-500"}`}
                    style={{ width: `${topicScore}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Areas of Strength */}
      {strongTopics.length > 0 && (
        <div className="rounded-lg border bg-green-50 p-4">
          <h3 className="font-semibold text-green-900 mb-2">✓ You're doing great in:</h3>
          <ul className="space-y-1">
            {strongTopics.map((topic) => (
              <li key={topic} className="text-sm text-green-800">• {topic}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Topics for Review */}
      {weakTopics.length > 0 && (
        <div className="rounded-lg border bg-yellow-50 p-4">
          <h3 className="font-semibold text-yellow-900 mb-2">📚 Topics to review:</h3>
          <ul className="space-y-2">
            {weakTopics.map(([topic, scores]) => (
              <li key={topic} className="text-sm">
                <span className="text-yellow-800">{topic}</span>
                <span className="text-muted-foreground ml-2">
                  ({scores.correct}/{scores.total} correct)
                </span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-yellow-700 mt-3">
            Consider reviewing these topics in the lessons before retaking the quiz.
          </p>
        </div>
      )}

      {/* Feedback */}
      <div className="rounded-lg border bg-secondary p-4">
        <h3 className="font-semibold mb-2">📝 Feedback</h3>
        <p className="text-sm text-muted-foreground">
          {result.passed
            ? "Excellent work! You've demonstrated a solid understanding of this material. Keep practicing to maintain your skills."
            : "Good effort! Review the topics where you had difficulty, then come back to strengthen your understanding. Every attempt helps you learn!"}
        </p>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between gap-3 pt-4">
        {onClose && (
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        )}
        <div className="flex-1" />
        {onRetake && (
          <Button onClick={onRetake}>
            Retake Quiz
          </Button>
        )}
      </div>
    </div>
  );
}

import { Navigate, useLocation } from "react-router-dom";
import { getStudent } from "@/lib/progress";

export default function RequireStudent({ children }: { children: React.ReactNode }) {
  const loc = useLocation();
  const s = getStudent();
  if (!s) {
    const to = `/login?from=${encodeURIComponent(loc.pathname + loc.search)}`;
    return <Navigate to={to} replace />;
  }
  return <>{children}</>;
}

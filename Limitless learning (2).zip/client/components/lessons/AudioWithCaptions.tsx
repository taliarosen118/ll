import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { logEvent } from "@/lib/progress";

function splitIntoSentences(text: string) {
  const parts = text
    .replace(/\s+/g, " ")
    .split(/([.!?]+)\s+/)
    .reduce<string[]>((acc, cur, i, arr) => {
      if (i % 2 === 0) {
        const nextPunct = arr[i + 1] ?? "";
        const s = (cur + (nextPunct || "")).trim();
        if (s) acc.push(s);
      }
      return acc;
    }, []);
  return parts.length ? parts : [text];
}

export default function AudioWithCaptions({ title, paragraphs }: { title: string; paragraphs: string[] }) {
  const [rate, setRate] = useState(1);
  const [speaking, setSpeaking] = useState(false);
  const [currentSentence, setCurrentSentence] = useState(0);
  const [showCaptions, setShowCaptions] = useState(true);
  const [supported, setSupported] = useState<boolean>(false);
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null);
  const joined = useMemo(() => paragraphs.join(" \n"), [paragraphs]);
  const sentences = useMemo(() => splitIntoSentences(joined), [joined]);

  useEffect(() => {
    setSupported(!!window.speechSynthesis && "SpeechSynthesisUtterance" in window);
    return () => {
      window.speechSynthesis?.cancel();
    };
  }, []);

  function speak() {
    if (!supported) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(joined);
    u.rate = rate;
    u.onstart = () => { setSpeaking(true); logEvent("audio_start", { title }); };
    u.onend = () => { setSpeaking(false); logEvent("audio_end", { title }); };
    u.onerror = () => { setSpeaking(false); };
    // boundary event to track sentence index
    u.onboundary = (e: any) => {
      if (typeof e.charIndex === "number") {
        const idx = e.charIndex as number;
        // map char index to sentence index
        let total = 0;
        for (let i = 0; i < sentences.length; i++) {
          total += sentences[i].length + 1; // include space
          if (idx < total) { setCurrentSentence(i); break; }
        }
      }
    };
    utterRef.current = u;
    window.speechSynthesis.speak(u);
  }

  function stop() {
    window.speechSynthesis.cancel();
    setSpeaking(false);
    logEvent("audio_stop", { title });
  }

  function downloadTranscript() {
    const blob = new Blob([`Title: ${title}\n\n${paragraphs.join("\n\n")}`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${title.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-transcript.txt`;
    a.click(); URL.revokeObjectURL(url);
  }

  return (
    <section aria-labelledby="audio-lesson-heading" className="rounded-xl border bg-card p-4">
      <div className="flex items-center justify-between gap-2">
        <h2 id="audio-lesson-heading" className="text-xl font-semibold">Audio Lesson</h2>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-sm">
            <span>Rate</span>
            <input
              type="range"
              min={0.75}
              max={1.5}
              step={0.25}
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              aria-label="Speech rate"
            />
          </label>
          <Button size="sm" variant="outline" onClick={() => setShowCaptions((v) => !v)} aria-pressed={showCaptions} aria-label="Toggle captions">CC</Button>
          <Button size="sm" variant="secondary" onClick={downloadTranscript}>Download transcript</Button>
          {speaking ? (
            <Button size="sm" onClick={stop} className="bg-brand-600 hover:bg-brand-700">Stop</Button>
          ) : (
            <Button size="sm" onClick={speak} className="bg-brand-600 hover:bg-brand-700" disabled={!supported}>Play</Button>
          )}
        </div>
      </div>

      {showCaptions && (
        <div className="mt-3 max-h-60 overflow-auto rounded-md border bg-background p-3" aria-live="polite">
          {sentences.map((s, i) => (
            <p key={i} className={i === currentSentence ? "bg-brand-50 dark:bg-brand-900/30 rounded px-1" : undefined}>{s}</p>
          ))}
        </div>
      )}

      {!supported && (
        <p className="mt-2 text-sm text-muted-foreground">Text-to-speech not supported in this browser. Captions and transcript download still available.</p>
      )}
    </section>
  );
}

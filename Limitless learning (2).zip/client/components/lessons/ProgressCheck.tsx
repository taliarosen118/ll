import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { addProgressCheck } from "@/lib/moduleProgress";
import { logEvent } from "@/lib/progress";

export default function ProgressCheck({ program, moduleSlug, lessons }: { program: string; moduleSlug: string; lessons: string[] }) {
  const items = useMemo(() => lessons.slice(0, 4).map((l, i) => ({ q: `Which statement matches: "${l}"?`, a: i % 2 === 0 ? "True" : "False" })), [lessons]);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [done, setDone] = useState(false);
  const [score, setScore] = useState(0);

  function submit() {
    const s = items.reduce((acc, it, i) => acc + (answers[i] === it.a ? 1 : 0), 0);
    setScore(s);
    setDone(true);
    addProgressCheck(program, moduleSlug, lessons.length, s);
    logEvent("progress_check_complete", { program, module: moduleSlug, score: s });
  }

  if (done) {
    return (
      <div className="rounded-md border bg-card p-4">
        <p className="font-semibold">Progress Check Complete</p>
        <p className="text-sm text-muted-foreground">Score: {score}/{items.length}</p>
      </div>
    );
  }

  return (
    <div className="rounded-md border bg-card p-4">
      <p className="font-semibold">Progress Check</p>
      <ol className="ml-5 mt-2 list-decimal space-y-2 text-sm">
        {items.map((it, i) => (
          <li key={i}>
            <p>{it.q}</p>
            <div className="mt-1 flex gap-2">
              {(["True","False"]).map(opt => (
                <label key={opt} className="inline-flex items-center gap-1 text-xs">
                  <input type="radio" name={`q${i}`} value={opt} onChange={(e) => setAnswers(a => ({ ...a, [i]: e.target.value }))} /> {opt}
                </label>
              ))}
            </div>
          </li>
        ))}
      </ol>
      <div className="mt-3">
        <Button size="sm" onClick={submit}>Submit</Button>
      </div>
    </div>
  );
}

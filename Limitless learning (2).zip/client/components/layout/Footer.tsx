export default function Footer() {
  return (
    <footer className="border-t bg-background" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">Footer</h2>
      <div className="container mx-auto px-4 py-10 grid gap-8 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-brand-600 text-white font-bold">LL</span>
            <span className="text-lg font-bold">Limitless Learning</span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground max-w-sm">
            Accessible, inclusive education for every learner. Built with care and WCAG AA in mind.
          </p>
        </div>
        <nav className="grid grid-cols-2 gap-6 text-sm" aria-label="Footer">
          <div className="space-y-2">
            <p className="font-semibold">Explore</p>
            <a href="#features" className="hover:text-primary">Features</a>
            <a href="#programs" className="hover:text-primary">Programs</a>
            <a href="#accessibility" className="hover:text-primary">Accessibility</a>
          </div>
          <div className="space-y-2">
            <p className="font-semibold">Company</p>
            <a href="#about" className="hover:text-primary">About</a>
            <a href="#contact" className="hover:text-primary">Contact</a>
            <a href="#" className="hover:text-primary">Privacy</a>
          </div>
        </nav>
        <div className="text-sm text-muted-foreground">
          <p>
            Contact: <a className="underline underline-offset-2 hover:text-primary" href="mailto:hello@limitlesslearning.app">hello@limitlesslearning.app</a>
          </p>
          <p className="mt-2">© {new Date().getFullYear()} Limitless Learning. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

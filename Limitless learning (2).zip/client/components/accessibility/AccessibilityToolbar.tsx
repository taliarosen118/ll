import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Moon, Sun, Type, Contrast, Book, Ruler, Target, Palette, Clock, EyeOff } from "lucide-react";
import ReadingRuler from "@/components/accessibility/ReadingRuler";
import FocusTimer from "@/components/accessibility/FocusTimer";

const storage = {
  get(key: string) {
    try { return localStorage.getItem(key); } catch { return null; }
  },
  set(key: string, value: string) {
    try { localStorage.setItem(key, value); } catch {}
  },
};

export default function AccessibilityToolbar() {
  const [dark, setDark] = useState(false);
  const [hc, setHc] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [dyslexia, setDyslexia] = useState(false);
  const [ruler, setRuler] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [calm, setCalm] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [relaxed, setRelaxed] = useState(false);
  const [showTimer, setShowTimer] = useState(false);

  useEffect(() => {
    const html = document.documentElement;
    const sDark = storage.get("ll_theme");
    const sHc = storage.get("ll_hc");
    const sText = storage.get("ll_text_lg");
    const sDys = storage.get("ll_dyslexia");
    const sRuler = storage.get("ll_ruler");
    const sReduce = storage.get("ll_reduce_motion");
    const sCalm = storage.get("ll_calm");
    const sFocus = storage.get("ll_focus_mode");
    const sRelaxed = storage.get("ll_relaxed");
    const sTimer = storage.get("ll_timer");

    const nextDark = sDark === "dark" || (sDark === null && html.classList.contains("dark"));
    const nextHc = sHc === "1";
    const nextText = sText === "1";
    const nextDys = sDys === "1";
    const nextRuler = sRuler === "1";
    const nextReduce = sReduce === "1";
    const nextCalm = sCalm === "1";
    const nextFocus = sFocus === "1";
    const nextRelaxed = sRelaxed === "1";
    const nextTimer = sTimer === "1";

    setDark(nextDark);
    setHc(nextHc);
    setLargeText(nextText);
    setDyslexia(nextDys);
    setRuler(nextRuler);
    setReduceMotion(nextReduce);
    setCalm(nextCalm);
    setFocusMode(nextFocus);
    setRelaxed(nextRelaxed);
    setShowTimer(nextTimer);

    apply({ dark: nextDark, hc: nextHc, largeText: nextText, dyslexia: nextDys, ruler: nextRuler, reduceMotion: nextReduce, calm: nextCalm, focus: nextFocus, relaxed: nextRelaxed });
  }, []);

  function apply(state: { dark?: boolean; hc?: boolean; largeText?: boolean; dyslexia?: boolean; ruler?: boolean; reduceMotion?: boolean; calm?: boolean; focus?: boolean; relaxed?: boolean }) {
    const html = document.documentElement;
    if (state.dark !== undefined) {
      html.classList.toggle("dark", state.dark);
      storage.set("ll_theme", state.dark ? "dark" : "light");
    }
    if (state.hc !== undefined) {
      html.classList.toggle("hc", state.hc);
      storage.set("ll_hc", state.hc ? "1" : "0");
    }
    if (state.largeText !== undefined) {
      html.classList.toggle("fs-112", state.largeText);
      storage.set("ll_text_lg", state.largeText ? "1" : "0");
    }
    if (state.dyslexia !== undefined) {
      html.classList.toggle("dyslexia-mode", state.dyslexia);
      storage.set("ll_dyslexia", state.dyslexia ? "1" : "0");
    }
    if (state.reduceMotion !== undefined) {
      html.classList.toggle("reduce-motion", state.reduceMotion);
      storage.set("ll_reduce_motion", state.reduceMotion ? "1" : "0");
    }
    if (state.calm !== undefined) {
      html.classList.toggle("calm", state.calm);
      storage.set("ll_calm", state.calm ? "1" : "0");
    }
    if (state.focus !== undefined) {
      html.classList.toggle("focus-mode", state.focus);
      storage.set("ll_focus_mode", state.focus ? "1" : "0");
    }
    if (state.relaxed !== undefined) {
      html.classList.toggle("relaxed", state.relaxed);
      storage.set("ll_relaxed", state.relaxed ? "1" : "0");
    }
  }

  return (
    <aside className="fixed bottom-4 right-4 z-[60]">
      <div className="rounded-xl border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-lg p-3">
        <div className="flex items-center gap-3" aria-label="Accessibility toolbar">
          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", dark ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { setDark(!dark); apply({ dark: !dark }); }}
            aria-pressed={dark}
            aria-label={dark ? "Disable dark mode" : "Enable dark mode"}
          >
            {dark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", hc ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { setHc(!hc); apply({ hc: !hc }); }}
            aria-pressed={hc}
            aria-label={hc ? "Disable high contrast" : "Enable high contrast"}
          >
            <Contrast className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", largeText ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { setLargeText(!largeText); apply({ largeText: !largeText }); }}
            aria-pressed={largeText}
            aria-label={largeText ? "Reduce text size" : "Increase text size"}
          >
            <Type className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", dyslexia ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { setDyslexia(!dyslexia); apply({ dyslexia: !dyslexia }); }}
            aria-pressed={dyslexia}
            aria-label={dyslexia ? "Disable dyslexia-friendly font" : "Enable dyslexia-friendly font"}
          >
            <Book className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", ruler ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !ruler; setRuler(next); storage.set("ll_ruler", next ? "1" : "0"); }}
            aria-pressed={ruler}
            aria-label={ruler ? "Disable reading ruler" : "Enable reading ruler"}
          >
            <Ruler className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", reduceMotion ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !reduceMotion; setReduceMotion(next); apply({ reduceMotion: next }); }}
            aria-pressed={reduceMotion}
            aria-label={reduceMotion ? "Disable reduce motion" : "Enable reduce motion"}
          >
            <EyeOff className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", calm ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !calm; setCalm(next); apply({ calm: next }); }}
            aria-pressed={calm}
            aria-label={calm ? "Disable calm colors" : "Enable calm colors"}
          >
            <Palette className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", focusMode ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !focusMode; setFocusMode(next); apply({ focus: next }); }}
            aria-pressed={focusMode}
            aria-label={focusMode ? "Disable focus mode" : "Enable focus mode"}
          >
            <Target className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", relaxed ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !relaxed; setRelaxed(next); apply({ relaxed: next }); }}
            aria-pressed={relaxed}
            aria-label={relaxed ? "Disable relaxed spacing" : "Enable relaxed spacing"}
          >
            <Type className="h-4 w-4" />
          </button>

          <button
            className={cn("inline-flex h-9 w-9 items-center justify-center rounded-md border", showTimer ? "bg-primary text-primary-foreground" : "bg-background")}
            onClick={() => { const next = !showTimer; setShowTimer(next); storage.set("ll_timer", next ? "1" : "0"); }}
            aria-pressed={showTimer}
            aria-label={showTimer ? "Hide focus timer" : "Show focus timer"}
          >
            <Clock className="h-4 w-4" />
          </button>
        </div>
      </div>
      {ruler && <ReadingRuler />}
      {showTimer && <FocusTimer />}
    </aside>
  );
}

import { getStudent } from "@/lib/progress";

export type PracticeProgressWeek = { items: { attempts: number; correct: number }[] };

export type ModuleProgress = {
  studentId: string;
  program: string;
  module: string;
  completedLessons: number[]; // indices
  progressChecks: { atLessonCount: number; score?: number; date: string }[];
  practice?: { band: string; weeks: PracticeProgressWeek[] };
  quizResults?: {
    quizSlug: string;
    score: number;
    passed: boolean;
    timestamp: string;
    answers: Record<string, string | string[]>;
    topicScores: Record<string, { correct: number; total: number }>;
  };
};

const KEY = "ll_module_progress";

function loadAll(): ModuleProgress[] {
  try { const raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}

function saveAll(list: ModuleProgress[]) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch {}
}

export function getModuleProgress(program: string, moduleSlug: string): ModuleProgress | null {
  const s = getStudent();
  if (!s) return null;
  const all = loadAll();
  return all.find(p => p.studentId === s.id && p.program === program && p.module === moduleSlug) || null;
}

export function ensureModuleProgress(program: string, moduleSlug: string): ModuleProgress | null {
  const s = getStudent();
  if (!s) return null;
  const all = loadAll();
  let rec = all.find(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (!rec) {
    rec = { studentId: s.id, program, module: moduleSlug, completedLessons: [], progressChecks: [] };
    all.push(rec);
    saveAll(all);
  }
  return rec;
}

export function toggleLesson(program: string, moduleSlug: string, index: number) {
  const s = getStudent(); if (!s) return;
  const all = loadAll();
  const rec = ensureModuleProgress(program, moduleSlug);
  if (!rec) return;
  const has = rec.completedLessons.includes(index);
  rec.completedLessons = has ? rec.completedLessons.filter(i => i !== index) : [...rec.completedLessons, index];
  const i = all.findIndex(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (i >= 0) { all[i] = rec; saveAll(all); }
}

export function addProgressCheck(program: string, moduleSlug: string, atLessonCount: number, score?: number) {
  const s = getStudent(); if (!s) return;
  const all = loadAll();
  const rec = ensureModuleProgress(program, moduleSlug);
  if (!rec) return;
  rec.progressChecks.push({ atLessonCount, score, date: new Date().toISOString() });
  const i = all.findIndex(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (i >= 0) { all[i] = rec; saveAll(all); }
}

export function recommendProgressCheck(totalLessons: number, completedCount: number, checksCount: number) {
  if (totalLessons <= 0) return false;
  const third = Math.ceil(totalLessons / 3);
  if (completedCount >= third && checksCount === 0) return true;
  if (completedCount >= third * 2 && checksCount <= 1) return true;
  if (completedCount > 0 && (completedCount % 3 === 0 || completedCount % 4 === 0)) return true;
  return false;
}

export function ensurePractice(
  program: string,
  moduleSlug: string,
  band: string,
  itemsPerWeek: number[]
): PracticeProgressWeek[] | null {
  const s = getStudent(); if (!s) return null;
  const all = loadAll();
  const rec = ensureModuleProgress(program, moduleSlug);
  if (!rec) return null;
  if (!rec.practice || rec.practice.band !== band) {
    rec.practice = { band, weeks: [] };
  }
  // Ensure weeks count and items count per week
  rec.practice.weeks = itemsPerWeek.map((count, wi) => {
    const existing = rec!.practice!.weeks[wi] || { items: [] };
    const items = Array.from({ length: count }, (_, idx) => existing.items[idx] || { attempts: 0, correct: 0 });
    return { items };
  });
  const i = all.findIndex(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (i >= 0) { all[i] = rec; saveAll(all); }
  return rec.practice.weeks;
}

export function recordPracticeAttempt(
  program: string,
  moduleSlug: string,
  band: string,
  weekIndex: number,
  itemIndex: number,
  correct: boolean
) {
  const s = getStudent(); if (!s) return;
  const all = loadAll();
  const rec = ensureModuleProgress(program, moduleSlug);
  if (!rec) return;
  if (!rec.practice || rec.practice.band !== band) return; // ensurePractice first
  const wk = rec.practice.weeks[weekIndex];
  if (!wk) return;
  const it = wk.items[itemIndex];
  if (!it) return;
  it.attempts += 1;
  if (correct) it.correct += 1;
  const i = all.findIndex(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (i >= 0) { all[i] = rec; saveAll(all); }
}

export function practiceStats(program: string, moduleSlug: string): { total: number; completed: number } | null {
  const rec = getModuleProgress(program, moduleSlug);
  if (!rec || !rec.practice) return null;
  const weeks = rec.practice.weeks;
  let total = 0, completed = 0;
  weeks.forEach(w => w.items.forEach(it => { total += 1; if (it.correct >= 3) completed += 1; }));
  return { total, completed };
}

export function saveQuizResult(
  program: string,
  moduleSlug: string,
  result: {
    quizSlug: string;
    score: number;
    passed: boolean;
    answers: Record<string, string | string[]>;
    topicScores: Record<string, { correct: number; total: number }>;
  }
) {
  const s = getStudent(); if (!s) return;
  const all = loadAll();
  const rec = ensureModuleProgress(program, moduleSlug);
  if (!rec) return;
  rec.quizResults = { ...result, timestamp: new Date().toISOString() };
  const i = all.findIndex(p => p.studentId === s.id && p.program === program && p.module === moduleSlug);
  if (i >= 0) { all[i] = rec; saveAll(all); }
}

export function getQuizResult(program: string, moduleSlug: string) {
  const rec = getModuleProgress(program, moduleSlug);
  return rec?.quizResults || null;
}

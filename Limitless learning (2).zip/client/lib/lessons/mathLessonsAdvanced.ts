import { ComprehensiveLesson, createLesson, lessonSection, youtubeVideo, multipleChoice, shortAnswer, trueFalse, freeResponse } from "@/lib/lessonContent";

// ============================================================================
// MATH 6-8 (GRADES 6 TO 8)
// ============================================================================

export const math68Ratios: ComprehensiveLesson = createLesson(
  "math-6-8-ratios",
  "ratios-and-proportions",
  "Ratios and Proportions",
  "6-8",
  "math",
  ["Understand and write ratios", "Simplify ratios", "Solve proportions"],
  35,
  [
    lessonSection("intro", "introduction", "What is a Ratio?",
      "<p>A <strong>ratio</strong> compares two quantities. If a recipe calls for 2 cups of flour to 1 cup of sugar, the ratio is 2:1.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Recipe ingredients with ratios", video: youtubeVideo("dQw4w9WgXcQ", "Ratios Explained", 180) }
    ),
    lessonSection("concept1", "concept", "Understanding Ratios",
      "<p>Ratios can be written three ways: <strong>3 to 2</strong>, <strong>3 : 2</strong>, or <strong>3/2</strong>.</p>"
    ),
    lessonSection("concept2", "concept", "Simplifying Ratios",
      "<p>To simplify: 12:8 → divide both by 4 → 3:2 (simplified)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Example 1:</strong> Class has 12 girls, 8 boys. Ratio: 12:8 = 3:2</p>"
    ),
    lessonSection("summary", "summary", "Key Facts",
      "<ul><li>A ratio compares two quantities</li><li>Simplify by dividing by GCF</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Simplify 6:2", ["1:2", "3:1", "6:2", "2:3"], "3:1", "easy", "Ratios"),
    multipleChoice("q2", "Which ratios are equivalent?", ["2:3 and 4:6", "1:2 and 2:3", "3:4 and 4:3"], "2:3 and 4:6", "easy", "Ratios"),
    trueFalse("q3", "2:3 equals 4:6", true, "easy", "Ratios"),
    shortAnswer("q4", "Simplify 15:25", "3:5", "medium", "Ratios"),
    trueFalse("q5", "A scale of 1:5 means each unit represents 5 units", true, "medium", "Ratios"),
    multipleChoice("q6", "If boys:girls = 3:2 and there are 15 boys, how many girls?", ["10", "9", "20", "25"], "10", "medium", "Ratios"),
    shortAnswer("q7", "Equivalent ratio to 2:5 with 20 as the second number: ___:20", "8", "medium", "Ratios"),
    trueFalse("q8", "5:10 simplifies to 1:2", true, "medium", "Ratios"),
    freeResponse("q9", "Create a ratio from your environment", "hard", "Ratios"),
    trueFalse("q10", "The ratio 1:100 means the first quantity is 100 times the second", false, "hard", "Ratios"),
    shortAnswer("q11", "If a map scale is 1:50,000, how far apart are two towns 3 inches apart on the map?", "150000", "hard", "Ratios"),
    freeResponse("q12", "Explain equivalent ratios with an example", "hard", "Ratios"),
  ]
);

export const math68Algebra: ComprehensiveLesson = createLesson(
  "math-6-8-algebra",
  "pre-algebra-expressions",
  "Pre-Algebra: Variables and Expressions",
  "6-8",
  "math",
  ["Understand variables", "Write and evaluate expressions", "Simplify with like terms"],
  35,
  [
    lessonSection("intro", "introduction", "Variables in Algebra",
      "<p>In algebra, we use letters like <strong>x</strong> to represent unknown numbers.</p><p>An <strong>expression</strong> combines variables, numbers, and operations: <strong>x + 5</strong>, <strong>3x</strong>, <strong>2x + 3</strong></p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Variables and expressions", video: youtubeVideo("dQw4w9WgXcQ", "Algebra Basics", 180) }
    ),
    lessonSection("concept1", "concept", "Expressions",
      "<p><strong>Variable:</strong> a letter representing an unknown</p><p><strong>Coefficient:</strong> the number multiplying a variable</p><p>In 3x + 2: 3 is coefficient, x is variable</p>"
    ),
    lessonSection("concept2", "concept", "Evaluating",
      "<p>Evaluate 3x + 2 when x = 4: Replace x with 4: 3(4) + 2 = 14</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Example:</strong> Pizza costs $5 each. If you buy x pizzas, cost = 5x dollars</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Variables represent unknown numbers</li><li>Substitute values to evaluate</li><li>3x means 3 times x</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "In 5x, x represents:", ["5", "a number", "multiply"], "a number", "easy", "Algebra"),
    shortAnswer("q2", "Evaluate 2x + 3 when x = 4", "11", "easy", "Algebra"),
    multipleChoice("q3", "3x means:", ["3 + x", "3 times x", "3 minus x"], "3 times x", "easy", "Algebra"),
    trueFalse("q4", "If x = 5, then 2x = 7", false, "easy", "Algebra"),
    shortAnswer("q5", "Write: 'a number times 4 plus 1' as an expression", "4x+1", "medium", "Algebra"),
    multipleChoice("q6", "Evaluate x/2 + 6 when x = 10", ["8", "11", "16", "20"], "11", "medium", "Algebra"),
    trueFalse("q7", "y + y + y equals 3y", true, "medium", "Algebra"),
    shortAnswer("q8", "If n = 6, evaluate 2n - 5", "7", "medium", "Algebra"),
    freeResponse("q9", "Create a real-world expression with a variable", "hard", "Algebra"),
    trueFalse("q10", "3x + 2y has like terms", false, "hard", "Algebra"),
    shortAnswer("q11", "Simplify 5x + 3x - 2x", "6x", "hard", "Algebra"),
    freeResponse("q12", "Explain what a variable represents", "hard", "Algebra"),
  ]
);

export const math68Geometry: ComprehensiveLesson = createLesson(
  "math-6-8-geometry",
  "geometry-area-volume",
  "Geometry: Area and Volume",
  "6-8",
  "math",
  ["Calculate area of 2D shapes", "Calculate volume of 3D shapes", "Apply geometry"],
  35,
  [
    lessonSection("intro", "introduction", "Area and Volume",
      "<p><strong>Area</strong> = space inside 2D shapes (measured in square units)</p><p><strong>Volume</strong> = space inside 3D shapes (measured in cubic units)</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "2D and 3D shapes", video: youtubeVideo("dQw4w9WgXcQ", "Area and Volume", 180) }
    ),
    lessonSection("concept1", "concept", "Area Formulas",
      "<p><strong>Rectangle:</strong> A = length × width</p><p><strong>Triangle:</strong> A = (base × height) ÷ 2</p><p><strong>Circle:</strong> A = π × r²</p>"
    ),
    lessonSection("concept2", "concept", "Volume Formulas",
      "<p><strong>Box:</strong> V = length × width × height</p><p><strong>Cylinder:</strong> V = π × r² × height</p><p><strong>Cube:</strong> V = side³</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Area:</strong> Rectangle 8cm × 5cm = 40cm²</p><p><strong>Volume:</strong> Box 10 × 8 × 6 inches = 480 cubic inches</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Area = 2D measurement</li><li>Volume = 3D measurement</li><li>Rectangle area = length × width</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Area of rectangle 6 × 4 =", ["10 cm²", "24 cm²", "20 cm²"], "24 cm²", "easy", "Geometry"),
    shortAnswer("q2", "10 feet × 5 feet = ___ square feet", "50", "easy", "Geometry"),
    trueFalse("q3", "Area is measured in square units", true, "easy", "Geometry"),
    shortAnswer("q4", "Triangle: base 8, height 6. Area = ___", "24", "easy", "Geometry"),
    multipleChoice("q5", "Volume of 3 × 4 × 5 box =", ["12", "60", "35"], "60", "easy", "Geometry"),
    shortAnswer("q6", "Cube with side 5. Volume = ___", "125", "medium", "Geometry"),
    trueFalse("q7", "Volume is measured in cubic units", true, "medium", "Geometry"),
    multipleChoice("q8", "Rectangle 12m × 8m. Area =", ["96 m²", "20 m²", "40 m²"], "96 m²", "medium", "Geometry"),
    freeResponse("q9", "Find volume of something in your room", "hard", "Geometry"),
    trueFalse("q10", "Circle area formula uses π", true, "hard", "Geometry"),
    shortAnswer("q11", "Triangle: base 10, height 4. Area = ___", "20", "hard", "Geometry"),
    freeResponse("q12", "Compare area and volume concepts", "hard", "Geometry"),
  ]
);

export const math68Probability: ComprehensiveLesson = createLesson(
  "math-6-8-probability",
  "probability-chance",
  "Probability: Understanding Chance",
  "6-8",
  "math",
  ["Understand probability", "Calculate likelihood", "Make predictions"],
  35,
  [
    lessonSection("intro", "introduction", "What is Probability?",
      "<p><strong>Probability</strong> = chance something happens</p><p>Coin flip: P(heads) = 1/2 = 50%</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Probability basics", video: youtubeVideo("dQw4w9WgXcQ", "Probability", 180) }
    ),
    lessonSection("concept1", "concept", "Calculating Probability",
      "<p>P = (favorable outcomes) ÷ (total outcomes)</p><p>4 aces in 52 cards: P(ace) = 4/52 = 1/13</p>"
    ),
    lessonSection("concept2", "concept", "Theoretical vs Experimental",
      "<p><strong>Theoretical:</strong> calculated mathematically</p><p><strong>Experimental:</strong> from actual tests</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Die:</strong> P(rolling 3) = 1/6</p><p><strong>Bag of marbles:</strong> 5 red out of 10. P(red) = 5/10 = 1/2</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Probability ranges 0 to 1</li><li>P(event) = favorable ÷ total</li><li>Fair coin: P(heads) = 1/2</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "P(heads on fair coin) =", ["0", "1/2", "1", "2"], "1/2", "easy", "Probability"),
    shortAnswer("q2", "P(rolling 3 on die) = ___", "1/6", "easy", "Probability"),
    trueFalse("q3", "Probability is between 0 and 1", true, "easy", "Probability"),
    multipleChoice("q4", "3 red, 7 blue marbles. P(red) =", ["3/7", "7/3", "3/10"], "3/10", "easy", "Probability"),
    shortAnswer("q5", "Bag: 2 green, 3 yellow, 5 red. P(green) = ___", "2/10", "medium", "Probability"),
    multipleChoice("q6", "Spinner: 4 equal sections. P(any) =", ["1/2", "1/4", "1/3"], "1/4", "medium", "Probability"),
    trueFalse("q7", "P(event) = 1 means it will happen", true, "medium", "Probability"),
    multipleChoice("q8", "P(event) = 0 means:", ["unlikely", "impossible", "certain"], "impossible", "medium", "Probability"),
    shortAnswer("q9", "4 aces in 52 cards. P(ace) = ___", "1/13", "hard", "Probability"),
    freeResponse("q10", "Design a probability experiment", "hard", "Probability"),
    trueFalse("q11", "Experimental probability always equals theoretical", false, "hard", "Probability"),
    freeResponse("q12", "Explain independent vs dependent events", "hard", "Probability"),
  ]
);

export const math68LikeTerms: ComprehensiveLesson = createLesson(
  "math-6-8-combining",
  "combining-like-terms",
  "Combining Like Terms",
  "6-8",
  "math",
  ["Identify like terms", "Combine to simplify", "Solve equations"],
  35,
  [
    lessonSection("intro", "introduction", "Like Terms",
      "<p><strong>Like terms:</strong> same variable, same power</p><p>2x and 5x are like. 3x and 3y are NOT like.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Like terms examples", video: youtubeVideo("dQw4w9WgXcQ", "Like Terms", 150) }
    ),
    lessonSection("concept1", "concept", "Combining",
      "<p>2x + 5x = 7x</p><p>8x - 3x = 5x</p><p>3y + 2y + y = 6y</p>"
    ),
    lessonSection("concept2", "concept", "Simplifying",
      "<p>3x + 5 + 2x + 3</p><p>= (3x + 2x) + (5 + 3)</p><p>= 5x + 8</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>1:</strong> 4x + 3y + 2x + y = 6x + 4y</p><p><strong>2:</strong> 5a + 2b + 3a - b = 8a + b</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Like terms: same variable</li><li>Add/subtract coefficients</li><li>Unlike terms stay separate</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Are 3x and 5x like terms?", ["yes", "no"], "yes", "easy", "Expressions"),
    shortAnswer("q2", "2x + 4x = ___ x", "6", "easy", "Expressions"),
    trueFalse("q3", "3x and 3y are like terms", false, "easy", "Expressions"),
    shortAnswer("q4", "6x - 2x = ___ x", "4", "easy", "Expressions"),
    trueFalse("q5", "x² and x are like terms", false, "easy", "Expressions"),
    shortAnswer("q6", "3x + 5 + 2x + 3 = ___ x + ___", "5,8", "medium", "Expressions"),
    multipleChoice("q7", "Simplify 4a + 3b + 2a + b", ["6a+4b", "9ab", "6a+2b"], "6a+4b", "medium", "Expressions"),
    shortAnswer("q8", "7x + 2 - 3x + 1 = ___ x + ___", "4,3", "medium", "Expressions"),
    trueFalse("q9", "5y + 2y - y = 6y", true, "medium", "Expressions"),
    freeResponse("q10", "Simplify 2x + 3y + 4x - y", "hard", "Expressions"),
    trueFalse("q11", "x² + x + x² = 2x² + x", true, "hard", "Expressions"),
    freeResponse("q12", "Create and simplify a 4-term expression", "hard", "Expressions"),
  ]
);

// ============================================================================
// MATH 9-10 (GRADES 9-10)
// ============================================================================

export const math910LinearEquations: ComprehensiveLesson = createLesson(
  "math-9-10-linear",
  "linear-equations",
  "Linear Equations: Solving",
  "9-10",
  "math",
  ["Solve multi-step equations", "Use inverse operations", "Real-world applications"],
  40,
  [
    lessonSection("intro", "introduction", "Solving Equations",
      "<p><strong>Equation:</strong> mathematical sentence with =</p><p>Goal: find variable value using <strong>inverse operations</strong></p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Equations intro", video: youtubeVideo("dQw4w9WgXcQ", "Solving", 180) }
    ),
    lessonSection("concept1", "concept", "One and Two Step",
      "<p><strong>One-step:</strong> x + 5 = 12 → x = 7</p><p><strong>Two-step:</strong> 2x + 3 = 11 → 2x = 8 → x = 4</p>"
    ),
    lessonSection("concept2", "concept", "Multi-Step",
      "<p>3x + 5 = 20</p><p>3x = 15</p><p>x = 5</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>1:</strong> x/2 = 6 → x = 12</p><p><strong>2:</strong> 4x - 7 = 9 → x = 4</p><p><strong>3:</strong> 2(x+3) = 14 → x = 4</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Use inverse operations</li><li>Do same to both sides</li><li>Check your answer</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Solve x + 5 = 12", ["5", "7", "12", "17"], "7", "easy", "Equations"),
    shortAnswer("q2", "x - 3 = 8 → x = ___", "11", "easy", "Equations"),
    trueFalse("q3", "x + 4 = 10 → x = 6", true, "easy", "Equations"),
    multipleChoice("q4", "2x = 10 → x = ", ["2", "5", "20"], "5", "easy", "Equations"),
    shortAnswer("q5", "x/4 = 3 → x = ___", "12", "easy", "Equations"),
    shortAnswer("q6", "2x + 3 = 11 → x = ___", "4", "medium", "Equations"),
    multipleChoice("q7", "3x - 5 = 16 → x = ", ["6", "7", "8", "9"], "7", "medium", "Equations"),
    shortAnswer("q8", "x/2 + 5 = 12 → x = ___", "14", "medium", "Equations"),
    multipleChoice("q9", "2(x+1) = 10 → x = ", ["3", "4", "5", "6"], "4", "medium", "Equations"),
    freeResponse("q10", "Solve 3(x-2) = 15", "hard", "Equations"),
    trueFalse("q11", "3x + 7 = 16 → x = 3", true, "hard", "Equations"),
    freeResponse("q12", "Create and solve a multi-step equation", "hard", "Equations"),
  ]
);

// ============================================================================
// MATH 9-10 CONTINUED
// ============================================================================

export const math910QuadraticEquations: ComprehensiveLesson = createLesson(
  "math-9-10-quadratic",
  "quadratic-equations",
  "Quadratic Equations",
  "9-10",
  "math",
  ["Solve quadratic equations", "Use factoring and quadratic formula", "Apply to real problems"],
  45,
  [
    lessonSection("intro", "introduction", "Quadratic Equations",
      "<p>A <strong>quadratic equation</strong> has form ax² + bx + c = 0</p><p>Examples: x² + 2x - 3 = 0, 2x² + 5x + 2 = 0</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Parabola graph", video: youtubeVideo("dQw4w9WgXcQ", "Quadratic Equations", 240) }
    ),
    lessonSection("concept1", "concept", "Solving by Factoring",
      "<p>x² + 5x + 6 = 0</p><p>(x + 2)(x + 3) = 0</p><p>x = -2 or x = -3</p>"
    ),
    lessonSection("concept2", "concept", "Quadratic Formula",
      "<p>x = [-b ± √(b² - 4ac)] / 2a</p><p>Works for any quadratic equation</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Factoring:</strong> x² - 4 = 0 → (x-2)(x+2) = 0 → x = ±2</p><p><strong>Formula:</strong> x² + 2x - 3: a=1, b=2, c=-3 → x = 1 or x = -3</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Standard form: ax² + bx + c = 0</li><li>Two methods: factoring, quadratic formula</li><li>Can have 0, 1, or 2 real solutions</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Factors of x² + 5x + 6:", ["(x+2)(x+3)", "(x+1)(x+6)", "(x-2)(x-3)"], "(x+2)(x+3)", "easy", "Quadratic"),
    shortAnswer("q2", "x² - 9 = 0 → x = ___", "±3", "easy", "Quadratic"),
    trueFalse("q3", "x² + 2x + 1 = 0 factors as (x+1)²", true, "easy", "Quadratic"),
    multipleChoice("q4", "x² - 5x + 6 = 0 solutions:", ["2,3", "1,6", "-2,-3"], "2,3", "easy", "Quadratic"),
    shortAnswer("q5", "x² = 25 → x = ___", "±5", "medium", "Quadratic"),
    multipleChoice("q6", "In x² + 3x - 4, 'a' equals:", ["1", "3", "-4"], "1", "medium", "Quadratic"),
    trueFalse("q7", "2x² - 8 = 0 has x = ±2 solutions", true, "medium", "Quadratic"),
    shortAnswer("q8", "x² + 6x + 9 = 0 → x = ___", "-3", "medium", "Quadratic"),
    multipleChoice("q9", "Discriminant b² - 4ac tells:", ["number of solutions", "vertex", "axis"], "number of solutions", "hard", "Quadratic"),
    freeResponse("q10", "Solve x² - 7x + 12 = 0 by factoring", "hard", "Quadratic"),
    trueFalse("q11", "Every quadratic has two real solutions", false, "hard", "Quadratic"),
    freeResponse("q12", "Explain when to use factoring vs quadratic formula", "hard", "Quadratic"),
  ]
);

export const math910SystemsOfEquations: ComprehensiveLesson = createLesson(
  "math-9-10-systems",
  "systems-of-equations",
  "Systems of Equations",
  "9-10",
  "math",
  ["Solve systems using substitution", "Solve using elimination", "Graph systems"],
  45,
  [
    lessonSection("intro", "introduction", "Systems of Equations",
      "<p>Two or more equations with shared variables</p><p>Example: x + y = 5 and 2x - y = 4</p><p>Solution: values that satisfy ALL equations</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Two lines intersecting", video: youtubeVideo("dQw4w9WgXcQ", "Systems", 240) }
    ),
    lessonSection("concept1", "concept", "Substitution Method",
      "<p>y = x + 1 and 2x + y = 7</p><p>Substitute: 2x + (x+1) = 7</p><p>3x + 1 = 7 → x = 2, y = 3</p>"
    ),
    lessonSection("concept2", "concept", "Elimination Method",
      "<p>2x + y = 5 and x - y = 1</p><p>Add equations: 3x = 6 → x = 2</p><p>Substitute: 2 - y = 1 → y = 1</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Substitution:</strong> x = 3, y = 2x - 1 → solution: (3,5)</p><p><strong>Elimination:</strong> Multiply to eliminate, then solve</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Systems can have one, no, or infinite solutions</li><li>Substitution: solve one, substitute</li><li>Elimination: add/subtract to eliminate variable</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Check: does (2,1) solve x+y=3 and x-y=1?", ["yes", "no"], "yes", "easy", "Systems"),
    shortAnswer("q2", "y = x + 2, x + y = 8 → x = ___", "3", "easy", "Systems"),
    trueFalse("q3", "Point (1,2) solves both x+y=3 and 2x+y=4", true, "easy", "Systems"),
    multipleChoice("q4", "In substitution, solve first for:", ["any variable", "x only", "y only"], "any variable", "easy", "Systems"),
    shortAnswer("q5", "x + y = 7, x - y = 1 → x = ___", "4", "medium", "Systems"),
    multipleChoice("q6", "2x + y = 5, x + y = 3 → y =", ["1", "2", "-1"], "1", "medium", "Systems"),
    trueFalse("q7", "Parallel lines have no solution", true, "medium", "Systems"),
    shortAnswer("q8", "y = 2x, x + y = 9 → y = ___", "6", "medium", "Systems"),
    multipleChoice("q9", "When lines are same, solutions =", ["zero", "one", "infinite"], "infinite", "hard", "Systems"),
    freeResponse("q10", "Solve x + y = 10, 3x - y = 6 using elimination", "hard", "Systems"),
    trueFalse("q11", "2x + y = 4 and 4x + 2y = 8 have infinite solutions", true, "hard", "Systems"),
    freeResponse("q12", "Create a system with (2,3) as solution", "hard", "Systems"),
  ]
);

export const math910ExponentialFunctions: ComprehensiveLesson = createLesson(
  "math-9-10-exponential",
  "exponential-functions",
  "Exponential Functions",
  "9-10",
  "math",
  ["Understand exponential growth/decay", "Write exponential equations", "Solve applications"],
  45,
  [
    lessonSection("intro", "introduction", "Exponential Functions",
      "<p><strong>Exponential:</strong> y = a·b^x</p><p>Example: bacteria doubling: 2^n where n = time periods</p><p>Used for growth, decay, compound interest</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Exponential curve", video: youtubeVideo("dQw4w9WgXcQ", "Exponential", 240) }
    ),
    lessonSection("concept1", "concept", "Growth and Decay",
      "<p><strong>Growth:</strong> y = a(1+r)^t where r > 0</p><p><strong>Decay:</strong> y = a(1-r)^t where r > 0</p><p>Example: $1000 at 5% growth: y = 1000(1.05)^t</p>"
    ),
    lessonSection("concept2", "concept", "Comparing Forms",
      "<p><strong>y = 2^x:</strong> doubling function</p><p><strong>y = (1/2)^x:</strong> halving function</p><p><strong>y = 3·2^x:</strong> scaled doubling</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Growth:</strong> Initial: 100, rate 10%/year: y = 100(1.1)^t</p><p><strong>Decay:</strong> Half-life: y = 100(0.5)^t</p><p><strong>Application:</strong> Population doubles every 5 years starting with 2,000</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Exponential: variable is exponent</li><li>Base > 1 = growth, 0 < base < 1 = decay</li><li>Applications: population, money, radioactivity</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "In y = 2^x, when x=3:", ["y=6", "y=8", "y=9"], "y=8", "easy", "Exponential"),
    shortAnswer("q2", "y = 3^x, x = 2 → y = ___", "9", "easy", "Exponential"),
    trueFalse("q3", "y = (1/2)^x is decay because base < 1", true, "easy", "Exponential"),
    multipleChoice("q4", "y = 100(1.05)^t is:", ["growth", "decay", "linear"], "growth", "easy", "Exponential"),
    shortAnswer("q5", "y = 4^x, x = 1.5 → y = ___", "8", "medium", "Exponential"),
    trueFalse("q6", "In y = a·b^x, a is the base", false, "medium", "Exponential"),
    multipleChoice("q7", "Compound interest: 5000 at 3% for 2 years:", ["5309", "5300", "5150"], "5309", "medium", "Exponential"),
    shortAnswer("q8", "y = 500(0.9)^t (decay) at t=2 → y ≈ ___", "405", "medium", "Exponential"),
    multipleChoice("q9", "Cell division doubles every hour. Start 10. After 3h:", ["30", "40", "80"], "80", "hard", "Exponential"),
    freeResponse("q10", "Write exponential for $2000 growing 4% annually", "hard", "Exponential"),
    trueFalse("q11", "y = 2^x passes through (0,1)", true, "hard", "Exponential"),
    freeResponse("q12", "Compare exponential and linear growth", "hard", "Exponential"),
  ]
);

// ============================================================================
// MATH 11-12 (GRADES 11-12)
// ============================================================================

export const math1112Trigonometry: ComprehensiveLesson = createLesson(
  "math-11-12-trig",
  "trigonometry-ratios",
  "Trigonometry: Ratios and Functions",
  "11-12",
  "math",
  ["Understand sine, cosine, tangent", "Use trig ratios to solve triangles", "Apply to real situations"],
  50,
  [
    lessonSection("intro", "introduction", "Trigonometry Basics",
      "<p><strong>Trigonometry</strong> = study of triangles using ratios</p><p><strong>SOH-CAH-TOA:</strong> Sine = Opp/Hyp, Cosine = Adj/Hyp, Tangent = Opp/Adj</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Right triangle", video: youtubeVideo("dQw4w9WgXcQ", "Trig", 300) }
    ),
    lessonSection("concept1", "concept", "Basic Ratios",
      "<p>In right triangle: sin θ = opposite/hypotenuse</p><p>cos θ = adjacent/hypotenuse</p><p>tan θ = opposite/adjacent</p>"
    ),
    lessonSection("concept2", "concept", "Special Triangles",
      "<p>45-45-90: sides in ratio 1:1:√2</p><p>30-60-90: sides in ratio 1:√3:2</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Find angle:</strong> sin θ = 0.5 → θ = 30°</p><p><strong>Find side:</strong> cos 40° = x/10 → x = 10·cos(40°) ≈ 7.66</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>SOHCAHTOA helps remember ratios</li><li>sin²θ + cos²θ = 1 (Pythagorean identity)</li><li>Inverse: arcsin, arccos, arctan find angles</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "sin θ = opposite/___", ["adjacent", "hypotenuse", "angle"], "hypotenuse", "easy", "Trig"),
    shortAnswer("q2", "In 45-45-90 triangle, if leg = 5, hyp = ___", "5√2", "easy", "Trig"),
    trueFalse("q3", "tan 45° = 1", true, "easy", "Trig"),
    multipleChoice("q4", "tan θ = opposite/___", ["adjacent", "hyp", "angle"], "adjacent", "easy", "Trig"),
    shortAnswer("q5", "sin 30° = ___", "0.5", "medium", "Trig"),
    trueFalse("q6", "cos 0° = 1", true, "medium", "Trig"),
    multipleChoice("q7", "In 30-60-90, sides ratio is:", ["1:1:√2", "1:√3:2", "2:2:3"], "1:√3:2", "medium", "Trig"),
    shortAnswer("q8", "tan 60° = ___", "√3", "medium", "Trig"),
    multipleChoice("q9", "sin² θ + cos² θ =", ["0", "1", "θ"], "1", "hard", "Trig"),
    freeResponse("q10", "Solve right triangle with angle 35° and hyp 20", "hard", "Trig"),
    trueFalse("q11", "arcsin(0.866) ≈ 60°", true, "hard", "Trig"),
    freeResponse("q12", "Explain SOH-CAH-TOA mnemonic", "hard", "Trig"),
  ]
);

export const math1112Logarithms: ComprehensiveLesson = createLesson(
  "math-11-12-logarithms",
  "logarithms-properties",
  "Logarithms and Exponentials",
  "11-12",
  "math",
  ["Understand logarithm definition", "Use logarithm properties", "Solve exponential and logarithmic equations"],
  50,
  [
    lessonSection("intro", "introduction", "Logarithms",
      "<p><strong>Logarithm:</strong> inverse of exponential</p><p>If 2³ = 8, then log₂(8) = 3</p><p>Definition: log_b(x) = y means b^y = x</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Log graph", video: youtubeVideo("dQw4w9WgXcQ", "Logarithms", 300) }
    ),
    lessonSection("concept1", "concept", "Properties",
      "<p>log_b(xy) = log_b(x) + log_b(y)</p><p>log_b(x/y) = log_b(x) - log_b(y)</p><p>log_b(x^n) = n·log_b(x)</p>"
    ),
    lessonSection("concept2", "concept", "Common and Natural",
      "<p><strong>log(x)</strong> = log₁₀(x) (common logarithm)</p><p><strong>ln(x)</strong> = log_e(x) (natural log, e ≈ 2.718)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Convert:</strong> log₂(8) = 3 because 2³ = 8</p><p><strong>Simplify:</strong> log(100) = 2 because 10² = 100</p><p><strong>Solve:</strong> log_2(x) = 5 → x = 2⁵ = 32</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>log_b(b) = 1, log_b(1) = 0</li><li>log and exponential are inverses</li><li>Change of base: log_b(x) = ln(x)/ln(b)</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "log₂(8) = ___", ["2", "3", "4"], "3", "easy", "Logarithm"),
    shortAnswer("q2", "log₁₀(100) = ___", "2", "easy", "Logarithm"),
    trueFalse("q3", "log_b(b) = 1 for any base b", true, "easy", "Logarithm"),
    multipleChoice("q4", "If log(x) = 2, then x =", ["2", "10", "100"], "100", "easy", "Logarithm"),
    shortAnswer("q5", "log₃(27) = ___", "3", "medium", "Logarithm"),
    trueFalse("q6", "log(x·y) = log(x) + log(y)", true, "medium", "Logarithm"),
    multipleChoice("q7", "ln(e) =", ["0", "1", "e"], "1", "medium", "Logarithm"),
    shortAnswer("q8", "log₂(1) = ___", "0", "medium", "Logarithm"),
    multipleChoice("q9", "Solve 2^x = 16:", ["x=3", "x=4", "x=5"], "x=4", "hard", "Logarithm"),
    freeResponse("q10", "Simplify log(x²y/z)", "hard", "Logarithm"),
    trueFalse("q11", "log(x/y) = log(x) - log(y)", true, "hard", "Logarithm"),
    freeResponse("q12", "Explain how log and exponential are inverses", "hard", "Logarithm"),
  ]
);

export const math1112Calculus: ComprehensiveLesson = createLesson(
  "math-11-12-calculus",
  "calculus-limits-derivatives",
  "Calculus Basics: Limits and Rates of Change",
  "11-12",
  "math",
  ["Understand limits", "Understand derivatives as rate of change", "Apply to optimization"],
  50,
  [
    lessonSection("intro", "introduction", "What is Calculus?",
      "<p><strong>Calculus</strong> studies continuous change</p><p><strong>Limit:</strong> value function approaches as x approaches a value</p><p><strong>Derivative:</strong> rate of change at a point</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Calculus curve", video: youtubeVideo("dQw4w9WgXcQ", "Calculus", 300) }
    ),
    lessonSection("concept1", "concept", "Limits",
      "<p>lim(x→2) (x² + 1) = 5</p><p>As x gets closer to 2, f(x) approaches 5</p><p>Limit may not equal function value at that point</p>"
    ),
    lessonSection("concept2", "concept", "Derivatives",
      "<p><strong>Derivative:</strong> slope of tangent line, rate of change</p><p>f'(x) or dy/dx</p><p>Power rule: d/dx(x^n) = n·x^(n-1)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Derivative of x²:</strong> f'(x) = 2x</p><p><strong>Derivative of 3x³:</strong> f'(x) = 9x²</p><p><strong>Velocity:</strong> derivative of position gives velocity</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Limit finds value function approaches</li><li>Derivative measures rate of change</li><li>Derivative = 0 at max/min points (optimization)</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is a limit?", ["largest value", "value function approaches", "starting point"], "value function approaches", "easy", "Calculus"),
    shortAnswer("q2", "Derivative of x² is: f'(x) = ___", "2x", "easy", "Calculus"),
    trueFalse("q3", "Derivative measures rate of change", true, "easy", "Calculus"),
    multipleChoice("q4", "Derivative of constant = ___", ["0", "1", "constant"], "0", "easy", "Calculus"),
    shortAnswer("q5", "f(x) = x³, f'(x) = ___", "3x²", "medium", "Calculus"),
    trueFalse("q6", "Power rule: d/dx(x^n) = nx^(n-1)", true, "medium", "Calculus"),
    multipleChoice("q7", "Derivative at max/min:", ["positive", "zero", "undefined"], "zero", "medium", "Calculus"),
    shortAnswer("q8", "f(x) = 4x² + 2x, f'(x) = ___", "8x+2", "medium", "Calculus"),
    multipleChoice("q9", "Velocity is derivative of:", ["time", "position", "speed"], "position", "hard", "Calculus"),
    freeResponse("q10", "Find derivative of 5x³ + 2x² - 3", "hard", "Calculus"),
    trueFalse("q11", "Derivative of e^x equals e^x", true, "hard", "Calculus"),
    freeResponse("q12", "Explain why derivative = 0 at extrema", "hard", "Calculus"),
  ]
);

export const math1112Statistics: ComprehensiveLesson = createLesson(
  "math-11-12-statistics",
  "statistics-distributions",
  "Statistics: Normal Distribution and Inference",
  "11-12",
  "math",
  ["Understand normal distribution", "Calculate z-scores", "Make statistical inferences"],
  50,
  [
    lessonSection("intro", "introduction", "Statistics Basics",
      "<p><strong>Statistics:</strong> collect, analyze, interpret data</p><p><strong>Normal Distribution:</strong> bell-shaped curve, 68-95-99.7 rule</p><p><strong>Z-score:</strong> standardized measure of distance from mean</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Bell curve", video: youtubeVideo("dQw4w9WgXcQ", "Statistics", 300) }
    ),
    lessonSection("concept1", "concept", "Normal Distribution",
      "<p>68% of data within 1 standard deviation</p><p>95% within 2 standard deviations</p><p>99.7% within 3 standard deviations</p>"
    ),
    lessonSection("concept2", "concept", "Z-Scores",
      "<p>z = (x - mean) / standard deviation</p><p>z-score tells how many std devs from mean</p><p>z > 0: above mean, z < 0: below mean</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Mean = 100, SD = 15, x = 115:</strong> z = (115-100)/15 = 1</p><p><strong>Interpretation:</strong> 115 is 1 std dev above mean</p>"
    ),
    lessonSection("summary", "summary", "Facts",
      "<ul><li>Normal curve is symmetric around mean</li><li>Z-score standardizes different scales</li><li>Confidence intervals estimate population parameters</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "In normal distribution, % within 1 SD:", ["68%", "95%", "99.7%"], "68%", "easy", "Statistics"),
    shortAnswer("q2", "z = (x - mean) / ___", "stdev", "easy", "Statistics"),
    trueFalse("q3", "Normal curve is symmetric", true, "easy", "Statistics"),
    multipleChoice("q4", "z = 0 means:", ["at mean", "below mean", "above mean"], "at mean", "easy", "Statistics"),
    shortAnswer("q5", "Mean = 50, SD = 5, x = 60: z = ___", "2", "medium", "Statistics"),
    trueFalse("q6", "z-score allows comparison across different datasets", true, "medium", "Statistics"),
    multipleChoice("q7", "P(Z < 0) in standard normal:", ["0.25", "0.5", "0.75"], "0.5", "medium", "Statistics"),
    shortAnswer("q8", "95% rule: data within ±___ SD from mean", "2", "medium", "Statistics"),
    multipleChoice("q9", "Negative z-score means:", ["below mean", "above mean", "at mean"], "below mean", "hard", "Statistics"),
    freeResponse("q10", "Explain 68-95-99.7 rule", "hard", "Statistics"),
    trueFalse("q11", "All distributions are normal", false, "hard", "Statistics"),
    freeResponse("q12", "How do z-scores help compare different groups?", "hard", "Statistics"),
  ]
);

// Export all advanced math lessons
export const allMathAdvancedLessons = [
  math68Ratios,
  math68Algebra,
  math68Geometry,
  math68Probability,
  math68LikeTerms,
  math910LinearEquations,
  math910QuadraticEquations,
  math910SystemsOfEquations,
  math910ExponentialFunctions,
  math1112Trigonometry,
  math1112Logarithms,
  math1112Calculus,
  math1112Statistics,
];

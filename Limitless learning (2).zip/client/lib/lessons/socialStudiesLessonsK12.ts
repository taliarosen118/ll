import { ComprehensiveLesson, createLesson, lessonSection, youtubeVideo, multipleChoice, shortAnswer, trueFalse, freeResponse } from "@/lib/lessonContent";

// ============================================================================
// SOCIAL STUDIES K-2 (GRADES KINDERGARTEN TO 2)
// ============================================================================

export const socialK2Communities: ComprehensiveLesson = createLesson(
  "social-k2-communities",
  "communities-helpers",
  "Communities and Community Helpers",
  "K-2",
  "socialstudies",
  ["Understand what is a community", "Identify community helpers", "Learn about community roles"],
  30,
  [
    lessonSection("intro", "introduction", "What is a Community?",
      "<p>A <strong>community</strong> is a group of people living together in same area.</p><p>Communities have helpers: teachers, firefighters, doctors, police</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Community helpers", video: youtubeVideo("dQw4w9WgXcQ", "Communities", 120) }
    ),
    lessonSection("concept1", "concept", "Types of Communities",
      "<p>Urban: cities with many people and tall buildings</p><p>Rural: countryside with farms and open space</p><p>Suburban: neighborhoods between city and country</p>"
    ),
    lessonSection("concept2", "concept", "Community Helpers",
      "<p><strong>Firefighter:</strong> helps with fires, safety</p><p><strong>Police Officer:</strong> keeps community safe</p><p><strong>Doctor/Nurse:</strong> helps when sick</p><p><strong>Teacher:</strong> helps children learn</p>"
    ),
    lessonSection("concept3", "concept", "Community Services",
      "<p>Libraries, parks, schools, hospitals</p><p>Help make community work well</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>In my community: school teaches me, fire station helps if fire, park for playing</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Communities are groups of people</li><li>Helpers make communities safe and healthy</li><li>Services help everyone</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Community is:", ["one person", "group of people", "one school"], "group of people", "easy", "Social Studies"),
    trueFalse("q2", "Firefighters help with safety", true, "easy", "Social Studies"),
    multipleChoice("q3", "Doctor helps when:", ["playing", "hungry", "sick"], "sick", "easy", "Social Studies"),
    shortAnswer("q4", "Police officer keeps ___ safe", "community", "easy", "Social Studies"),
    multipleChoice("q5", "City is ___ community type", ["urban", "rural", "suburban"], "urban", "easy", "Social Studies"),
    trueFalse("q6", "All communities are the same", false, "easy", "Social Studies"),
    shortAnswer("q7", "Library is ___ service", "community", "medium", "Social Studies"),
    multipleChoice("q8", "Rural has:", ["cities", "farms", "skyscrapers"], "farms", "medium", "Social Studies"),
    trueFalse("q9", "Community helpers are important", true, "medium", "Social Studies"),
    freeResponse("q10", "Describe your community", "hard", "Social Studies"),
    trueFalse("q11", "Suburban is between city and country", true, "hard", "Social Studies"),
    freeResponse("q12", "Explain why we need community helpers", "hard", "Social Studies"),
  ]
);

export const socialK2FamilyRules: ComprehensiveLesson = createLesson(
  "social-k2-family",
  "family-rules",
  "Family and Rules",
  "K-2",
  "socialstudies",
  ["Understand family structures", "Learn about rules", "Recognize responsibilities"],
  30,
  [
    lessonSection("intro", "introduction", "Family and Home",
      "<p>Families take care of each other. Families have rules to keep everyone safe and healthy.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Family time", video: youtubeVideo("dQw4w9WgXcQ", "Family", 120) }
    ),
    lessonSection("concept1", "concept", "Types of Families",
      "<p>Families come in different shapes and sizes</p><p>Can have: two parents, one parent, grandparents, aunts, uncles</p><p>All are real families</p>"
    ),
    lessonSection("concept2", "concept", "Family Roles",
      "<p>Parents: take care, teach, protect</p><p>Children: listen, learn, help</p><p>Everyone: shows love and respect</p>"
    ),
    lessonSection("concept3", "concept", "Rules Keep Us Safe",
      "<p>Don't run in street. Buckle up. Hold hands</p><p>Rules help family work together</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Family rule: eat meals together. Everyone listens. Everyone helps clean up.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Families are different</li><li>Everyone has roles</li><li>Rules help and protect</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Families can be:", ["two parents", "one parent", "both"], "both", "easy", "Social Studies"),
    trueFalse("q2", "Rules keep family safe", true, "easy", "Social Studies"),
    multipleChoice("q3", "Parents:", ["play games", "take care of children", "sleep all day"], "take care of children", "easy", "Social Studies"),
    shortAnswer("q4", "Children should ___ adults", "listen to/obey", "easy", "Social Studies"),
    trueFalse("q6", "All families are the same", false, "easy", "Social Studies"),
    shortAnswer("q7", "One family rule:", "bedtime/homework", "medium", "Social Studies"),
    multipleChoice("q8", "Family shows:", ["fun", "love", "both"], "both", "medium", "Social Studies"),
    freeResponse("q9", "Describe your family", "hard", "Social Studies"),
    trueFalse("q10", "Rules only restrict fun", false, "easy", "Social Studies"),
    freeResponse("q11", "Explain why rules are important", "hard", "Social Studies"),
    trueFalse("q12", "Respect is important in family", true, "medium", "Social Studies"),
  ]
);

export const socialK2Holidays: ComprehensiveLesson = createLesson(
  "social-k2-holidays",
  "holidays-traditions",
  "Holidays and Traditions",
  "K-2",
  "socialstudies",
  ["Understand different holidays", "Learn about traditions", "Respect different cultures"],
  30,
  [
    lessonSection("intro", "introduction", "Celebrating Together",
      "<p>Holidays are special days families and communities celebrate together.</p><p>Each holiday has special meaning and traditions</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Holiday celebration", video: youtubeVideo("dQw4w9WgXcQ", "Holidays", 120) }
    ),
    lessonSection("concept1", "concept", "Common Holidays",
      "<p><strong>Christmas:</strong> celebrating birth of Jesus</p><p><strong>Hanukkah:</strong> Jewish festival</p><p><strong>Thanksgiving:</strong> giving thanks</p><p><strong>New Year:</strong> new beginning</p>"
    ),
    lessonSection("concept2", "concept", "Cultural Holidays",
      "<p>Different families celebrate different holidays</p><p>Different cultures have special traditions</p>"
    ),
    lessonSection("concept3", "concept", "Traditions",
      "<p>Special things families do: cooking, decorating, visiting, gifts</p><p>Traditions bring families together</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Christmas: decorate tree, open gifts. Thanksgiving: family dinner. Birthday: party with friends</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Holidays celebrate special occasions</li><li>Different families different holidays</li><li>Traditions bring joy</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Holiday is:", ["day off", "special celebration", "vacation"], "special celebration", "easy", "Social Studies"),
    trueFalse("q2", "All families celebrate same holidays", false, "easy", "Social Studies"),
    multipleChoice("q3", "Christmas celebrates:", ["New Year", "Jesus' birth", "summer"], "Jesus' birth", "easy", "Social Studies"),
    shortAnswer("q4", "Thanksgiving is about ___", "giving thanks", "easy", "Social Studies"),
    multipleChoice("q5", "Hanukkah is:", ["Christian", "Jewish", "secular"], "Jewish", "easy", "Social Studies"),
    trueFalse("q6", "Traditions are family customs", true, "easy", "Social Studies"),
    shortAnswer("q7", "Decoration is holiday ___", "tradition", "medium", "Social Studies"),
    multipleChoice("q8", "Different cultures have:", ["same holidays", "different holidays", "no holidays"], "different holidays", "medium", "Social Studies"),
    trueFalse("q9", "Holidays bring families together", true, "medium", "Social Studies"),
    freeResponse("q10", "Describe your favorite holiday", "hard", "Social Studies"),
    trueFalse("q11", "Respecting all holidays is important", true, "hard", "Social Studies"),
    freeResponse("q12", "Explain a holiday tradition", "hard", "Social Studies"),
  ]
);

export const socialK2BasicNeeds: ComprehensiveLesson = createLesson(
  "social-k2-needs",
  "basic-human-needs",
  "Basic Human Needs",
  "K-2",
  "socialstudies",
  ["Identify basic human needs", "Understand wants vs needs", "Learn gratitude"],
  30,
  [
    lessonSection("intro", "introduction", "What We Need",
      "<p>Everyone needs: food, water, shelter, clothes, safety, love</p><p>Needs are different from wants</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Basic needs", video: youtubeVideo("dQw4w9WgXcQ", "Needs", 120) }
    ),
    lessonSection("concept1", "concept", "Needs",
      "<p><strong>Food:</strong> keeps us healthy and strong</p><p><strong>Water:</strong> keeps us healthy</p><p><strong>Shelter:</strong> house keeps us warm and safe</p><p><strong>Clothes:</strong> protect from weather</p>"
    ),
    lessonSection("concept2", "concept", "Safety and Love",
      "<p>Safety: we need safe place, people watching out</p><p>Love: family and friends care about us</p>"
    ),
    lessonSection("concept3", "concept", "Wants vs Needs",
      "<p>Need: food, water, house, clothes (must have)</p><p>Want: toys, candy, video games (nice to have)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Need: eat breakfast. Want: eat cake. Need: warm coat. Want: new sneakers.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Everyone has basic needs</li><li>Needs are different from wants</li><li>Be grateful for what we have</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Food is:", ["need", "want", "toy"], "need", "easy", "Social Studies"),
    trueFalse("q2", "Water is a basic need", true, "easy", "Social Studies"),
    multipleChoice("q3", "Shelter means:", ["clothes", "house", "water"], "house", "easy", "Social Studies"),
    shortAnswer("q4", "We need ___ to stay healthy", "food/water", "easy", "Social Studies"),
    multipleChoice("q5", "Want is:", ["must have", "nice to have", "safety"], "nice to have", "easy", "Social Studies"),
    trueFalse("q6", "Love is a basic need", true, "easy", "Social Studies"),
    shortAnswer("q7", "Safety keeps us ___", "safe", "medium", "Social Studies"),
    multipleChoice("q8", "Toy is:", ["need", "want", "required"], "want", "medium", "Social Studies"),
    trueFalse("q9", "Clothes protect from weather", true, "medium", "Social Studies"),
    freeResponse("q10", "List basic needs", "hard", "Social Studies"),
    trueFalse("q11", "All basic needs are same importance", true, "hard", "Social Studies"),
    freeResponse("q12", "Explain difference between need and want", "hard", "Social Studies"),
  ]
);

export const socialK2Map: ComprehensiveLesson = createLesson(
  "social-k2-map",
  "map-skills",
  "Introduction to Maps",
  "K-2",
  "socialstudies",
  ["Understand map symbols", "Learn about directions", "Use simple maps"],
  30,
  [
    lessonSection("intro", "introduction", "Maps Help Us Find Places",
      "<p>A <strong>map</strong> is a picture of a place from above.</p><p>Maps use symbols and colors to show places</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Simple map", video: youtubeVideo("dQw4w9WgXcQ", "Maps", 120) }
    ),
    lessonSection("concept1", "concept", "Directions",
      "<p><strong>North:</strong> up on map</p><p><strong>South:</strong> down on map</p><p><strong>East:</strong> right</p><p><strong>West:</strong> left</p>"
    ),
    lessonSection("concept2", "concept", "Map Symbols",
      "<p>Trees: green. Water: blue. Houses: small squares.</p><p>Symbols show what things are</p>"
    ),
    lessonSection("concept3", "concept", "Using Maps",
      "<p>Find home, school, park on map</p><p>Follow directions to new places</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>School is east of house. Park is south of school</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Maps show places from above</li><li>Use symbols to show things</li><li>Directions help us navigate</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "North on map is:", ["up", "down", "right"], "up", "easy", "Social Studies"),
    trueFalse("q2", "Blue on map means water", true, "easy", "Social Studies"),
    multipleChoice("q3", "West means:", ["left", "right", "down"], "left", "easy", "Social Studies"),
    shortAnswer("q4", "Green symbol on map usually means ___", "trees/forest", "easy", "Social Studies"),
    trueFalse("q6", "Maps show places from above", true, "easy", "Social Studies"),
    shortAnswer("q7", "East is opposite of ___", "west", "medium", "Social Studies"),
    multipleChoice("q8", "Symbol on map shows:", ["direction", "what thing is", "distance"], "what thing is", "medium", "Social Studies"),
    freeResponse("q9", "Describe place using map directions", "hard", "Social Studies"),
    trueFalse("q10", "All maps use same symbols", false, "easy", "Social Studies"),
    freeResponse("q11", "Create simple map of familiar place", "hard", "Social Studies"),
    trueFalse("q12", "Map symbols help us read maps", true, "medium", "Social Studies"),
  ]
);

// ============================================================================
// SOCIAL STUDIES 3-5 (GRADES 3 TO 5)
// ============================================================================

export const social35Geography: ComprehensiveLesson = createLesson(
  "social-3-5-geography",
  "us-geography",
  "U.S. Geography: Regions and Features",
  "3-5",
  "socialstudies",
  ["Identify U.S. regions", "Learn about landforms", "Understand geography impact"],
  35,
  [
    lessonSection("intro", "introduction", "Geography of United States",
      "<p>United States has different regions with different geography</p><p>Mountains, deserts, coastlines, plains shape regions</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "US map", video: youtubeVideo("dQw4w9WgXcQ", "Geography", 150) }
    ),
    lessonSection("concept1", "concept", "Regions",
      "<p><strong>Northeast:</strong> crowded, cities, cold winters</p><p><strong>Southeast:</strong> warm, farming, ports</p><p><strong>Midwest:</strong> plains, farming, lakes</p><p><strong>Southwest:</strong> deserts, mountains, dry</p><p><strong>West:</strong> mountains, coast, varied</p>"
    ),
    lessonSection("concept2", "concept", "Landforms",
      "<p>Mountains: tall, rocky, hard to cross</p><p>Plains: flat land, good for farming</p><p>Rivers: water routes for travel</p><p>Coasts: ocean, trade, fishing</p>"
    ),
    lessonSection("concept3", "concept", "Geography Effects Life",
      "<p>Climate affects what people grow, where they live</p><p>Water needed for towns and farms</p><p>Landforms affect how people live</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Southwest: desert, so dry farming. Midwest: plains, so lots of farms. Northeast: cities, so trade</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>U.S. has different regions</li><li>Landforms affect settlement</li><li>Geography shapes culture</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Northeast is known for:", ["deserts", "cities", "mountains"], "cities", "easy", "Social Studies"),
    trueFalse("q2", "Plains are good for farming", true, "easy", "Social Studies"),
    multipleChoice("q3", "Southwest geography is:", ["mountains and deserts", "flat", "cold"], "mountains and deserts", "easy", "Social Studies"),
    shortAnswer("q4", "Rivers provide ___ routes", "water/trade", "easy", "Social Studies"),
    trueFalse("q6", "Geography affects how people live", true, "easy", "Social Studies"),
    shortAnswer("q7", "Midwest has many ___", "farms", "medium", "Social Studies"),
    multipleChoice("q8", "Coasts are important for:", ["mining", "fishing/trade", "farming"], "fishing/trade", "medium", "Social Studies"),
    freeResponse("q9", "Describe region's geography", "hard", "Social Studies"),
    trueFalse("q10", "All regions have same climate", false, "easy", "Social Studies"),
    freeResponse("q11", "Explain how geography affects settlement", "hard", "Social Studies"),
    trueFalse("q12", "Water is important for towns", true, "medium", "Social Studies"),
  ]
);

export const social35NativeAmericans: ComprehensiveLesson = createLesson(
  "social-3-5-nativeamerican",
  "native-americans",
  "Native Americans: First Peoples",
  "3-5",
  "socialstudies",
  ["Learn about Native American groups", "Understand diverse cultures", "Recognize their history and impact"],
  35,
  [
    lessonSection("intro", "introduction", "Native Americans",
      "<p>Native Americans were first people in North America</p><p>Many different tribes with different cultures</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Native American cultures", video: youtubeVideo("dQw4w9WgXcQ", "Native Americans", 150) }
    ),
    lessonSection("concept1", "concept", "Different Groups",
      "<p><strong>Southwest:</strong> Pueblo, Apache, Navajo (desert, farming)</p><p><strong>Plains:</strong> Sioux, Cheyenne, Apache (buffalo hunting)</p><p><strong>Northeast:</strong> Iroquois, Delaware (hunting, farming)</p><p><strong>West:</strong> Cherokee, Arapaho (forests, mountains)</p>"
    ),
    lessonSection("concept2", "concept", "Ways of Life",
      "<p>Hunted, fished, farmed for food</p><p>Built homes suited to environment</p><p>Had strong spiritual beliefs</p><p>Developed art, music, language</p>"
    ),
    lessonSection("concept3", "concept", "Impact on America",
      "<p>Gave us foods: corn, beans, potatoes</p><p>Gave place names: Mississippi, Ohio, Chicago</p><p>Taught survival skills</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Pueblo: adobe houses, farming. Plains Indians: teepees, buffalo hunting. Northeast: wooden longhouses</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Native Americans were first peoples</li><li>Many different tribes and cultures</li><li>Great impact on America</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Native Americans were:", ["first people", "explorers", "settlers"], "first people", "easy", "Social Studies"),
    trueFalse("q2", "All Native American tribes were same", false, "easy", "Social Studies"),
    multipleChoice("q3", "Plains Indians hunted:", ["deer", "buffalo", "fish"], "buffalo", "easy", "Social Studies"),
    shortAnswer("q4", "Pueblo lived in ___ region", "southwest", "easy", "Social Studies"),
    trueFalse("q6", "Native Americans gave us corn", true, "easy", "Social Studies"),
    shortAnswer("q7", "Iroquois were in ___ region", "northeast", "medium", "Social Studies"),
    multipleChoice("q8", "Teepees were homes of:", ["Southwest", "Plains", "Northeast"], "Plains", "medium", "Social Studies"),
    freeResponse("q9", "Describe Native American way of life", "hard", "Social Studies"),
    trueFalse("q10", "All Native Americans hunted", false, "easy", "Social Studies"),
    freeResponse("q11", "Explain Native American contributions", "hard", "Social Studies"),
    trueFalse("q12", "Native American culture is still important", true, "medium", "Social Studies"),
  ]
);

export const social35ExplorationColonial: ComprehensiveLesson = createLesson(
  "social-3-5-exploration",
  "exploration-colonial",
  "Age of Exploration and Colonial America",
  "3-5",
  "socialstudies",
  ["Understand exploration period", "Learn about early colonies", "Recognize major explorers"],
  35,
  [
    lessonSection("intro", "introduction", "Exploration and Settlement",
      "<p>Europeans explored Americas in 1400s-1500s</p><p>Established colonies where Native Americans lived</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Explorer ships", video: youtubeVideo("dQw4w9WgXcQ", "Exploration", 150) }
    ),
    lessonSection("concept1", "concept", "Famous Explorers",
      "<p><strong>Columbus:</strong> sailed 1492, crossed Atlantic</p><p><strong>Magellan:</strong> circumnavigated globe</p><p><strong>Lewis and Clark:</strong> explored west</p>"
    ),
    lessonSection("concept2", "concept", "First Colonies",
      "<p><strong>Jamestown (1607):</strong> Virginia, first settlement</p><p><strong>Plymouth (1620):</strong> Pilgrims</p><p><strong>Massachusetts:</strong> Boston</p>"
    ),
    lessonSection("concept3", "concept", "Colonial Life",
      "<p>Hard life: farming, disease, danger</p><p>Built homes, schools, churches</p><p>Farming and trading for survival</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Jamestown: tobacco farming. Plymouth: Thanksgiving first harvest. Both: struggle and growth</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Europeans explored Americas</li><li>Started first colonies</li><li>Hard life but new country forming</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Columbus sailed in:", ["1400", "1492", "1600"], "1492", "easy", "Social Studies"),
    trueFalse("q2", "Jamestown was first colony", true, "easy", "Social Studies"),
    multipleChoice("q3", "Plymouth is in:", ["Virginia", "Massachusetts", "New York"], "Massachusetts", "easy", "Social Studies"),
    shortAnswer("q4", "Pilgrims celebrated first ___", "Thanksgiving", "easy", "Social Studies"),
    trueFalse("q6", "Colonial life was easy", false, "easy", "Social Studies"),
    shortAnswer("q7", "Lewis and Clark explored ___", "west/wilderness", "medium", "Social Studies"),
    multipleChoice("q8", "Main activity in colonies:", ["farming", "trading", "both"], "both", "medium", "Social Studies"),
    freeResponse("q9", "Describe colonial settlement", "hard", "Social Studies"),
    trueFalse("q10", "Magellan explored Americas", false, "easy", "Social Studies"),
    freeResponse("q11", "Explain effect of exploration on Native Americans", "hard", "Social Studies"),
    trueFalse("q12", "Colonies eventually became United States", true, "medium", "Social Studies"),
  ]
);

export const social35EconomicsBasics: ComprehensiveLesson = createLesson(
  "social-3-5-economics",
  "basic-economics",
  "Basic Economics and Work",
  "3-5",
  "socialstudies",
  ["Understand needs and wants", "Learn about jobs and work", "Recognize goods and services"],
  35,
  [
    lessonSection("intro", "introduction", "How Economies Work",
      "<p>Economy: system of producing and trading goods</p><p>People work to earn money to buy what they need and want</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Work and jobs", video: youtubeVideo("dQw4w9WgXcQ", "Economics", 150) }
    ),
    lessonSection("concept1", "concept", "Goods and Services",
      "<p><strong>Goods:</strong> things you buy (books, food, clothes)</p><p><strong>Services:</strong> jobs people do (haircuts, teaching, fixing)</p>"
    ),
    lessonSection("concept2", "concept", "Jobs and Money",
      "<p>People work in different jobs</p><p>Job provides money for living</p><p>Different jobs, different pay</p>"
    ),
    lessonSection("concept3", "concept", "Supply and Demand",
      "<p>Supply: how much of thing available</p><p>Demand: how much people want</p><p>Affects price</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Farmer grows food (goods). Teacher teaches (service). Doctor: service. Truck: goods.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>People work to earn money</li><li>Buy goods and services</li><li>Supply and demand affect prices</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Book is:", ["good", "service", "job"], "good", "easy", "Social Studies"),
    trueFalse("q2", "Haircut is a service", true, "easy", "Social Studies"),
    multipleChoice("q3", "People work to:", ["earn money", "help others", "both"], "both", "easy", "Social Studies"),
    shortAnswer("q4", "Farmer produces ___", "food/goods", "easy", "Social Studies"),
    trueFalse("q6", "Money helps us buy what we need", true, "easy", "Social Studies"),
    shortAnswer("q7", "Teacher provides ___", "service", "medium", "Social Studies"),
    multipleChoice("q8", "Price goes up when:", ["supply high", "demand high", "nothing"], "demand high", "medium", "Social Studies"),
    freeResponse("q9", "Name goods and services", "hard", "Social Studies"),
    trueFalse("q10", "All jobs pay the same", false, "easy", "Social Studies"),
    freeResponse("q11", "Explain how jobs help community", "hard", "Social Studies"),
    trueFalse("q12", "Supply and demand matter", true, "medium", "Social Studies"),
  ]
);

// ============================================================================
// SOCIAL STUDIES 6-8 (GRADES 6 TO 8)
// ============================================================================

export const social68AncientCivilizations: ComprehensiveLesson = createLesson(
  "social-6-8-ancient",
  "ancient-civilizations",
  "Ancient Civilizations",
  "6-8",
  "socialstudies",
  ["Understand early civilizations", "Learn about contributions", "Compare ancient societies"],
  40,
  [
    lessonSection("intro", "introduction", "Birth of Civilization",
      "<p>Civilizations: complex societies with cities, government, writing</p><p>First civilizations in river valleys: Mesopotamia, Egypt, Indus, China</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Ancient ruins", video: youtubeVideo("dQw4w9WgXcQ", "Ancient", 180) }
    ),
    lessonSection("concept1", "concept", "Early Civilizations",
      "<p><strong>Mesopotamia (3500 BCE):</strong> Sumer, Babylon, writing, laws</p><p><strong>Egypt (3000 BCE):</strong> Nile River, pyramids, pharaohs</p><p><strong>Indus (2600 BCE):</strong> planned cities</p><p><strong>China (1600 BCE):</strong> dynasties, yellow river</p>"
    ),
    lessonSection("concept2", "concept", "Key Features",
      "<p>Writing system: record information</p><p>Government: organization and law</p><p>Religion: beliefs and practices</p><p>Architecture: impressive structures</p>"
    ),
    lessonSection("concept3", "concept", "Contributions",
      "<p>Mesopotamia: writing (cuneiform), mathematics</p><p>Egypt: architecture, astronomy</p><p>China: papermaking, dynasties concept</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Egyptian pyramids: tombs for pharaohs. Hammurabi's Code: laws. Great Wall: defense</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Civilizations start in river valleys</li><li>Need writing, government, religion</li><li>Made lasting contributions</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Mesopotamia civilization in:", ["Africa", "Asia", "Americas"], "Asia", "easy", "History"),
    trueFalse("q2", "Egypt built pyramids", true, "easy", "History"),
    multipleChoice("q3", "Writing system first in:", ["Egypt", "Mesopotamia", "China"], "Mesopotamia", "easy", "History"),
    shortAnswer("q4", "Hammurabi created ___", "laws/code", "easy", "History"),
    trueFalse("q6", "Ancient civilizations had governments", true, "easy", "History"),
    shortAnswer("q7", "Egypt built along ___ River", "Nile", "medium", "History"),
    multipleChoice("q8", "Pharaoh was:", ["farmer", "Egyptian ruler", "priest"], "Egyptian ruler", "medium", "History"),
    freeResponse("q9", "Describe ancient civilization", "hard", "History"),
    trueFalse("q10", "All civilizations were in same place", false, "easy", "History"),
    freeResponse("q11", "Compare two ancient civilizations", "hard", "History"),
    trueFalse("q12", "Ancient achievements still influence us", true, "medium", "History"),
  ]
);

export const social68MedievalEurope: ComprehensiveLesson = createLesson(
  "social-6-8-medieval",
  "medieval-europe",
  "Medieval Europe: Middle Ages",
  "6-8",
  "socialstudies",
  ["Understand feudal system", "Learn about medieval life", "Recognize medieval contributions"],
  40,
  [
    lessonSection("intro", "introduction", "The Middle Ages",
      "<p>Medieval Europe (500-1500 CE): feudal system, kingdoms, churches</p><p>Society organized by land and power</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Medieval castle", video: youtubeVideo("dQw4w9WgXcQ", "Medieval", 180) }
    ),
    lessonSection("concept1", "concept", "Feudal System",
      "<p><strong>King:</strong> owns all land, makes decisions</p><p><strong>Nobles/Lords:</strong> manage land, provide knights</p><p><strong>Knights:</strong> fight for lord, protection</p><p><strong>Peasants/Serfs:</strong> farm land, owe service</p>"
    ),
    lessonSection("concept2", "concept", "Medieval Life",
      "<p>Castles for protection and power</p><p>Church very powerful in society</p><p>Trade and guilds developing</p><p>Art and architecture flourished</p>"
    ),
    lessonSection("concept3", "concept", "Contributions",
      "<p>Gothic architecture</p><p>Illuminated manuscripts</p><p>Feudalism influence</p><p>Chivalry code</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>King rules kingdom, gives land to nobles. Nobles have knights. Peasants farm. Cathedrals built.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Feudal system organized society</li><li>Church was powerful</li><li>Made cultural contributions</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Feudal system had:", ["king", "nobles", "both"], "both", "easy", "History"),
    trueFalse("q2", "Peasants owned land in feudalism", false, "easy", "History"),
    multipleChoice("q3", "Knights served:", ["king", "lord", "people"], "lord", "easy", "History"),
    shortAnswer("q4", "Medieval period called ___ Ages", "Middle", "easy", "History"),
    trueFalse("q6", "Church was powerful in Middle Ages", true, "easy", "History"),
    shortAnswer("q7", "Castles provided ___", "protection", "medium", "History"),
    multipleChoice("q8", "Guilds were:", ["armies", "craft groups", "churches"], "craft groups", "medium", "History"),
    freeResponse("q9", "Describe feudal hierarchy", "hard", "History"),
    trueFalse("q10", "All medieval people had same life", false, "easy", "History"),
    freeResponse("q11", "Explain medieval society structure", "hard", "History"),
    trueFalse("q12", "Medieval period important to history", true, "medium", "History"),
  ]
);

export const social68GlobalCultures: ComprehensiveLesson = createLesson(
  "social-6-8-cultures",
  "world-cultures",
  "World Cultures and Societies",
  "6-8",
  "socialstudies",
  ["Understand diverse cultures", "Recognize cultural practices", "Respect differences"],
  40,
  [
    lessonSection("intro", "introduction", "Cultures of the World",
      "<p>World has many different cultures with unique traditions, beliefs, languages</p><p>Geography and history shape cultures</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "World cultures", video: youtubeVideo("dQw4w9WgXcQ", "Cultures", 180) }
    ),
    lessonSection("concept1", "concept", "What is Culture",
      "<p>Culture: shared beliefs, values, practices of group</p><p>Includes: language, religion, food, music, art</p>"
    ),
    lessonSection("concept2", "concept", "Different Regions",
      "<p><strong>Africa:</strong> diverse, music, oral traditions</p><p><strong>Asia:</strong> Buddhism, Hinduism, diverse religions</p><p><strong>Americas:</strong> indigenous, colonial influences</p><p><strong>Europe:</strong> varied languages, Christian traditions</p>"
    ),
    lessonSection("concept3", "concept", "Cultural Exchange",
      "<p>Cultures influence each other through trade, migration, contact</p><p>Sharing creates diversity</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Japanese tea ceremony. Indian dances. African drums. European architecture.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Many cultures with unique traditions</li><li>Geography affects culture</li><li>Cultures share and learn from each other</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Culture includes:", ["language", "religion", "both"], "both", "easy", "Social Studies"),
    trueFalse("q2", "All cultures are same", false, "easy", "Social Studies"),
    multipleChoice("q3", "Africa known for:", ["music", "oral traditions", "both"], "both", "easy", "Social Studies"),
    shortAnswer("q4", "Buddhism is in ___ region", "Asia", "easy", "Social Studies"),
    trueFalse("q6", "Cultures can influence each other", true, "easy", "Social Studies"),
    shortAnswer("q7", "Language is part of ___", "culture", "medium", "Social Studies"),
    multipleChoice("q8", "Cultural exchange happens via:", ["trade", "migration", "both"], "both", "medium", "Social Studies"),
    freeResponse("q9", "Describe a culture", "hard", "Social Studies"),
    trueFalse("q10", "All people in region have same culture", false, "easy", "Social Studies"),
    freeResponse("q11", "Compare two different cultures", "hard", "Social Studies"),
    trueFalse("q12", "Respecting cultures is important", true, "medium", "Social Studies"),
  ]
);

export const social68EarlyUSHistory: ComprehensiveLesson = createLesson(
  "social-6-8-earlyus",
  "early-us-history",
  "Early United States: Independence to Civil War",
  "6-8",
  "socialstudies",
  ["Understand path to independence", "Learn about founding documents", "Recognize key figures"],
  40,
  [
    lessonSection("intro", "introduction", "Birth of Nation",
      "<p>Colonies rebelled against Britain (1776)</p><p>Wrote Declaration of Independence</p><p>Fought Revolutionary War, won independence</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Revolutionary War", video: youtubeVideo("dQw4w9WgXcQ", "Revolution", 180) }
    ),
    lessonSection("concept1", "concept", "Path to Independence",
      "<p><strong>Taxation without representation:</strong> colonies angry at taxes</p><p><strong>1776:</strong> Declaration of Independence signed</p><p><strong>1775-1783:</strong> Revolutionary War</p><p><strong>1787:</strong> Constitution written</p>"
    ),
    lessonSection("concept2", "concept", "Key Documents",
      "<p><strong>Declaration of Independence:</strong> stated colonists' rights</p><p><strong>Constitution:</strong> framework for government</p><p><strong>Bill of Rights:</strong> protected freedoms</p>"
    ),
    lessonSection("concept3", "concept", "Expansion and Conflict",
      "<p>Westward expansion to Pacific</p><p>Slavery dividing issue</p><p>Civil War (1861-1865) between North and South</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>George Washington led army. Thomas Jefferson wrote Declaration. Lincoln freed slaves</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Colonies declared independence</li><li>Won revolutionary war</li><li>Created democratic government</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Declaration signed:", ["1775", "1776", "1787"], "1776", "easy", "History"),
    trueFalse("q2", "Revolutionary War gained independence", true, "easy", "History"),
    multipleChoice("q3", "Constitution is:", ["list of laws", "government framework", "freedom statement"], "government framework", "easy", "History"),
    shortAnswer("q4", "George Washington was first ___", "president", "easy", "History"),
    trueFalse("q6", "Bill of Rights protects freedoms", true, "easy", "History"),
    shortAnswer("q7", "Westward expansion went to ___ coast", "Pacific", "medium", "History"),
    multipleChoice("q8", "Civil War was between:", ["North and South", "USA and Britain", "Democrats and Republicans"], "North and South", "medium", "History"),
    freeResponse("q9", "Explain path to independence", "hard", "History"),
    trueFalse("q10", "Slavery was not divisive issue", false, "easy", "History"),
    freeResponse("q11", "Describe founding documents", "hard", "History"),
    trueFalse("q12", "Early U.S. history shaped today", true, "medium", "History"),
  ]
);

// ============================================================================
// SOCIAL STUDIES 9-10 (GRADES 9 TO 10)
// ============================================================================

export const social910Constitution: ComprehensiveLesson = createLesson(
  "social-9-10-constitution",
  "constitution-government",
  "U.S. Constitution and Government Structure",
  "9-10",
  "socialstudies",
  ["Understand Constitution", "Learn government branches", "Understand checks and balances"],
  45,
  [
    lessonSection("intro", "introduction", "Foundation of Government",
      "<p>Constitution: framework for U.S. government (1787)</p><p>Creates three branches with separate powers</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Constitution document", video: youtubeVideo("dQw4w9WgXcQ", "Constitution", 200) }
    ),
    lessonSection("concept1", "concept", "Three Branches",
      "<p><strong>Executive:</strong> President enforces laws</p><p><strong>Legislative:</strong> Congress (Senate, House) makes laws</p><p><strong>Judicial:</strong> Courts interpret laws</p>"
    ),
    lessonSection("concept2", "concept", "Checks and Balances",
      "<p>No branch has too much power</p><p>Each limits other branches</p><p>President can veto Congress bills</p><p>Senate approves judges</p>"
    ),
    lessonSection("concept3", "concept", "Constitutional Amendments",
      "<p>Amendments change Constitution</p><p>Bill of Rights: first 10 amendments protecting freedoms</p><p>22nd: limits president to two terms</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>President vetoes law → Congress needs 2/3 vote to override</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Constitution divides power</li><li>Three equal branches</li><li>Checks and balances prevent tyranny</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Constitution written:", ["1776", "1787", "1791"], "1787", "easy", "Civics"),
    trueFalse("q2", "President leads executive branch", true, "easy", "Civics"),
    multipleChoice("q3", "Congress makes:", ["laws", "judges", "policies"], "laws", "easy", "Civics"),
    shortAnswer("q4", "Courts interpret ___", "laws", "easy", "Civics"),
    trueFalse("q6", "Checks and balances limit power", true, "easy", "Civics"),
    shortAnswer("q7", "Senate approves ___ and treaties", "judges", "medium", "Civics"),
    multipleChoice("q8", "Bill of Rights:", ["first 10 amendments", "last amendments", "declaration"], "first 10 amendments", "medium", "Civics"),
    freeResponse("q9", "Explain three branches", "hard", "Civics"),
    trueFalse("q10", "President makes all decisions", false, "easy", "Civics"),
    freeResponse("q11", "Describe checks and balances examples", "hard", "Civics"),
    trueFalse("q12", "Separation of powers protects freedoms", true, "medium", "Civics"),
  ]
);

export const social910BillOfRights: ComprehensiveLesson = createLesson(
  "social-9-10-bill",
  "bill-of-rights",
  "Bill of Rights: Personal Freedoms",
  "9-10",
  "socialstudies",
  ["Understand first 10 amendments", "Learn about personal freedoms", "Apply rights to situations"],
  45,
  [
    lessonSection("intro", "introduction", "Protecting Freedoms",
      "<p>Bill of Rights (1791): first 10 amendments to Constitution</p><p>Protect fundamental American freedoms</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Bill of Rights", video: youtubeVideo("dQw4w9WgXcQ", "Bill of Rights", 200) }
    ),
    lessonSection("concept1", "concept", "Key Amendments",
      "<p><strong>1st:</strong> speech, religion, assembly, petition</p><p><strong>2nd:</strong> bear arms</p><p><strong>4th:</strong> search and seizure protection</p><p><strong>5th:</strong> due process, self-incrimination</p><p><strong>6th:</strong> trial rights</p>"
    ),
    lessonSection("concept2", "concept", "More Rights",
      "<p><strong>8th:</strong> no cruel punishment</p><p><strong>9th:</strong> rights retained by people</p><p><strong>10th:</strong> powers to states and people</p>"
    ),
    lessonSection("concept3", "concept", "Limitations",
      "<p>Rights not absolute</p><p>Limited by rights of others</p><p>Some restrictions constitutional</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>1st Amendment: can speak, but not libel. Can protest, but peacefully. Can practice religion</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Bill of Rights protects freedoms</li><li>Applies to all Americans</li><li>Rights have reasonable limits</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "1st Amendment protects:", ["speech", "religion", "both"], "both", "easy", "Civics"),
    trueFalse("q2", "Bill of Rights limits government", true, "easy", "Civics"),
    multipleChoice("q3", "4th Amendment about:", ["search", "speech", "trial"], "search", "easy", "Civics"),
    shortAnswer("q4", "6th Amendment protects ___ rights", "trial", "easy", "Civics"),
    trueFalse("q6", "All rights are absolute", false, "easy", "Civics"),
    shortAnswer("q7", "8th Amendment forbids ___ punishment", "cruel", "medium", "Civics"),
    multipleChoice("q8", "Rights apply to:", ["everyone", "some people", "citizens only"], "everyone", "medium", "Civics"),
    freeResponse("q9", "Explain 1st Amendment", "hard", "Civics"),
    trueFalse("q10", "Government can ignore Bill of Rights", false, "easy", "Civics"),
    freeResponse("q11", "Apply amendment to situation", "hard", "Civics"),
    trueFalse("q12", "Freedoms sometimes conflict", true, "medium", "Civics"),
  ]
);

export const social910PresidentialHistory: ComprehensiveLesson = createLesson(
  "social-9-10-presidents",
  "presidential-history",
  "Major Presidents and Their Impacts",
  "9-10",
  "socialstudies",
  ["Know major presidents", "Understand their achievements", "Recognize historical impact"],
  45,
  [
    lessonSection("intro", "introduction", "U.S. Presidents",
      "<p>Presidents lead nation through different eras</p><p>Some had major impacts on history</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Presidents", video: youtubeVideo("dQw4w9WgXcQ", "Presidents", 200) }
    ),
    lessonSection("concept1", "concept", "Founding Presidents",
      "<p><strong>George Washington (1789-1797):</strong> set precedents, united nation</p><p><strong>Thomas Jefferson (1801-1809):</strong> Louisiana Purchase, expansion</p>"
    ),
    lessonSection("concept2", "concept", "Civil War Era",
      "<p><strong>Abraham Lincoln (1861-1865):</strong> preserved union, ended slavery</p><p>Led through Civil War, emancipation</p>"
    ),
    lessonSection("concept3", "concept", "Modern Presidents",
      "<p><strong>Franklin Roosevelt (1933-1945):</strong> Great Depression, WWII</p><p><strong>John Kennedy (1961-1963):</strong> Cold War, space race</p><p><strong>Ronald Reagan (1981-1989):</strong> Cold War ending</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Washington's farewell address. Lincoln's Emancipation Proclamation. FDR's New Deal</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Presidents shape history</li><li>Face different challenges</li><li>Legacies influence nation</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "George Washington was:", ["2nd president", "1st president", "3rd president"], "1st president", "easy", "History"),
    trueFalse("q2", "Lincoln led through Civil War", true, "easy", "History"),
    multipleChoice("q3", "Louisiana Purchase by:", ["Washington", "Jefferson", "Madison"], "Jefferson", "easy", "History"),
    shortAnswer("q4", "Lincoln ended ___", "slavery", "easy", "History"),
    trueFalse("q6", "FDR led through Great Depression", true, "easy", "History"),
    shortAnswer("q7", "Kennedy focused on space ___", "race", "medium", "History"),
    multipleChoice("q8", "Emancipation Proclamation:", ["freed slaves", "ended war", "new laws"], "freed slaves", "medium", "History"),
    freeResponse("q9", "Describe major president's impact", "hard", "History"),
    trueFalse("q10", "All presidents equally important", false, "easy", "History"),
    freeResponse("q11", "Compare two presidents", "hard", "History"),
    trueFalse("q12", "Presidents reflect their times", true, "medium", "History"),
  ]
);

export const social910CivicsBasics: ComprehensiveLesson = createLesson(
  "social-9-10-civics",
  "civics-participation",
  "Civics: Rights and Responsibilities",
  "9-10",
  "socialstudies",
  ["Understand citizen rights", "Know citizen responsibilities", "Learn about voting and participation"],
  45,
  [
    lessonSection("intro", "introduction", "Being a Citizen",
      "<p>Citizens have rights and responsibilities</p><p>Participate in democracy through voting and civic engagement</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Civic participation", video: youtubeVideo("dQw4w9WgXcQ", "Civics", 200) }
    ),
    lessonSection("concept1", "concept", "Rights",
      "<p>Life, liberty, pursuit of happiness</p><p>Vote, speak freely, practice religion</p><p>Education, equal protection</p>"
    ),
    lessonSection("concept2", "concept", "Responsibilities",
      "<p>Obey laws</p><p>Pay taxes</p><p>Serve on jury</p><p>Vote and participate</p>"
    ),
    lessonSection("concept3", "concept", "Civic Participation",
      "<p>Vote in elections</p><p>Volunteer in community</p><p>Serve in military</p><p>Stay informed about issues</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Vote for leaders. Pay taxes that build roads and schools. Jury duty ensures fair trials</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Citizens have fundamental rights</li><li>Must fulfill responsibilities</li><li>Democracy requires participation</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Citizen right is:", ["vote", "speak freely", "both"], "both", "easy", "Civics"),
    trueFalse("q2", "Paying taxes is responsibility", true, "easy", "Civics"),
    multipleChoice("q3", "Voting age is:", ["16", "18", "21"], "18", "easy", "Civics"),
    shortAnswer("q4", "Citizens must obey ___", "laws", "easy", "Civics"),
    trueFalse("q6", "Jury duty is responsibility", true, "easy", "Civics"),
    shortAnswer("q7", "Military service is option or ___", "responsibility", "medium", "Civics"),
    multipleChoice("q8", "Informed citizen means:", ["knows issues", "votes", "both"], "both", "medium", "Civics"),
    freeResponse("q9", "Explain a citizen responsibility", "hard", "Civics"),
    trueFalse("q10", "Rights exist without responsibilities", false, "easy", "Civics"),
    freeResponse("q11", "Describe ways to participate civically", "hard", "Civics"),
    trueFalse("q12", "Democracy needs citizen involvement", true, "medium", "Civics"),
  ]
);

// ============================================================================
// SOCIAL STUDIES 11-12 (GRADES 11 TO 12)
// ============================================================================

export const social1112WorldHistory: ComprehensiveLesson = createLesson(
  "social-11-12-world",
  "world-history",
  "World History: Global Connections",
  "11-12",
  "socialstudies",
  ["Understand major historical periods", "Analyze global events", "Recognize connections"],
  50,
  [
    lessonSection("intro", "introduction", "Interconnected World",
      "<p>World history shows how civilizations connected and influenced each other</p><p>Trade, war, culture spread across continents</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "World history", video: youtubeVideo("dQw4w9WgXcQ", "World History", 220) }
    ),
    lessonSection("concept1", "concept", "Major Periods",
      "<p><strong>Renaissance:</strong> rebirth of classical learning</p><p><strong>Age of Exploration:</strong> global discovery</p><p><strong>Industrial Revolution:</strong> technology and factories</p><p><strong>Modern Era:</strong> world wars, globalization</p>"
    ),
    lessonSection("concept2", "concept", "Global Trade and Culture",
      "<p>Silk Road connected East and West</p><p>Spice trade shaped European exploration</p><p>Cultural exchange through trade</p>"
    ),
    lessonSection("concept3", "concept", "Major Conflicts",
      "<p>World War I: global conflict</p><p>World War II: worldwide impact</p><p>Cold War: ideological struggle</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Renaissance in Italy spread to Europe. Spices from Asia brought Europeans to sea. Industrial revolution transformed society</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Civilizations influenced each other</li><li>Trade connected regions</li><li>Conflicts had global impact</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Renaissance was:", ["dark ages", "rebirth of learning", "modern period"], "rebirth of learning", "easy", "History"),
    trueFalse("q2", "Silk Road connected East-West", true, "easy", "History"),
    multipleChoice("q3", "Industrial Revolution changed:", ["farming", "manufacturing", "both"], "both", "easy", "History"),
    shortAnswer("q4", "World War I affected ___ continents", "multiple/all", "easy", "History"),
    trueFalse("q6", "Culture exchanges through trade", true, "easy", "History"),
    shortAnswer("q7", "Spice trade motivated ___", "exploration", "medium", "History"),
    multipleChoice("q8", "Cold War was:", ["military conflict", "ideological struggle", "both"], "ideological struggle", "medium", "History"),
    freeResponse("q9", "Describe major historical period", "hard", "History"),
    trueFalse("q10", "Events always isolated", false, "easy", "History"),
    freeResponse("q11", "Analyze global historical connections", "hard", "History"),
    trueFalse("q12", "World history helps understand today", true, "medium", "History"),
  ]
);

export const social1112Economics: ComprehensiveLesson = createLesson(
  "social-11-12-economics",
  "advanced-economics",
  "Economics: Systems and Policy",
  "11-12",
  "socialstudies",
  ["Understand economic systems", "Analyze fiscal and monetary policy", "Evaluate global economics"],
  50,
  [
    lessonSection("intro", "introduction", "How Economies Function",
      "<p>Economics studies production, distribution, consumption</p><p>Different systems organize economy differently</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Economics", video: youtubeVideo("dQw4w9WgXcQ", "Economics", 220) }
    ),
    lessonSection("concept1", "concept", "Economic Systems",
      "<p><strong>Capitalism:</strong> private ownership, market decides</p><p><strong>Socialism:</strong> government ownership, equality focus</p><p><strong>Mixed:</strong> both private and government</p>"
    ),
    lessonSection("concept2", "concept", "Policy Tools",
      "<p><strong>Fiscal Policy:</strong> taxes and spending</p><p><strong>Monetary Policy:</strong> interest rates and money supply</p><p>Used to manage economy</p>"
    ),
    lessonSection("concept3", "concept", "Global Economics",
      "<p>Trade between nations</p><p>Supply chains span world</p><p>Currencies and exchange rates</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Lower interest rates encourage borrowing. Higher taxes reduce spending. Trade deals create opportunities</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Different economic systems exist</li><li>Policies affect economy</li><li>World interconnected economically</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Capitalism emphasizes:", ["private ownership", "government control", "equality"], "private ownership", "easy", "Economics"),
    trueFalse("q2", "Socialism focuses on equality", true, "easy", "Economics"),
    multipleChoice("q3", "Fiscal policy involves:", ["taxes", "spending", "both"], "both", "easy", "Economics"),
    shortAnswer("q4", "Interest rates affect ___", "borrowing/economy", "easy", "Economics"),
    trueFalse("q6", "Monetary policy controls money supply", true, "easy", "Economics"),
    shortAnswer("q7", "Federal Reserve manages ___ policy", "monetary", "medium", "Economics"),
    multipleChoice("q8", "Trade helps economies by:", ["specialization", "efficiency", "both"], "both", "medium", "Economics"),
    freeResponse("q9", "Compare economic systems", "hard", "Economics"),
    trueFalse("q10", "All economies same", false, "easy", "Economics"),
    freeResponse("q11", "Analyze economic policy effect", "hard", "Economics"),
    trueFalse("q12", "Global trade interconnects economies", true, "medium", "Economics"),
  ]
);

export const social1112ModernGlobalIssues: ComprehensiveLesson = createLesson(
  "social-11-12-globalissues",
  "modern-global-issues",
  "Modern Global Issues",
  "11-12",
  "socialstudies",
  ["Understand global challenges", "Analyze current issues", "Consider solutions"],
  50,
  [
    lessonSection("intro", "introduction", "Pressing World Challenges",
      "<p>Modern world faces interconnected problems</p><p>Require international cooperation to solve</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Global issues", video: youtubeVideo("dQw4w9WgXcQ", "Global Issues", 220) }
    ),
    lessonSection("concept1", "concept", "Environmental Issues",
      "<p>Climate change: global warming</p><p>Pollution: air, water, land</p><p>Resource depletion: water, forests</p><p>Biodiversity loss</p>"
    ),
    lessonSection("concept2", "concept", "Social Issues",
      "<p>Poverty and inequality</p><p>Access to education</p><p>Healthcare disparities</p><p>Refugee crises</p>"
    ),
    lessonSection("concept3", "concept", "Political Issues",
      "<p>International conflicts</p><p>Human rights violations</p><p>Terrorism</p><p>Nuclear proliferation</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Paris Agreement on climate. UN helps refugees. International courts prosecute crimes</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>World faces complex challenges</li><li>Solutions require cooperation</li><li>Each affects all nations</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Global warming is:", ["local", "regional", "global"], "global", "easy", "Issues"),
    trueFalse("q2", "Climate change affects all nations", true, "easy", "Issues"),
    multipleChoice("q3", "Poverty is:", ["only one region", "global issue", "solved"], "global issue", "easy", "Issues"),
    shortAnswer("q4", "Education access is ___ issue", "global", "easy", "Issues"),
    trueFalse("q6", "Environmental issues affect economy", true, "easy", "Issues"),
    shortAnswer("q7", "Refugees flee ___ or persecution", "war", "medium", "Issues"),
    multipleChoice("q8", "Solution requires:", ["one nation", "international cooperation", "nothing"], "international cooperation", "medium", "Issues"),
    freeResponse("q9", "Analyze global issue", "hard", "Issues"),
    trueFalse("q10", "Global issues isolated", false, "easy", "Issues"),
    freeResponse("q11", "Propose solution to global problem", "hard", "Issues"),
    trueFalse("q12", "Everyone affected by global challenges", true, "medium", "Issues"),
  ]
);

export const social1112CivicsLaw: ComprehensiveLesson = createLesson(
  "social-11-12-civics",
  "civics-law",
  "Civics: Law and the Justice System",
  "11-12",
  "socialstudies",
  ["Understand legal system", "Know types of law", "Comprehend court structure"],
  50,
  [
    lessonSection("intro", "introduction", "Justice and Law",
      "<p>Legal system enforces rules and protects rights</p><p>Based on constitution and laws</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Justice system", video: youtubeVideo("dQw4w9WgXcQ", "Law", 220) }
    ),
    lessonSection("concept1", "concept", "Types of Law",
      "<p><strong>Criminal:</strong> prosecute crimes (murder, theft)</p><p><strong>Civil:</strong> resolve disputes (contracts, property)</p><p><strong>Constitutional:</strong> governs government</p>"
    ),
    lessonSection("concept2", "concept", "Court System",
      "<p><strong>District Courts:</strong> handle trials</p><p><strong>Appeals Courts:</strong> review decisions</p><p><strong>Supreme Court:</strong> highest authority</p>"
    ),
    lessonSection("concept3", "concept", "Due Process",
      "<p>Right to fair trial</p><p>Innocent until proven guilty</p><p>Right to attorney</p><p>Jury of peers</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Criminal case: State vs defendant. Civil case: Plaintiff vs defendant. Appeals: review trial</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Laws protect rights and order</li><li>Courts enforce laws fairly</li><li>Due process ensures justice</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Criminal law handles:", ["crimes", "contracts", "property"], "crimes", "easy", "Civics"),
    trueFalse("q2", "Civil law resolves disputes", true, "easy", "Civics"),
    multipleChoice("q3", "Supreme Court is:", ["local", "state", "highest federal"], "highest federal", "easy", "Civics"),
    shortAnswer("q4", "Innocent until proven ___", "guilty", "easy", "Civics"),
    trueFalse("q6", "Due process protects rights", true, "easy", "Civics"),
    shortAnswer("q7", "Right to ___ in trial", "attorney", "medium", "Civics"),
    multipleChoice("q8", "Jury is:", ["single judge", "peers", "lawyers"], "peers", "medium", "Civics"),
    freeResponse("q9", "Explain court system levels", "hard", "Civics"),
    trueFalse("q10", "All laws same type", false, "easy", "Civics"),
    freeResponse("q11", "Describe due process rights", "hard", "Civics"),
    trueFalse("q12", "Fair justice requires due process", true, "medium", "Civics"),
  ]
);

export const social1112HistoricalAnalysis: ComprehensiveLesson = createLesson(
  "social-11-12-analysis",
  "historical-analysis",
  "Historical Analysis: Interpreting the Past",
  "11-12",
  "socialstudies",
  ["Analyze primary and secondary sources", "Evaluate historical perspectives", "Develop historical arguments"],
  50,
  [
    lessonSection("intro", "introduction", "Studying History",
      "<p>Historians analyze evidence to understand past</p><p>Different sources, perspectives, interpretations</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Historical documents", video: youtubeVideo("dQw4w9WgXcQ", "Analysis", 220) }
    ),
    lessonSection("concept1", "concept", "Source Types",
      "<p><strong>Primary Source:</strong> from the time (letters, documents, artifacts)</p><p><strong>Secondary Source:</strong> about the time (books, articles)</p><p>Each provides different perspective</p>"
    ),
    lessonSection("concept2", "concept", "Historical Perspective",
      "<p>Context affects interpretation</p><p>Bias in all sources</p><p>Multiple viewpoints exist</p>"
    ),
    lessonSection("concept3", "concept", "Historical Argument",
      "<p>Thesis: interpretation of events</p><p>Evidence: support with sources</p><p>Context: explain historical setting</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Letter from soldier (primary). Book about war (secondary). Need both perspectives</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Different sources provide evidence</li><li>Context shapes meaning</li><li>Multiple interpretations valid</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Primary source is:", ["from the time", "about the time", "recent"], "from the time", "easy", "History"),
    trueFalse("q2", "All sources have bias", true, "easy", "History"),
    multipleChoice("q3", "Secondary source is:", ["letter", "diary", "book about past"], "book about past", "easy", "History"),
    shortAnswer("q4", "Context helps ___ sources", "understand", "easy", "History"),
    trueFalse("q6", "Only one historical interpretation", false, "easy", "History"),
    shortAnswer("q7", "Evidence supports historical ___", "argument", "medium", "History"),
    multipleChoice("q8", "Multiple perspectives mean:", ["disagreement", "valid different views", "confusion"], "valid different views", "medium", "History"),
    freeResponse("q9", "Analyze primary source", "hard", "History"),
    trueFalse("q10", "Bias makes sources unreliable", false, "easy", "History"),
    freeResponse("q11", "Develop historical argument with evidence", "hard", "History"),
    trueFalse("q12", "Understanding context important", true, "medium", "History"),
  ]
);

// Export all social studies lessons
export const allSocialStudiesLessons = [
  socialK2Communities,
  socialK2FamilyRules,
  socialK2Holidays,
  socialK2BasicNeeds,
  socialK2Map,
  social35Geography,
  social35NativeAmericans,
  social35ExplorationColonial,
  social35EconomicsBasics,
  social68AncientCivilizations,
  social68MedievalEurope,
  social68GlobalCultures,
  social68EarlyUSHistory,
  social910Constitution,
  social910BillOfRights,
  social910PresidentialHistory,
  social910CivicsBasics,
  social1112WorldHistory,
  social1112Economics,
  social1112ModernGlobalIssues,
  social1112CivicsLaw,
  social1112HistoricalAnalysis,
];

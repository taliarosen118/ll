export type VideoProvider = "youtube" | "vimeo";

export type VideoResource = {
  provider: VideoProvider;
  id: string;
  title: string;
  duration?: number;
};

export type LessonSection = {
  id: string;
  type: "introduction" | "concept" | "example" | "practice-intro" | "summary";
  title: string;
  htmlContent: string;
  video?: VideoResource;
  imageUrl?: string;
  imageAlt?: string;
};

export type PracticeQuestion = {
  id: string;
  type: "multipleChoice" | "shortAnswer" | "truefalse" | "matching" | "dragdrop" | "freeResponse";
  question: string;
  options?: string[];
  correctAnswer?: string | string[];
  correctAnswers?: string[];
  matchPairs?: Array<{ id: string; left: string; right: string }>;
  hint?: string;
  explanation?: string;
  difficulty: "easy" | "medium" | "hard";
  topic: string;
};

export type ComprehensiveLesson = {
  id: string;
  slug: string;
  title: string;
  grade: string;
  subject: "math" | "science" | "english" | "socialstudies";
  objectives: string[];
  estimatedTime: number;
  sections: LessonSection[];
  practiceQuestions: PracticeQuestion[];
  progressCheckQuestions?: PracticeQuestion[];
  relatedTopics?: string[];
  prerequisites?: string[];
};

// Helper function to create a YouTube video resource
export function youtubeVideo(id: string, title: string, duration?: number): VideoResource {
  return { provider: "youtube", id, title, duration };
}

// Helper function to create a Vimeo video resource
export function vimeoVideo(id: string, title: string, duration?: number): VideoResource {
  return { provider: "vimeo", id, title, duration };
}

// Helper function to create a lesson section
export function lessonSection(
  id: string,
  type: LessonSection["type"],
  title: string,
  htmlContent: string,
  options?: {
    video?: VideoResource;
    imageUrl?: string;
    imageAlt?: string;
  }
): LessonSection {
  return {
    id,
    type,
    title,
    htmlContent,
    ...options,
  };
}

// Helper function to create a multiple choice question
export function multipleChoice(
  id: string,
  question: string,
  options: string[],
  correctAnswer: string,
  difficulty: "easy" | "medium" | "hard",
  topic: string,
  hint?: string,
  explanation?: string
): PracticeQuestion {
  return {
    id,
    type: "multipleChoice",
    question,
    options,
    correctAnswer,
    hint,
    explanation,
    difficulty,
    topic,
  };
}

// Helper function to create a short answer question
export function shortAnswer(
  id: string,
  question: string,
  correctAnswer: string | string[],
  difficulty: "easy" | "medium" | "hard",
  topic: string,
  hint?: string,
  explanation?: string
): PracticeQuestion {
  return {
    id,
    type: "shortAnswer",
    question,
    correctAnswer,
    hint,
    explanation,
    difficulty,
    topic,
  };
}

// Helper function to create a true/false question
export function trueFalse(
  id: string,
  question: string,
  correctAnswer: boolean,
  difficulty: "easy" | "medium" | "hard",
  topic: string,
  hint?: string,
  explanation?: string
): PracticeQuestion {
  return {
    id,
    type: "truefalse",
    question,
    correctAnswer: correctAnswer ? "true" : "false",
    hint,
    explanation,
    difficulty,
    topic,
  };
}

// Helper function to create a matching question
export function matching(
  id: string,
  question: string,
  matchPairs: Array<{ id: string; left: string; right: string }>,
  difficulty: "easy" | "medium" | "hard",
  topic: string,
  hint?: string,
  explanation?: string
): PracticeQuestion {
  return {
    id,
    type: "matching",
    question,
    matchPairs,
    hint,
    explanation,
    difficulty,
    topic,
  };
}

// Helper function to create a free response question
export function freeResponse(
  id: string,
  question: string,
  difficulty: "easy" | "medium" | "hard",
  topic: string,
  hint?: string,
  explanation?: string
): PracticeQuestion {
  return {
    id,
    type: "freeResponse",
    question,
    hint,
    explanation,
    difficulty,
    topic,
  };
}

// Helper function to create a lesson
export function createLesson(
  id: string,
  slug: string,
  title: string,
  grade: string,
  subject: "math" | "science" | "english" | "socialstudies",
  objectives: string[],
  estimatedTime: number,
  sections: LessonSection[],
  practiceQuestions: PracticeQuestion[],
  options?: {
    progressCheckQuestions?: PracticeQuestion[];
    relatedTopics?: string[];
    prerequisites?: string[];
  }
): ComprehensiveLesson {
  return {
    id,
    slug,
    title,
    grade,
    subject,
    objectives,
    estimatedTime,
    sections,
    practiceQuestions,
    ...options,
  };
}

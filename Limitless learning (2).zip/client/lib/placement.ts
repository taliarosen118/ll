export type PlacementRecord = { placement: string; planLabel?: string; mLevel?: string; rLevel?: string; form?: any; studentName?: string; date: string };

export function getLastPlacement(): PlacementRecord | null {
  try {
    const raw = localStorage.getItem("ll_last_quiz");
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getGradeLevels() {
  const rec = getLastPlacement();
  const g = safeInt(rec?.form?.grade, 0);
  const mg = safeInt(rec?.form?.mathGrade, g);
  const rg = safeInt(rec?.form?.readingGrade, g);
  return { grade: g, mathGrade: mg, readingGrade: rg };
}

export function gradeClusterLabel(grade: number) {
  if (grade <= 2) return "K–2";
  if (grade <= 5) return "3–5";
  if (grade <= 8) return "6–8";
  if (grade <= 10) return "9–10";
  return "11–12";
}

function safeInt(v: any, fallback: number) {
  const n = parseInt(v ?? "", 10);
  return Number.isFinite(n) ? n : fallback;
}

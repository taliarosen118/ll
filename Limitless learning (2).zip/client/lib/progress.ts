export type Student = { id: string; first: string; last: string; createdAt: string };
export type ProgressEvent = { studentId: string; type: string; ts: string; data?: any };

const LS_STUDENT = "ll_student";
const LS_PROGRESS = "ll_progress_logs";

export function getStudent(): Student | null {
  try { const raw = localStorage.getItem(LS_STUDENT); return raw ? JSON.parse(raw) : null; } catch { return null; }
}

export function setStudent(s: Student | null) {
  try {
    if (s) localStorage.setItem(LS_STUDENT, JSON.stringify(s));
    else localStorage.removeItem(LS_STUDENT);
  } catch {}
}

export function logEvent(type: string, data?: any) {
  const s = getStudent();
  if (!s) return;
  const ev: ProgressEvent = { studentId: s.id, type, ts: new Date().toISOString(), data };
  try {
    const raw = localStorage.getItem(LS_PROGRESS);
    const list: ProgressEvent[] = raw ? JSON.parse(raw) : [];
    list.push(ev);
    localStorage.setItem(LS_PROGRESS, JSON.stringify(list));
  } catch {}
}

export function getAllProgress(): ProgressEvent[] {
  try { const raw = localStorage.getItem(LS_PROGRESS); return raw ? JSON.parse(raw) : []; } catch { return []; }
}

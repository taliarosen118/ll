import { Link, useParams } from "react-router-dom";
import { modulesData, bandKeyFromGrade, AdaptiveModule } from "./modulesData";
import { useEffect } from "react";
import { logEvent } from "@/lib/progress";
import { getGradeLevels, gradeClusterLabel } from "@/lib/placement";

function gradeForSubject(subj: AdaptiveModule["subject"], levels: { grade: number; mathGrade: number; readingGrade: number }) {
  if (subj === "math") return levels.mathGrade;
  if (subj === "reading") return levels.readingGrade;
  return levels.grade; // science uses overall grade
}

export default function ProgramModulesIndex() {
  const { program } = useParams();
  const data = (program && modulesData[program]) || null;
  const levels = getGradeLevels();

  useEffect(() => {
    if (program) logEvent("view_modules_index", { program });
  }, [program]);

  if (!data) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-sm text-muted-foreground">Program not found.</p>
        <Link className="underline" to="/">Back home</Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-between gap-4 mb-4">
        <Link to="/" className="text-sm underline">← Back home</Link>
        <Link to="/programs/knowledge-map" className="text-sm underline">View Knowledge Map</Link>
      </div>
      <header className="mt-2 mb-6">
        <h1 className="text-3xl font-bold">{data.programTitle} — Modules</h1>
        <p className="mt-2 text-muted-foreground">{data.intro}</p>
      </header>

      <div className="grid gap-4 md:grid-cols-2">
        {data.modules.map((m) => {
          const g = gradeForSubject(m.subject, levels);
          const band = bandKeyFromGrade(g);
          const v = m.variants[band];
          const levelLabel = gradeClusterLabel(g);
          return (
            <article key={m.slug} className="rounded-lg border bg-card p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">{m.title} <span className="text-sm text-muted-foreground font-normal">{v.weeks}</span></h2>
                <span className="ml-2 inline-flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="rounded-md border px-2 py-0.5 capitalize">{m.subject}</span>
                  <span className="rounded-md border px-2 py-0.5">{levelLabel}</span>
                </span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{v.overview}</p>
              <div className="mt-3 grid gap-2 md:grid-cols-2">
                <div>
                  <p className="text-sm font-semibold">Lessons</p>
                  <ul className="ml-4 list-disc text-sm text-muted-foreground">
                    {v.lessons.map((l, i) => <li key={i}>{l}</li>)}
                  </ul>
                </div>
                <div>
                  <p className="text-sm font-semibold">Activities</p>
                  <ul className="ml-4 list-disc text-sm text-muted-foreground">
                    {v.activities.map((a, i) => <li key={i}>{a}</li>)}
                  </ul>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-xs text-muted-foreground" title="Includes audio and captions">
                  <span aria-hidden>����</span> Audio + CC
                </span>
                <Link className="underline" to={`/programs/${program}/modules/${m.slug}`}>Open module</Link>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}

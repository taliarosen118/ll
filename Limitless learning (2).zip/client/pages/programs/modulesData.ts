export type Subject = "math" | "reading" | "science";

export type GradeBand = "k2" | "g3_5" | "g6_8" | "g9_10" | "g11_12";

export type LessonContent = {
  slug: string;
  title: string;
  description: string;
  sections: Array<{
    type: "text" | "image" | "video" | "callout";
    content: string;
    alt?: string;
    caption?: string;
  }>;
  keyPoints: string[];
};

export type QuizQuestion = {
  id: string;
  type: "multipleChoice" | "shortAnswer" | "matching" | "dragDrop";
  question: string;
  options?: string[];
  correctAnswer?: string | string[];
  matchPairs?: Array<{ left: string; right: string }>;
  hint?: string;
  topic: string;
};

export type UnitQuiz = {
  slug: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
  passingScore: number;
  topics: string[];
};

export type ModuleVariant = {
  weeks: string;
  overview: string;
  lessons: string[];
  activities: string[];
  lessonContent?: Record<string, LessonContent>;
  quiz?: UnitQuiz;
};

export type AdaptiveModule = {
  slug: string;
  title: string;
  subject: Subject;
  variants: Record<GradeBand, ModuleVariant>;
};

export type ProgramModules = Record<string, { programTitle: string; intro: string; modules: AdaptiveModule[] }>;

export function bandKeyFromGrade(grade: number): GradeBand {
  if (grade <= 2) return "k2";
  if (grade <= 5) return "g3_5";
  if (grade <= 8) return "g6_8";
  if (grade <= 10) return "g9_10";
  return "g11_12";
}

export const modulesData: ProgramModules = {
  "skills-lab": {
    programTitle: "Skills Lab",
    intro: "Adaptive, practice‑focused modules across Math, Reading, and Science. Content adjusts to your grade level with accessible, keyboard‑first design.",
    modules: [
      {
        slug: "math",
        title: "Math Pathways",
        subject: "math",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Count, compare, and add within 20 using visuals and manipulatives.",
            lessons: ["Count to 20", "Compare numbers", "Addition within 10", "Shapes and patterns"],
            activities: ["Number line hop", "Ten‑frame games", "Shape sort", "Domino addition"],
            lessonContent: {
              "count-to-20": {
                slug: "count-to-20",
                title: "Count to 20",
                description: "Learn to count numbers 1–20 using visuals, fingers, and songs.",
                sections: [
                  {
                    type: "text",
                    content: "Counting is the foundation of all math! Today, we'll learn to count from 1 to 20. Pay attention to the number names and how we say them."
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Number line from 1 to 20 with colorful blocks",
                    caption: "A number line helps us see numbers in order."
                  },
                  {
                    type: "video",
                    content: "https://example.com/count-to-20.mp4",
                    caption: "Watch this short song about counting to 20"
                  },
                  {
                    type: "text",
                    content: "Let's try: Point to each number and say it out loud. You can use your fingers to help!"
                  },
                  {
                    type: "callout",
                    content: "💡 Tip: Counting is easier when you say the names slowly and point to each number."
                  }
                ],
                keyPoints: ["Numbers 1–20 in order", "Saying number names clearly", "Using fingers to count"]
              },
              "compare-numbers": {
                slug: "compare-numbers",
                title: "Compare Numbers",
                description: "Learn which number is bigger or smaller using visual comparisons.",
                sections: [
                  {
                    type: "text",
                    content: "Now that we can count to 20, let's compare numbers. Is 5 bigger or smaller than 8? Let's find out!"
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Two groups of objects showing 5 and 8",
                    caption: "More objects = bigger number"
                  },
                  {
                    type: "video",
                    content: "https://example.com/compare-numbers.mp4",
                    caption: "Learn the symbols > (greater than) and < (less than)"
                  },
                  {
                    type: "text",
                    content: "We use special symbols: > means 'bigger than' and < means 'smaller than'. Try it: 7 > 3 (7 is bigger than 3)"
                  },
                  {
                    type: "callout",
                    content: "🎯 Remember: The point of the symbol always points to the smaller number."
                  }
                ],
                keyPoints: ["Comparing numbers 1–20", "Using > and < symbols", "Understanding 'bigger' and 'smaller'"]
              },
              "addition-within-10": {
                slug: "addition-within-10",
                title: "Addition Within 10",
                description: "Combine groups to learn addition facts up to 10.",
                sections: [
                  {
                    type: "text",
                    content: "Addition means putting groups together! If you have 3 apples and get 2 more, how many do you have now? 3 + 2 = 5"
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Visual representation of 3 plus 2 equals 5 using dots",
                    caption: "Using dots or pictures helps us see addition"
                  },
                  {
                    type: "video",
                    content: "https://example.com/addition-within-10.mp4",
                    caption: "Watch us add using manipulatives and fingers"
                  },
                  {
                    type: "text",
                    content: "The '+' sign means 'put together'. The '=' sign shows the answer. Practice: 4 + 1 = ?, 2 + 3 = ?, 5 + 5 = ?"
                  },
                  {
                    type: "callout",
                    content: "��� Fun fact: 5 + 5 = 10. Both hands help you remember this!"
                  }
                ],
                keyPoints: ["Understanding addition", "Using the + and = signs", "Adding within 10"]
              }
            },
            quiz: {
              slug: "math-pathways-quiz",
              title: "Math Pathways Quiz",
              description: "Test your understanding of counting, comparing, and adding within 20.",
              passingScore: 70,
              topics: ["Count to 20", "Compare numbers", "Addition within 10", "Shapes and patterns"],
              questions: [
                {
                  id: "q1",
                  type: "multipleChoice",
                  question: "What number comes after 15?",
                  options: ["14", "16", "17", "15"],
                  correctAnswer: "16",
                  topic: "Count to 20",
                  hint: "Count on your fingers or number line"
                },
                {
                  id: "q2",
                  type: "multipleChoice",
                  question: "Which is bigger, 8 or 12?",
                  options: ["8", "12", "They are the same", "Can't tell"],
                  correctAnswer: "12",
                  topic: "Compare numbers",
                  hint: "Look at a number line or count"
                },
                {
                  id: "q3",
                  type: "multipleChoice",
                  question: "What is 5 + 3?",
                  options: ["6", "7", "8", "9"],
                  correctAnswer: "8",
                  topic: "Addition within 10",
                  hint: "Use fingers or a number line"
                },
                {
                  id: "q4",
                  type: "multipleChoice",
                  question: "What is 4 + 4?",
                  options: ["7", "8", "9", "10"],
                  correctAnswer: "8",
                  topic: "Addition within 10",
                  hint: "Four fingers on each hand!"
                },
                {
                  id: "q5",
                  type: "multipleChoice",
                  question: "How many sides does a square have?",
                  options: ["2", "3", "4", "5"],
                  correctAnswer: "4",
                  topic: "Shapes and patterns",
                  hint: "Count the lines around the square"
                }
              ]
            }
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Master place value, multi‑digit addition/subtraction, and intro to fractions.",
            lessons: ["Place value to 1,000", "Add/subtract multi‑digit", "Intro fractions", "Area and perimeter"],
            activities: ["Base‑ten block build", "Open number line", "Fraction strips", "Design a floor plan"],
            lessonContent: {
              "place-value": {
                slug: "place-value",
                title: "Place Value to 1,000",
                description: "Understand hundreds, tens, and ones in numbers up to 1,000.",
                sections: [
                  {
                    type: "text",
                    content: "In the number 347, each digit has a different job. The 3 is in the hundreds place, the 4 is in the tens place, and the 7 is in the ones place."
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Base-ten blocks showing 347: 3 hundreds, 4 tens, 7 ones",
                    caption: "Base-ten blocks help us visualize place value"
                  },
                  {
                    type: "video",
                    content: "https://example.com/place-value.mp4",
                    caption: "See how to break down 3-digit numbers"
                  },
                  {
                    type: "text",
                    content: "We can write this as: 347 = 300 + 40 + 7. This is called 'expanded form'."
                  },
                  {
                    type: "callout",
                    content: "💡 Tip: Remember—each place is worth 10 times more than the place to its right."
                  }
                ],
                keyPoints: ["Hundreds, tens, and ones places", "Values of each digit", "Expanded form notation"]
              },
              "add-subtract-multi-digit": {
                slug: "add-subtract-multi-digit",
                title: "Add & Subtract Multi-Digit",
                description: "Use place value to add and subtract numbers with 2–3 digits.",
                sections: [
                  {
                    type: "text",
                    content: "When we add or subtract bigger numbers, we line them up by place value. Let's add 234 + 152."
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Vertical addition showing 234 + 152 = 386 with place values aligned",
                    caption: "Line up ones, tens, and hundreds"
                  },
                  {
                    type: "video",
                    content: "https://example.com/multi-digit.mp4",
                    caption: "Watch step-by-step addition and subtraction"
                  },
                  {
                    type: "text",
                    content: "Start from the ones place. If we get 10 or more, we 'regroup' to the tens place. This is sometimes called 'carrying' or 'borrowing'."
                  },
                  {
                    type: "callout",
                    content: "⭐ Remember: Always align numbers by their place values when adding or subtracting!"
                  }
                ],
                keyPoints: ["Aligning by place value", "Regrouping/carrying", "Multi-digit addition and subtraction"]
              }
            },
            quiz: {
              slug: "math-pathways-g3-5-quiz",
              title: "Math Pathways Quiz",
              description: "Test your understanding of place value, multi-digit operations, and fractions.",
              passingScore: 70,
              topics: ["Place value to 1,000", "Add/subtract multi‑digit", "Intro fractions", "Area and perimeter"],
              questions: [
                {
                  id: "q1",
                  type: "multipleChoice",
                  question: "What is the value of the 5 in 567?",
                  options: ["5", "50", "500", "5000"],
                  correctAnswer: "500",
                  topic: "Place value to 1,000",
                  hint: "The 5 is in the hundreds place"
                },
                {
                  id: "q2",
                  type: "multipleChoice",
                  question: "Solve: 234 + 158 = ?",
                  options: ["376", "382", "392", "402"],
                  correctAnswer: "392",
                  topic: "Add/subtract multi‑digit",
                  hint: "Align by place value and add from right to left"
                },
                {
                  id: "q3",
                  type: "multipleChoice",
                  question: "Which fraction represents half?",
                  options: ["1/4", "1/3", "1/2", "2/2"],
                  correctAnswer: "1/2",
                  topic: "Intro fractions"
                },
                {
                  id: "q4",
                  type: "multipleChoice",
                  question: "What is the area of a rectangle 4 units long and 3 units wide?",
                  options: ["7 square units", "12 square units", "14 square units", "24 square units"],
                  correctAnswer: "12 square units",
                  topic: "Area and perimeter",
                  hint: "Area = length × width"
                },
                {
                  id: "q5",
                  type: "multipleChoice",
                  question: "Which digit is in the tens place in 348?",
                  options: ["3", "4", "8", "48"],
                  correctAnswer: "4",
                  topic: "Place value to 1,000"
                }
              ]
            }
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Fluency with ratios, fractions/decimals/percents, integers, and expressions.",
            lessons: ["Ratios & unit rate", "Operations with integers", "Percents", "Evaluate expressions"],
            activities: ["Recipe scaling", "Integer walk", "Discount shopping", "Expression match"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Linear relationships: slope, graphs, and systems. Foundations for algebra.",
            lessons: ["Slope & rate of change", "Graph y = mx + b", "Solve linear equations", "Systems of equations"],
            activities: ["Staircase slope", "Graphing lab", "Balance scale algebra", "Substitution/Elimination"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Quadratics, exponentials, and data modeling. College/career readiness.",
            lessons: ["Quadratic forms", "Factoring & zeros", "Exponentials & logs (intro)", "Fit a model to data"],
            activities: ["Projectile lab", "Zero finder", "Growth/decay explorer", "Regression with spreadsheets"],
          },
        },
      },
      {
        slug: "reading",
        title: "Reading Steps",
        subject: "reading",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Phonemic awareness, decoding CVC words, and reading simple sentences.",
            lessons: ["Letter‑sound blends", "CVC decoding", "Sight words", "Read & retell"],
            activities: ["Sound boxes", "Word building tiles", "High‑frequency bingo", "Story sequence cards"],
            lessonContent: {
              "letter-sound-blends": {
                slug: "letter-sound-blends",
                title: "Letter-Sound Blends",
                description: "Learn how sounds blend together to make words.",
                sections: [
                  {
                    type: "text",
                    content: "When two letter sounds blend together, they make a new sound! Like 'bl' in 'blue' or 'st' in 'stop'. Let's practice listening to and saying blends."
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "Pictures of blends: blue, stop, smile, play",
                    caption: "Blends appear at the beginning of these words"
                  },
                  {
                    type: "video",
                    content: "https://example.com/blends.mp4",
                    caption: "Watch and listen to common blends"
                  },
                  {
                    type: "text",
                    content: "Try saying these blends: bl, st, sm, sp, tr, gr. Now listen as I show you words with these blends."
                  },
                  {
                    type: "callout",
                    content: "🎵 Tip: Blends sound different from digraphs. A blend keeps both sounds, but a digraph makes one new sound!"
                  }
                ],
                keyPoints: ["Identifying blends (bl, st, sm, sp, tr, gr)", "Blending sounds to read words", "Hearing the difference between blends and digraphs"]
              },
              "cvc-decoding": {
                slug: "cvc-decoding",
                title: "CVC Decoding",
                description: "Sound out consonant-vowel-consonant words like cat, sit, and dog.",
                sections: [
                  {
                    type: "text",
                    content: "CVC stands for Consonant-Vowel-Consonant. These are simple words with three letters. Examples: cat, sit, dog, run, hot. Let's learn to read them by sounding out each letter."
                  },
                  {
                    type: "image",
                    content: "/placeholder.svg",
                    alt: "CVC word examples: cat, sit, dog, run with sound markings",
                    caption: "Sound out each letter to read the word"
                  },
                  {
                    type: "video",
                    content: "https://example.com/cvc.mp4",
                    caption: "Watch how to blend sounds to read CVC words"
                  },
                  {
                    type: "text",
                    content: "Remember: Sound out each letter, then blend them together quickly. /c/ /a/ /t/ = cat!"
                  },
                  {
                    type: "callout",
                    content: "⭐ Practice: Try these—what words do you make? /m/ /a/ /t/ and /p/ /i/ /g/"
                  }
                ],
                keyPoints: ["Understanding CVC pattern (C-V-C)", "Sounding out each letter", "Blending sounds to read words"]
              }
            },
            quiz: {
              slug: "reading-steps-k2-quiz",
              title: "Reading Steps Quiz",
              description: "Test your phonemic awareness and word decoding skills.",
              passingScore: 70,
              topics: ["Letter‑sound blends", "CVC decoding", "Sight words", "Read & retell"],
              questions: [
                {
                  id: "q1",
                  type: "multipleChoice",
                  question: "What letters are in the blend at the start of 'blue'?",
                  options: ["b and l", "bl and u", "blue all together", "b and e"],
                  correctAnswer: "b and l",
                  topic: "Letter‑sound blends",
                  hint: "Listen: /b/ /l/ - blue"
                },
                {
                  id: "q2",
                  type: "multipleChoice",
                  question: "What word matches these sounds: /c/ /a/ /t/?",
                  options: ["car", "cat", "cut", "coat"],
                  correctAnswer: "cat",
                  topic: "CVC decoding"
                },
                {
                  id: "q3",
                  type: "multipleChoice",
                  question: "Which is a sight word (a word we just remember)?",
                  options: ["cat", "the", "dog", "sit"],
                  correctAnswer: "the",
                  topic: "Sight words",
                  hint: "Sight words are very common and we don't sound them out"
                },
                {
                  id: "q4",
                  type: "multipleChoice",
                  question: "What do you do after reading a story?",
                  options: ["Sleep", "Retell it in your own words", "Forget it", "Draw only"],
                  correctAnswer: "Retell it in your own words",
                  topic: "Read & retell"
                },
                {
                  id: "q5",
                  type: "multipleChoice",
                  question: "What word matches these sounds: /s/ /i/ /t/?",
                  options: ["sit", "sat", "set", "sit down"],
                  correctAnswer: "sit",
                  topic: "CVC decoding"
                }
              ]
            }
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Fluent reading with main idea, detail, and vocabulary strategies.",
            lessons: ["Main idea & details", "Context clues", "Summarize paragraphs", "Compare/contrast"],
            activities: ["Highlight the gist", "Word detective", "Somebody‑Wanted‑But‑So‑Then", "Venn diagram"],
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Analyze structure, purpose, and claims across literary and informational texts.",
            lessons: ["Text structure", "Author’s purpose", "Citing evidence", "Strong summary"],
            activities: ["Signal‑word hunt", "Purpose sort", "Quote���and‑explain", "Summary checklist"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Rhetorical analysis, tone, and evaluating arguments with credible evidence.",
            lessons: ["Rhetorical appeals", "Tone & diction", "Evaluate sources", "Counterclaims"],
            activities: ["Ethos/Pathos/Logos map", "Tone shift tracker", "Source reliability rubric", "Claim‑evidence��reasoning"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Synthesize multiple texts and craft clear, well‑supported analyses.",
            lessons: ["Synthesis strategies", "Integrate quotations", "Academic vocabulary", "Timed analysis"],
            activities: ["Two‑text matrix", "Quote sandwich", "Vocabulary notebook", "Practice prompt"],
          },
        },
      },
      {
        slug: "science",
        title: "Science Inquiry",
        subject: "science",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Observe weather, plants, and pushes/pulls with hands‑on investigations.",
            lessons: ["Observe & record", "Living vs. nonliving", "Weather patterns", "Pushes & pulls"],
            activities: ["Nature journal", "Sort station", "Daily weather chart", "Ramp and motion"],
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Ecosystems, simple machines, and scientific method with fair tests.",
            lessons: ["Habitats & food chains", "Simple machines", "States of matter", "Plan an investigation"],
            activities: ["Food web build", "Machine hunt", "Matter stations", "Test & data table"],
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Atoms, energy transfer, and Earth systems with data interpretation.",
            lessons: ["Atomic model", "Energy flow", "Plate tectonics", "Read graphs & tables"],
            activities: ["Build an atom", "Thermal transfer demo", "Plate boundary map", "Graph‑to‑claim"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Biology, chemistry, and physics foundations with quantitative lab skills.",
            lessons: ["Cell structure & function", "Chemical reactions", "Forces & motion", "Experimental design"],
            activities: ["Cell model", "Reaction rate lab", "Motion tracker", "Variable control plan"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Systems thinking, genetics, and data modeling across scientific domains.",
            lessons: ["Feedback systems", "Genetics & heredity", "Stoichiometry (intro)", "Model with data"],
            activities: ["System diagram", "Punnett squares", "Conservation of mass", "Best‑fit analysis"],
          },
        },
      },
    ],
  },
  "career-pathways": {
    programTitle: "Career Pathways",
    intro: "Project‑based modules aligned to Math, Reading, and Science skills used in real jobs. Levels adapt from K–2 through 11–12.",
    modules: [
      {
        slug: "math",
        title: "Math Pathways",
        subject: "math",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Count money and read simple schedules to support daily routines.",
            lessons: ["Coins & values", "Count by 5s & 10s", "Read a picture schedule", "Add within 20"],
            activities: ["Mock store", "Skip‑count songs", "Daily routine board", "Receipt totals"],
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Apply place value and operations to timecards and budgets.",
            lessons: ["Add/subtract with regrouping", "Elapsed time", "Intro multiplication", "Budget a project"],
            activities: ["Timecard math", "Timeline puzzles", "Array build", "Plan a party cost"],
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Ratios, percents, and integer operations in workplace contexts.",
            lessons: ["Unit price compare", "Discounts & tax", "Temperatures below zero", "Intro linear patterns"],
            activities: ["Grocery unit‑rate", "Sale flyer math", "Weather log", "Table to graph"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Linear modeling and systems for planning and logistics.",
            lessons: ["Slope as rate", "Linear models", "Two‑variable equations", "Systems to plan"],
            activities: ["Delivery route rate", "Budget vs. cost line", "Constraint table", "Intersect to decide"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Quadratics and exponentials for forecasting and analysis.",
            lessons: ["Quadratic models", "Exponential growth/decay", "Analyze residuals", "Optimize with graphs"],
            activities: ["Height vs. time lab", "Inventory growth", "Residual plot", "Profit window"],
          },
        },
      },
      {
        slug: "reading",
        title: "Reading Steps",
        subject: "reading",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Decode workplace words and follow picture‑supported directions.",
            lessons: ["Read labels", "Safety words", "Short instructions", "Retell steps"],
            activities: ["Label match", "Safety sign walk", "Sequence cards", "Explain the task"],
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Read short articles and identify the main idea and key steps.",
            lessons: ["Main idea", "Text features", "Follow procedures", "Glossary words"],
            activities: ["Headline‑to‑idea", "Diagram hunt", "Recipe/procedure", "Word wall"],
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Evaluate instructions and summarize accurately with evidence.",
            lessons: ["Purpose & audience", "Signal words", "Paraphrase & cite", "Objective summary"],
            activities: ["Audience sort", "Signal‑word map", "Quote‑and‑paraphrase", "Summary rubric"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Compare sources, assess credibility, and synthesize instructions.",
            lessons: ["Source reliability", "Compare procedures", "Conflicting info", "Synthesize steps"],
            activities: ["CRAAP check", "Procedure Venn", "Resolve conflict", "Combined checklist"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Analyze technical texts and craft clear summaries for teams.",
            lessons: ["Technical vocabulary", "Interpret charts", "Summarize precisely", "Peer review"],
            activities: ["Term map", "Chart reading", "Executive summary", "Review protocol"],
          },
        },
      },
      {
        slug: "science",
        title: "Science Inquiry",
        subject: "science",
        variants: {
          k2: {
            weeks: "Weeks 1–6",
            overview: "Observe materials and weather to inform simple choices at work and home.",
            lessons: ["Solid vs. liquid", "Warm vs. cool days", "Safe tools", "Ask & observe"],
            activities: ["Sort station", "Clothing choice chart", "Tool match", "Observation notebook"],
          },
          g3_5: {
            weeks: "Weeks 1–8",
            overview: "Use data tables and fair tests to make conclusions.",
            lessons: ["Measure & record", "Fair test", "Make a claim", "Share results"],
            activities: ["Data table build", "Variable control", "Claim‑evidence", "Poster share"],
          },
          g6_8: {
            weeks: "Weeks 1–8",
            overview: "Model systems and interpret data to support decisions.",
            lessons: ["Inputs/outputs", "Graph types", "Trends & anomalies", "Evidence‑based decision"],
            activities: ["System diagram", "Graph match", "Trend talk", "Decision brief"],
          },
          g9_10: {
            weeks: "Weeks 1–8",
            overview: "Plan and analyze investigations with appropriate precision.",
            lessons: ["Operational definitions", "Accuracy vs. precision", "Error analysis", "Conclude & justify"],
            activities: ["Define & measure", "Precision lab", "Percent error", "Justification write‑up"],
          },
          g11_12: {
            weeks: "Weeks 1–8",
            overview: "Synthesize evidence across domains and communicate to stakeholders.",
            lessons: ["Cross‑domain reasoning", "Uncertainty", "Model selection", "Stakeholder summary"],
            activities: ["Multi‑source matrix", "Confidence bands", "Model compare", "Executive brief"],
          },
        },
      },
    ],
  },
};

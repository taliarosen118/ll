import { useMemo } from "react";
import { modulesData } from "./modulesData";
import { getGradeLevels } from "@/lib/placement";
import { getStudent } from "@/lib/progress";
import { Link } from "react-router-dom";

interface TopicMastery {
  topic: string;
  module: string;
  program: string;
  masteryPercent: number;
  status: "notStarted" | "inProgress" | "mastered";
}

export default function KnowledgeMap() {
  const student = getStudent();
  const levels = getGradeLevels();

  const topicMastery = useMemo(() => {
    if (!student) return [];

    const topics: TopicMastery[] = [];

    // Iterate through all programs and modules to calculate mastery
    Object.entries(modulesData).forEach(([programSlug, program]) => {
      program.modules.forEach((mod) => {
        // For each module, create a topic entry
        const masteryPercent = Math.random() * 100; // This would be calculated from actual progress data
        const status: TopicMastery["status"] =
          masteryPercent === 0
            ? "notStarted"
            : masteryPercent >= 80
              ? "mastered"
              : "inProgress";

        topics.push({
          topic: mod.title,
          module: mod.slug,
          program: programSlug,
          masteryPercent: Math.round(masteryPercent),
          status,
        });
      });
    });

    return topics;
  }, [student]);

  const masteryStats = useMemo(() => {
    const total = topicMastery.length;
    const mastered = topicMastery.filter((t) => t.status === "mastered").length;
    const inProgress = topicMastery.filter((t) => t.status === "inProgress").length;

    return {
      total,
      mastered,
      inProgress,
      notStarted: total - mastered - inProgress,
      overallPercent: Math.round((mastered / total) * 100) || 0,
    };
  }, [topicMastery]);

  const groupedByProgram = useMemo(() => {
    const groups: Record<string, TopicMastery[]> = {};
    topicMastery.forEach((topic) => {
      if (!groups[topic.program]) {
        groups[topic.program] = [];
      }
      groups[topic.program].push(topic);
    });
    return groups;
  }, [topicMastery]);

  if (!student) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-muted-foreground">Please log in to view your knowledge map.</p>
        <div className="mt-4 text-center">
          <Link to="/login" className="inline-block rounded-md border px-4 py-2 hover:bg-accent hover:text-accent-foreground">
            Log In
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Your Learning Map</h1>
        <p className="text-muted-foreground">Track your mastery across all topics and skills.</p>
      </div>

      {/* Mastery Overview */}
      <div className="grid gap-4 md:grid-cols-5 mb-8">
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground mb-1">Overall Mastery</p>
          <p className="text-3xl font-bold text-accent">{masteryStats.overallPercent}%</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground mb-1">Mastered Topics</p>
          <p className="text-3xl font-bold text-green-600">{masteryStats.mastered}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground mb-1">In Progress</p>
          <p className="text-3xl font-bold text-blue-600">{masteryStats.inProgress}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground mb-1">Not Started</p>
          <p className="text-3xl font-bold text-gray-600">{masteryStats.notStarted}</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <p className="text-sm text-muted-foreground mb-1">Total Topics</p>
          <p className="text-3xl font-bold">{masteryStats.total}</p>
        </div>
      </div>

      {/* Mastery Pie Chart Representation */}
      <div className="mb-8 rounded-lg border bg-card p-6">
        <h2 className="text-lg font-semibold mb-4">Mastery Distribution</h2>
        <div className="flex items-center gap-8">
          <div className="flex-1">
            <div className="relative w-40 h-40 mx-auto">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle cx="50" cy="50" r="40" fill="none" stroke="#e5e7eb" strokeWidth="8" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="8"
                  strokeDasharray={`${(masteryStats.mastered / masteryStats.total) * 251.2} 251.2`}
                  strokeLinecap="round"
                  transform="rotate(-90 50 50)"
                />
                <text x="50" y="55" textAnchor="middle" className="text-sm font-bold fill-current">
                  {masteryStats.overallPercent}%
                </text>
              </svg>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-600" />
              <span className="text-sm">Mastered: {masteryStats.mastered} topics</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-600" />
              <span className="text-sm">In Progress: {masteryStats.inProgress} topics</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-gray-400" />
              <span className="text-sm">Not Started: {masteryStats.notStarted} topics</span>
            </div>
          </div>
        </div>
      </div>

      {/* Topics by Program */}
      {Object.entries(groupedByProgram).map(([programSlug, topics]) => {
        const programData = modulesData[programSlug];
        if (!programData) return null;

        return (
          <div key={programSlug} className="mb-8">
            <h2 className="text-xl font-semibold mb-4">{programData.programTitle}</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {topics.map((topic) => (
                <Link
                  key={`${topic.program}-${topic.module}`}
                  to={`/programs/${topic.program}/modules/${topic.module}`}
                  className="rounded-lg border bg-card p-4 hover:shadow-md hover:border-accent transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold">{topic.topic}</h3>
                    {topic.status === "mastered" && <span className="text-lg">✓</span>}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Mastery</span>
                      <span className="font-semibold">{topic.masteryPercent}%</span>
                    </div>

                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          topic.status === "mastered"
                            ? "bg-green-600"
                            : topic.status === "inProgress"
                              ? "bg-blue-600"
                              : "bg-gray-400"
                        }`}
                        style={{ width: `${topic.masteryPercent}%` }}
                      />
                    </div>

                    <p className="text-xs text-muted-foreground pt-1">
                      {topic.status === "mastered" && "Mastered"}
                      {topic.status === "inProgress" && "In Progress"}
                      {topic.status === "notStarted" && "Not Started"}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        );
      })}

      {/* Recommended Next Steps */}
      <div className="mt-8 rounded-lg border bg-blue-50 p-6">
        <h2 className="font-semibold text-blue-900 mb-3">📚 Recommended Next Steps</h2>
        <p className="text-sm text-blue-800 mb-4">
          Based on your current progress, we recommend focusing on:
        </p>
        <ul className="space-y-2">
          {topicMastery
            .filter((t) => t.status === "inProgress")
            .slice(0, 3)
            .map((topic) => (
              <li key={`${topic.program}-${topic.module}`} className="text-sm text-blue-800">
                <span className="font-medium">→ {topic.topic}</span> (Currently {topic.masteryPercent}% complete)
              </li>
            ))}
          {topicMastery
            .filter((t) => t.status === "notStarted")
            .slice(0, Math.max(0, 3 - topicMastery.filter((t) => t.status === "inProgress").slice(0, 3).length))
            .map((topic) => (
              <li key={`${topic.program}-${topic.module}`} className="text-sm text-blue-800">
                <span className="font-medium">→ Start with {topic.topic}</span> (Not yet started)
              </li>
            ))}
        </ul>
      </div>

      {/* Learning Stats */}
      <div className="mt-8 rounded-lg border bg-card p-6">
        <h2 className="font-semibold mb-4">Your Learning Stats</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="text-center p-4 rounded border">
            <p className="text-3xl font-bold text-accent">{Math.floor(Math.random() * 50) + 10}</p>
            <p className="text-sm text-muted-foreground mt-2">Hours Spent Learning</p>
          </div>
          <div className="text-center p-4 rounded border">
            <p className="text-3xl font-bold text-accent">{Math.floor(Math.random() * 30) + 5}</p>
            <p className="text-sm text-muted-foreground mt-2">Quizzes Completed</p>
          </div>
          <div className="text-center p-4 rounded border">
            <p className="text-3xl font-bold text-accent">{Math.floor(Math.random() * 15) + 3}</p>
            <p className="text-sm text-muted-foreground mt-2">Day Streak</p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link, useParams } from "react-router-dom";
import { modulesData, bandKeyFromGrade, AdaptiveModule } from "./modulesData";
import { useEffect, useMemo, useState } from "react";
import { logEvent } from "@/lib/progress";
import AudioWithCaptions from "@/components/lessons/AudioWithCaptions";
import { getGradeLevels, gradeClusterLabel } from "@/lib/placement";
import { ensureModuleProgress, getModuleProgress, recommendProgressCheck, toggleLesson, ensurePractice, recordPracticeAttempt, practiceStats, saveQuizResult, getQuizResult } from "@/lib/moduleProgress";
import ProgressCheck from "@/components/lessons/ProgressCheck";
import { buildPracticePlan } from "@/lib/practice";
import Quiz, { QuizResult } from "@/components/quiz/Quiz";
import QuizResults from "@/components/quiz/QuizResults";

function gradeForSubject(subj: AdaptiveModule["subject"], levels: { grade: number; mathGrade: number; readingGrade: number }) {
  if (subj === "math") return levels.mathGrade;
  if (subj === "reading") return levels.readingGrade;
  return levels.grade;
}

export default function ProgramModuleDetail() {
  const { program, module: moduleSlug } = useParams();
  const data = (program && modulesData[program]) || null;
  const mod = data?.modules.find((m) => m.slug === moduleSlug);

  useEffect(() => {
    if (program && moduleSlug) logEvent("view_module", { program, module: moduleSlug });
  }, [program, moduleSlug]);

  // Progress state
  const [, force] = useState(0);
  useEffect(() => { if (program && moduleSlug) { ensureModuleProgress(program, moduleSlug); force((v) => v + 1); } }, [program, moduleSlug]);
  const progress = useMemo(() => (program && moduleSlug ? getModuleProgress(program, moduleSlug) : null), [program, moduleSlug]);
  const completedCount = progress?.completedLessons.length || 0;
  const checksCount = progress?.progressChecks.length || 0;
  const [showCheck, setShowCheck] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);
  const savedQuizResult = useMemo(() => (program && moduleSlug ? getQuizResult(program, moduleSlug) : null), [program, moduleSlug]);

  // Grade-based difficulty banner
  const levels = getGradeLevels();
  const overallLabel = `${gradeClusterLabel(levels.grade)} • Math: ${gradeClusterLabel(levels.mathGrade)} • Reading: ${gradeClusterLabel(levels.readingGrade)}`;

  if (!data || !mod) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-sm text-muted-foreground">Module not found.</p>
        <Link className="underline" to="/">Back home</Link>
      </div>
    );
  }

  const g = gradeForSubject(mod.subject, levels);
  const band = bandKeyFromGrade(g);
  const v = mod.variants[band];
  const levelLabel = gradeClusterLabel(g);

  // Practice plan and tracking
  const plan = buildPracticePlan(mod, band);
  useEffect(() => {
    if (!program || !moduleSlug) return;
    const counts = plan.map(w => w.items.length);
    ensurePractice(program, moduleSlug, band, counts);
    force((x) => x + 1);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [program, moduleSlug, band, v.lessons.join("|"), v.activities.join("|")]);
  const pstats = useMemo(() => (program && moduleSlug ? practiceStats(program, moduleSlug) : null), [program, moduleSlug, progress?.practice]);

  return (
    <div className="container mx-auto px-4 py-12">
      <Link to={`/programs/${program}/modules`} className="text-sm underline">← Back to modules</Link>
      <header className="mt-2 mb-6">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-3xl font-bold">{mod.title}</h1>
          <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
            <span className="rounded-md border px-2 py-0.5 capitalize">{mod.subject}</span>
            <span className="rounded-md border px-2 py-0.5">{levelLabel}</span>
          </span>
        </div>
        <p className="mt-1 text-muted-foreground">{data.programTitle} • {v.weeks}</p>
        <p className="mt-2 text-muted-foreground">{v.overview}</p>
        <div className="mt-3 rounded-md border bg-secondary px-3 py-2 text-sm">Recommended level: {overallLabel}</div>
        {pstats && (
          <div className="mt-2 text-xs text-muted-foreground">Practice progress: {pstats.completed}/{pstats.total} items completed</div>
        )}
      </header>

      <AudioWithCaptions
        title={`${data.programTitle} — ${mod.title}`}
        paragraphs={[
          v.overview,
          `Lessons: ${v.lessons.join(", ")}.`,
          `Activities: ${v.activities.join(", ")}.`,
        ]}
      />

      <section className="mt-6">
        <h2 className="text-xl font-semibold mb-4">Lessons</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {v.lessons.map((l, i) => {
            const lessonSlug = l.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
            const isCompleted = progress?.completedLessons.includes(i) || false;
            const hasContent = v.lessonContent?.[lessonSlug];
            return (
              <div key={i} className="rounded-lg border bg-card p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <h3 className="font-semibold text-base">{l}</h3>
                  <input
                    type="checkbox"
                    checked={isCompleted}
                    onChange={() => { if (program && moduleSlug) { toggleLesson(program, moduleSlug, i); force((vv) => vv + 1); } }}
                    aria-label={`Mark lesson ${i + 1} complete`}
                    className="mt-1"
                  />
                </div>
                {hasContent && (
                  <>
                    <p className="text-sm text-muted-foreground mb-3">{v.lessonContent[lessonSlug].description}</p>
                    <Link
                      to={`/programs/${program}/modules/${moduleSlug}/lessons/${lessonSlug}`}
                      className="inline-block text-sm rounded-md border px-3 py-1 hover:bg-accent hover:text-accent-foreground"
                    >
                      Start Lesson →
                    </Link>
                  </>
                )}
                {!hasContent && (
                  <p className="text-xs text-muted-foreground italic">Content coming soon</p>
                )}
                <div className="mt-3 text-xs text-muted-foreground">
                  {isCompleted && <span className="inline-block rounded-md bg-green-100 px-2 py-1 text-green-800">Completed</span>}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Activities</h2>
        <ul className="ml-5 mt-2 list-disc space-y-1 text-sm text-muted-foreground">
          {v.activities.map((a, i) => <li key={i}>{a}</li>)}
        </ul>

        {recommendProgressCheck(v.lessons.length, completedCount, checksCount) && !showCheck && (
          <div className="mt-4 rounded-md border bg-card p-3">
            <p className="text-sm">Progress check is recommended now (to keep it gentle, it looks like a normal lesson).</p>
            <div className="mt-2 flex gap-2 text-sm">
              <button className="rounded-md border px-3 py-1 hover:bg-accent hover:text-accent-foreground" onClick={() => setShowCheck(true)}>Take now</button>
              <button className="rounded-md border px-3 py-1" onClick={() => setShowCheck(false)}>Study more</button>
            </div>
          </div>
        )}

        {showCheck && (
          <div className="mt-4">
            <ProgressCheck program={program!} moduleSlug={moduleSlug!} lessons={v.lessons} />
          </div>
        )}
      </section>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Practice (Trackable)</h2>
        <div className="mt-2 grid gap-3">
          {plan.map((week, wi) => (
            <div key={wi} className="rounded-lg border bg-card p-3">
              <div className="flex items-center justify-between">
                <p className="font-medium">{week.title}</p>
              </div>
              <ul className="mt-2 space-y-2">
                {week.items.map((it, ii) => {
                  const rec = progress?.practice?.weeks?.[wi]?.items?.[ii];
                  const attempts = rec?.attempts || 0;
                  const correct = rec?.correct || 0;
                  const done = correct >= it.minCorrect;
                  return (
                    <li key={ii} className="rounded-md border p-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm"><span className="font-medium">{it.target}:</span> {it.prompt}</p>
                          <p className="mt-1 text-xs text-muted-foreground">Goal: {it.minCorrect} correct • You: {correct}/{it.minCorrect} (Attempts: {attempts})</p>
                        </div>
                        <div className="flex gap-2 text-xs">
                          <button className="rounded-md border px-2 py-1" onClick={() => { if (program && moduleSlug) { recordPracticeAttempt(program, moduleSlug, band, wi, ii, false); force((x)=>x+1); } }}>Try again</button>
                          <button className="rounded-md border px-2 py-1 hover:bg-accent hover:text-accent-foreground" onClick={() => { if (program && moduleSlug) { recordPracticeAttempt(program, moduleSlug, band, wi, ii, true); force((x)=>x+1); } }} disabled={done} aria-disabled={done}>{done ? "Completed" : "Mark correct"}</button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {v.quiz && (
        <section className="mt-8">
          {showQuiz && quizResult ? (
            <div className="rounded-lg border bg-card p-6">
              <h2 className="text-xl font-semibold mb-6">Quiz Results</h2>
              <QuizResults
                result={quizResult}
                onRetake={() => { setQuizResult(null); setShowQuiz(true); }}
                onClose={() => { setShowQuiz(false); }}
              />
            </div>
          ) : showQuiz && !quizResult ? (
            <Quiz
              quiz={v.quiz}
              onComplete={(result) => {
                setQuizResult(result);
                if (program && moduleSlug) {
                  saveQuizResult(program, moduleSlug, result);
                }
              }}
              onCancel={() => setShowQuiz(false)}
            />
          ) : (
            <div className="rounded-lg border bg-card p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-xl font-semibold mb-2">{v.quiz.title}</h2>
                  <p className="text-sm text-muted-foreground mb-4">{v.quiz.description}</p>
                  {savedQuizResult && (
                    <div className="mb-4 rounded-md bg-blue-50 p-3">
                      <p className="text-sm font-medium text-blue-900">
                        Last attempt: {Math.round(new Date(savedQuizResult.timestamp).getTime() / 1000) > 0 ? new Date(savedQuizResult.timestamp).toLocaleDateString() : "Recently"}
                      </p>
                      <p className="text-sm text-blue-800">Score: {savedQuizResult.score}% {savedQuizResult.passed && "✓"}</p>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => setShowQuiz(true)}
                  className="shrink-0 rounded-md border px-4 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
                >
                  {savedQuizResult ? "Retake Quiz" : "Start Quiz"}
                </button>
              </div>
            </div>
          )}
        </section>
      )}

      <div className="mt-8">
        <button className="rounded-md border px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground" onClick={() => logEvent("complete_module", { program, module: moduleSlug })}>
          Mark module as completed
        </button>
      </div>
    </div>
  );
}

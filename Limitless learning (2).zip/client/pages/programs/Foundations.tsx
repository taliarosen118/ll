import { Link } from "react-router-dom";

export default function Foundations() {
  return (
    <div className="container mx-auto px-4 py-12">
      <Link to="/#programs" className="text-sm underline">← Back to programs</Link>
      <header className="mt-4 mb-6">
        <h1 className="text-3xl font-bold">Foundations — Subject Overview</h1>
        <p className="mt-2 text-muted-foreground">A 36-week program focused on communication, numeracy, life skills, social-emotional learning, and creativity tailored for learners needing foundational supports.</p>
        <p className="mt-3"><Link className="underline" to="/programs/foundations/modules">View modules</Link></p>
      </header>

      <section className="grid gap-8">
        <article>
          <h2 className="text-2xl font-semibold">Subject 1: Communication & Literacy</h2>
          <p className="mt-2 text-sm text-muted-foreground font-semibold">Goals</p>
          <ul className="list-disc ml-6">
            <li>Improve receptive and expressive communication</li>
            <li>Develop functional reading & writing skills</li>
          </ul>

          <h3 className="mt-3 font-semibold">Units & Sample Activities</h3>
          <div className="mt-2 grid gap-3">
            <div className="rounded-md border bg-card p-3">
              <strong>Letters & Sounds (Weeks 1–6)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Match letters with pictures (A → Apple).</li>
                <li>Phonics songs and tracing letters.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Sight Words & Picture Reading (Weeks 7–12)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Flashcards for common words (stop, mom, cat).</li>
                <li>Match words to symbols/pictures.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Functional Literacy (Weeks 13–24)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Reading signs (EXIT, STOP).</li>
                <li>Writing names, simple sentences.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Storytelling & Expression (Weeks 25–36)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Shared reading with visuals.</li>
                <li>Roleplay stories with puppets.</li>
              </ul>
            </div>
          </div>
        </article>

        <article>
          <h2 className="text-2xl font-semibold">Subject 2: Numeracy</h2>
          <p className="mt-2 text-sm text-muted-foreground font-semibold">Goals</p>
          <ul className="list-disc ml-6">
            <li>Develop number sense & real-life math skills</li>
          </ul>

          <h3 className="mt-3 font-semibold">Units & Sample Activities</h3>
          <div className="mt-2 grid gap-3">
            <div className="rounded-md border bg-card p-3">
              <strong>Counting & Number Recognition (Weeks 1–6)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Count objects, clapping games.</li>
                <li>Number matching puzzles.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Shapes & Patterns (Weeks 7–12)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Sorting blocks by color/shape.</li>
                <li>Making patterns with beads.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Money & Time (Weeks 13–24)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Play store with pretend coins.</li>
                <li>Reading clocks (hour & half-hour).</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Measurement & Calendar (Weeks 25–36)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Measure ingredients while cooking.</li>
                <li>Mark birthdays/events on a calendar.</li>
              </ul>
            </div>
          </div>
        </article>

        <article>
          <h2 className="text-2xl font-semibold">Subject 3: Life Skills</h2>
          <p className="mt-2 text-sm text-muted-foreground font-semibold">Goals</p>
          <ul className="list-disc ml-6">
            <li>Build independence in daily living</li>
          </ul>

          <h3 className="mt-3 font-semibold">Units & Sample Activities</h3>
          <div className="mt-2 grid gap-3">
            <div className="rounded-md border bg-card p-3">
              <strong>Self-Care (Weeks 1–9)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Brushing teeth routine.</li>
                <li>Dressing skills with Velcro/zippers.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Healthy Living (Weeks 10–18)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Washing hands.</li>
                <li>Simple food prep (sandwiches, fruit salad).</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Safety & Community (Weeks 19–27)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Road crossing practice.</li>
                <li>Recognizing community helpers (police, doctor).</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Chores & Responsibility (Weeks 28–36)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Sorting laundry.</li>
                <li>Cleaning table after meals.</li>
              </ul>
            </div>
          </div>
        </article>

        <article>
          <h2 className="text-2xl font-semibold">Subject 4: Social & Emotional Learning</h2>
          <p className="mt-2 text-sm text-muted-foreground font-semibold">Goals</p>
          <ul className="list-disc ml-6">
            <li>Strengthen social interaction & self-regulation</li>
          </ul>

          <h3 className="mt-3 font-semibold">Units & Sample Activities</h3>
          <div className="mt-2 grid gap-3">
            <div className="rounded-md border bg-card p-3">
              <strong>Feelings & Emotions (Weeks 1–9)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Emotion flashcards.</li>
                <li>“How do you feel today?” circle.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Friendship & Sharing (Weeks 10–18)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Group games (taking turns).</li>
                <li>Cooperative art projects.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Coping & Calm Down (Weeks 19–27)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Breathing exercises.</li>
                <li>Quiet corner with sensory tools.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Community & Celebrations (Weeks 28–36)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Celebrating holidays/cultural events.</li>
                <li>Group projects.</li>
              </ul>
            </div>
          </div>
        </article>

        <article>
          <h2 className="text-2xl font-semibold">Subject 5: Creativity & Motor Skills</h2>
          <p className="mt-2 text-sm text-muted-foreground font-semibold">Goals</p>
          <ul className="list-disc ml-6">
            <li>Express creativity and improve fine/gross motor control</li>
          </ul>

          <h3 className="mt-3 font-semibold">Units & Sample Activities</h3>
          <div className="mt-2 grid gap-3">
            <div className="rounded-md border bg-card p-3">
              <strong>Art & Colors (Weeks 1–9)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Finger painting.</li>
                <li>Color mixing with water.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Music & Rhythm (Weeks 10–18)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Clapping patterns.</li>
                <li>Playing percussion instruments.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Movement & Play (Weeks 19–27)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Obstacle courses.</li>
                <li>Dancing with scarves.</li>
              </ul>
            </div>

            <div className="rounded-md border bg-card p-3">
              <strong>Drama & Expression (Weeks 28–36)</strong>
              <ul className="ml-6 list-disc mt-1">
                <li>Puppet theater.</li>
                <li>Acting out emotions.</li>
              </ul>
            </div>
          </div>
        </article>
      </section>
    </div>
  );
}

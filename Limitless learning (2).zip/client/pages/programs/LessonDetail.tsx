import { Link, useParams } from "react-router-dom";
import { modulesData, bandKeyFromGrade, AdaptiveModule, LessonContent } from "./modulesData";
import { useEffect, useMemo, useState } from "react";
import { logEvent } from "@/lib/progress";
import AudioWithCaptions from "@/components/lessons/AudioWithCaptions";
import { getGradeLevels, gradeClusterLabel } from "@/lib/placement";
import { getStudent } from "@/lib/progress";

function gradeForSubject(subj: AdaptiveModule["subject"], levels: { grade: number; mathGrade: number; readingGrade: number }) {
  if (subj === "math") return levels.mathGrade;
  if (subj === "reading") return levels.readingGrade;
  return levels.grade;
}

export default function ProgramLessonDetail() {
  const { program, module: moduleSlug, lesson: lessonSlug } = useParams();
  const data = (program && modulesData[program]) || null;
  const mod = data?.modules.find((m) => m.slug === moduleSlug);
  const [, setForceUpdate] = useState(0);

  useEffect(() => {
    if (program && moduleSlug && lessonSlug) {
      logEvent("view_lesson", { program, module: moduleSlug, lesson: lessonSlug });
    }
  }, [program, moduleSlug, lessonSlug]);

  const levels = getGradeLevels();
  const student = getStudent();

  if (!data || !mod) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-sm text-muted-foreground">Module not found.</p>
        <Link className="underline" to="/">Back home</Link>
      </div>
    );
  }

  const g = gradeForSubject(mod.subject, levels);
  const band = bandKeyFromGrade(g);
  const v = mod.variants[band];
  const levelLabel = gradeClusterLabel(g);

  const lessonContent = v.lessonContent?.[lessonSlug || ""];

  if (!lessonContent) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-sm text-muted-foreground">Lesson not found.</p>
        <Link className="underline" to={`/programs/${program}/modules/${moduleSlug}`}>
          ← Back to {mod.title}
        </Link>
      </div>
    );
  }

  const lessonIndex = v.lessons.findIndex((l) => l.toLowerCase().replace(/[^a-z0-9]/g, "-") === lessonSlug);

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Link to={`/programs/${program}/modules/${moduleSlug}`} className="text-sm underline">
          ← Back to {mod.title}
        </Link>
      </div>

      <header className="mb-8">
        <div className="flex items-center justify-between gap-2 mb-4">
          <h1 className="text-3xl font-bold">{lessonContent.title}</h1>
          <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
            <span className="rounded-md border px-2 py-0.5 capitalize">{mod.subject}</span>
            <span className="rounded-md border px-2 py-0.5">{levelLabel}</span>
          </span>
        </div>
        <p className="text-muted-foreground mb-3">{lessonContent.description}</p>
        <div className="rounded-md border bg-secondary px-3 py-2 text-sm">
          {data.programTitle} • {mod.title} • Lesson {lessonIndex >= 0 ? lessonIndex + 1 : "?"} of {v.lessons.length}
        </div>
      </header>

      <AudioWithCaptions
        title={`${mod.title} — ${lessonContent.title}`}
        paragraphs={[lessonContent.description, `Key points: ${lessonContent.keyPoints.join(", ")}.`]}
      />

      <div className="mt-8 max-w-4xl">
        <div className="prose prose-sm max-w-none space-y-6">
          {lessonContent.sections.map((section, idx) => {
            if (section.type === "text") {
              return (
                <p key={idx} className="text-base leading-relaxed">
                  {section.content}
                </p>
              );
            }

            if (section.type === "image") {
              return (
                <figure key={idx} className="my-6">
                  <img
                    loading="lazy"
                    srcSet="https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=100 100w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=200 200w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=400 400w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=800 800w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=1200 1200w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=1600 1600w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe?width=2000 2000w, https://cdn.builder.io/api/v1/image/assets%2F77c534726d5a474b99ed0b4b1107543f%2F3e39c55c88a54503b828b04153db98fe"
                    alt={section.alt}
                    className="w-full rounded-lg border object-cover"
                  />
                  {section.caption && (
                    <figcaption className="mt-2 text-center text-sm text-muted-foreground italic">
                      {section.caption}
                    </figcaption>
                  )}
                </figure>
              );
            }

            if (section.type === "video") {
              return (
                <figure key={idx} className="my-6">
                  <div className="rounded-lg border bg-muted p-12 text-center">
                    <div className="inline-block text-5xl">▶️</div>
                    <p className="mt-2 text-sm text-muted-foreground">[Video placeholder]</p>
                    <p className="mt-1 text-sm font-medium">Video will appear here</p>
                  </div>
                  {section.caption && (
                    <figcaption className="mt-2 text-center text-sm text-muted-foreground italic">
                      {section.caption}
                    </figcaption>
                  )}
                </figure>
              );
            }

            if (section.type === "callout") {
              return (
                <div key={idx} className="my-4 rounded-lg border-l-4 border-accent bg-accent/10 px-4 py-3 text-sm">
                  {section.content}
                </div>
              );
            }

            return null;
          })}
        </div>
      </div>

      <div className="mt-12 rounded-lg border bg-secondary p-6">
        <h2 className="font-semibold mb-3">Key Points from This Lesson:</h2>
        <ul className="list-disc ml-5 space-y-1 text-sm">
          {lessonContent.keyPoints.map((point, idx) => (
            <li key={idx} className="text-muted-foreground">{point}</li>
          ))}
        </ul>
      </div>

      <div className="mt-8 flex items-center justify-between">
        {lessonIndex > 0 && (
          <Link
            to={`/programs/${program}/modules/${moduleSlug}/lessons/${slugifyLesson(v.lessons[lessonIndex - 1])}`}
            className="rounded-md border px-4 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
          >
            ← Previous Lesson
          </Link>
        )}
        <div className="flex-1" />
        {lessonIndex < v.lessons.length - 1 && (
          <Link
            to={`/programs/${program}/modules/${moduleSlug}/lessons/${slugifyLesson(v.lessons[lessonIndex + 1])}`}
            className="rounded-md border px-4 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
          >
            Next Lesson →
          </Link>
        )}
      </div>

      {lessonIndex === v.lessons.length - 1 && (
        <div className="mt-8 text-center">
          <p className="mb-3 text-sm text-muted-foreground">You've completed this lesson!</p>
          <Link
            to={`/programs/${program}/modules/${moduleSlug}`}
            className="inline-block rounded-md border px-4 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
          >
            Return to Module
          </Link>
        </div>
      )}
    </div>
  );
}

function slugifyLesson(lesson: string): string {
  return lesson.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

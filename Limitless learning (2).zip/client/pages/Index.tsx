import { ArrowRight, Brain, Headphones, Keyboard, Languages, Sparkles, Subtitles, ZoomIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function Index() {
  return (
    <div id="top">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div data-decorative aria-hidden className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-br from-brand-50 via-white to-brand-100 dark:from-brand-950 dark:via-zinc-900 dark:to-brand-900" />
        <div className="container mx-auto px-4 py-20 md:py-28">
          <div className="mx-auto grid max-w-6xl items-center gap-10 md:grid-cols-2">
            <div>
              <p className="inline-flex items-center gap-2 rounded-full border bg-background/70 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur">
                <Sparkles className="h-3.5 w-3.5 text-brand-600" /> Inclusive by design
              </p>
              <h1 className="mt-4 text-4xl font-extrabold tracking-tight md:text-6xl">
                Limitless Learning
              </h1>
              <p className="mt-4 max-w-prose text-lg text-muted-foreground">
                An educational platform crafted for learners with disabilities. High contrast, dyslexia‑friendly fonts, captioned lessons, keyboard navigation, and more — because every mind deserves the chance to thrive.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a href="#programs">
                  <Button size="lg" className="bg-brand-600 hover:bg-brand-700">
                    Start learning <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </a>
                <a href="#accessibility">
                  <Button size="lg" variant="outline">See accessibility features</Button>
                </a>
                <Link to="/login">
                  <Button size="lg" className="rounded-[10px] h-11 px-8 md:bg-gray-100 md:text-foreground bg-white border border-transparent">Student login</Button>
                </Link>
                <Link to="/signup">
                  <Button size="lg" className="rounded-[10px] h-11 px-8 bg-brand-600 text-white md:bg-gray-100 md:text-foreground md:border md:border-transparent">New to LL? Sign up here!</Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="relative mx-auto aspect-[4/3] w-full max-w-xl overflow-hidden rounded-2xl border bg-card shadow-xl">
                <div data-decorative className="absolute inset-0 bg-gradient-to-br from-brand-200/60 to-brand-400/40 dark:from-brand-800/40 dark:to-brand-600/30" />
                <div className="relative grid h-full grid-cols-2 p-6 md:p-8">
                  <FeatureTile icon={<Headphones />} title="Audio lessons" desc="Narrated content with speed control." />
                  <FeatureTile icon={<Subtitles />} title="Captions" desc="Accurate, customizable subtitles." />
                  <FeatureTile icon={<Keyboard />} title="Keyboard-first" desc="Full navigation with shortcuts." />
                  <FeatureTile icon={<ZoomIn />} title="Zoom & resize" desc="Text scales cleanly across UI." />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-t bg-background">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold md:text-4xl">Accessibility at the core</h2>
            <p className="mt-3 text-muted-foreground">
              Built to meet WCAG 2.2 AA guidelines. Personalize the interface to your needs using the accessibility toolbar.
            </p>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Card icon={<Brain className="text-brand-600" />} title="Inclusive pedagogy" desc="Chunked lessons, plain language, predictable layouts, and progress feedback." />
            <Card icon={<Languages className="text-brand-600" />} title="Multimodal content" desc="Text, audio, and video with transcripts and sign language support." />
            <Card icon={<Headphones className="text-brand-600" />} title="Screen reader friendly" desc="Robust semantics, labels, regions, and skip links across pages." />
            <Card icon={<Keyboard className="text-brand-600" />} title="Keyboard shortcuts" desc="Navigate modules, toggle modes, and control playback without a mouse." />
            <Card icon={<Subtitles className="text-brand-600" />} title="Captions & transcripts" desc="Accurate captions and downloadable transcripts for every lesson." />
            <Card icon={<ZoomIn className="text-brand-600" />} title="Readable typography" desc="Dyslexia‑friendly mode and large text options, no layout breakage." />
          </div>
        </div>
      </section>

      {/* Programs */}
      <section id="programs" className="border-t bg-gradient-to-b from-background to-brand-50/60 dark:to-zinc-900">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold md:text-4xl">Programs for diverse learners</h2>
            <p className="mt-3 text-muted-foreground">
              Self‑paced modules designed with accessibility and mastery learning in mind.
            </p>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            <ProgramCard path="/programs/foundations" title="Foundations" desc="Learn essentials with step‑by‑step guidance and audio narration." color="from-brand-500 to-brand-700" />
            <ProgramCard path="/programs/skills-lab/modules" title="Skills Lab" desc="Interactive exercises with keyboard‑only and switch‑device support." color="from-teal-500 to-teal-700" />
            <ProgramCard path="/programs/career-pathways/modules" title="Career Pathways" desc="Project‑based learning with real‑world accommodations built‑in." color="from-amber-500 to-amber-700" />
          </div>
          <div className="mt-8 text-center">
            <Link to="/placement-quiz">
              <Button size="lg" variant="secondary">Take placement quiz</Button>
            </Link>
            <div className="mt-4">
              <a href="#contact">
                <Button size="lg" className="bg-brand-600 hover:bg-brand-700">Bring Limitless Learning to your school</Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Accessibility pledge */}
      <section id="accessibility" className="border-t bg-background">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-5xl rounded-2xl border bg-card p-8 md:p-12">
            <h3 className="text-2xl font-bold md:text-3xl">Our accessibility pledge</h3>
            <ul className="mt-6 grid gap-3 text-muted-foreground md:grid-cols-2">
              <li className="leading-relaxed"><span className="font-semibold text-foreground">Perceivable:</span> text alternatives for non‑text content and adaptable layouts.</li>
              <li className="leading-relaxed"><span className="font-semibold text-foreground">Operable:</span> keyboard navigation, logical focus order, and visible focus.</li>
              <li className="leading-relaxed"><span className="font-semibold text-foreground">Understandable:</span> consistent navigation and plain language across modules.</li>
              <li className="leading-relaxed"><span className="font-semibold text-foreground">Robust:</span> tested with assistive tech and standard semantic HTML elements.</li>
            </ul>
            <p className="mt-6 text-sm text-muted-foreground">Use the floating toolbar to toggle dark mode, high contrast, large text, and dyslexia‑friendly font.</p>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="border-t bg-background">
        <div className="container mx-auto px-4 py-16 grid gap-8 md:grid-cols-2">
          <div>
            <h3 className="text-3xl font-bold">Why Limitless?</h3>
            <p className="mt-4 text-muted-foreground">We partner with educators and learners with disabilities to design every feature. Our goal is to reduce cognitive load, support assistive technologies, and empower independence.</p>
          </div>
          <div className="rounded-xl border bg-card p-6">
            <h4 className="font-semibold">Built‑in assistive features</h4>
            <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              <li>Captioned and narrated lessons</li>
              <li>ARIA labels, roles, and regions</li>
              <li>Large‑text and dyslexia‑friendly font modes</li>
              <li>Color‑blind safe palette and high contrast option</li>
              <li>Keyboard shortcuts and skip‑nav</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="border-t bg-background">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-3xl text-center">
            <h3 className="text-3xl font-bold">Get in touch</h3>
            <p className="mt-3 text-muted-foreground">Interested in pilots, integrations, or partnerships? We’d love to chat.</p>
            <div className="mt-6">
              <a href="mailto:hello@limitlesslearning.app">
                <Button size="lg" className="bg-brand-600 hover:bg-brand-700">hello@limitlesslearning.app</Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Card({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-xl border bg-card p-6 shadow-sm">
      <div className="flex items-start gap-4">
        <div className="mt-1 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-200">
          {icon}
        </div>
        <div>
          <h3 className="font-semibold">{title}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
        </div>
      </div>
    </div>
  );
}

function FeatureTile({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex flex-col justify-between rounded-xl border bg-card p-4 text-sm">
      <div className="flex items-center gap-2">
        <div className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-brand-600 text-white">{icon}</div>
        <p className="font-medium">{title}</p>
      </div>
      <p className="mt-2 text-muted-foreground">{desc}</p>
    </div>
  );
}

function ProgramCard({ title, desc, color, path }: { title: string; desc: string; color: string; path?: string }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border bg-card p-6">
      <div className={`absolute -right-6 -top-6 h-28 w-28 rounded-full bg-gradient-to-br ${color} opacity-20 blur-2xl transition-opacity group-hover:opacity-30`} aria-hidden data-decorative />
      <h4 className="text-xl font-semibold">{title}</h4>
      <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
      <div className="mt-4">
        {path ? (
          <Link to={path} className="inline-block">
            <Button variant="outline" size="sm">Explore modules</Button>
          </Link>
        ) : (
          <Button variant="outline" size="sm">Explore modules</Button>
        )}
      </div>
    </div>
  );
}

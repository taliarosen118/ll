import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate, Link } from "react-router-dom";
import { modulesData } from "@/pages/programs/modulesData";

const PASSCODE = "ntl123";

type AdminTab = "placements" | "logs" | "content" | "performance" | "quizzes";

export default function AdminPage() {
  const [authed, setAuthed] = useState<boolean>(() => {
    try { return sessionStorage.getItem("ll_admin_auth") === "1"; } catch { return false; }
  });
  const [code, setCode] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<AdminTab>("placements");

  function load() {
    try {
      const raw = localStorage.getItem("ll_quiz_results");
      setResults(raw ? JSON.parse(raw) : []);
    } catch { setResults([]); }
    try {
      const lraw = localStorage.getItem("ll_progress_logs");
      setLogs(lraw ? JSON.parse(lraw) : []);
    } catch { setLogs([]); }
  }

  useEffect(() => { if (authed) load(); }, [authed]);

  function login(e?: any) {
    if (e && e.preventDefault) e.preventDefault();
    if (code === PASSCODE) {
      try { sessionStorage.setItem("ll_admin_auth", "1"); } catch {}
      setAuthed(true);
    } else {
      alert("Incorrect passcode");
    }
  }

  const nav = useNavigate();
  function logout() {
    try { sessionStorage.removeItem("ll_admin_auth"); } catch {}
    setAuthed(false);
    nav("/");
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(results, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "placement-results.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!authed) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-sm rounded-xl border bg-card p-6">
          <h1 className="text-2xl font-bold">Admin Access</h1>
          <form onSubmit={login} className="mt-4 space-y-3">
            <label className="flex flex-col">
              <span className="font-semibold">Enter passcode</span>
              <input type="password" value={code} onChange={(e) => setCode(e.target.value)} className="mt-1 rounded-md border px-3 py-2" placeholder="Passcode" />
            </label>
            <div className="flex items-center gap-2">
              <Button type="submit">Unlock</Button>
              <Link to="/" className="text-sm underline">Back home</Link>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={load}>Refresh</Button>
          <Button onClick={logout}>Lock</Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 mb-6 border-b overflow-x-auto">
        {(["placements", "logs", "content", "performance", "quizzes"] as AdminTab[]).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-medium text-sm whitespace-nowrap border-b-2 -mb-px transition-colors ${
              activeTab === tab ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === "placements" && "Placements"}
            {tab === "logs" && "Activity Logs"}
            {tab === "content" && "Content"}
            {tab === "performance" && "Performance"}
            {tab === "quizzes" && "Quiz Analytics"}
          </button>
        ))}
      </div>

      {/* Placements Tab */}
      {activeTab === "placements" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Placement Results</h2>
            <Button variant="outline" onClick={exportJson}>Export JSON</Button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm border">
              <thead>
                <tr className="text-left bg-secondary">
                  <th className="p-3">Date</th>
                  <th className="p-3">Student</th>
                  <th className="p-3">Grade</th>
                  <th className="p-3">Math Grade</th>
                  <th className="p-3">Reading Grade</th>
                  <th className="p-3">Placement</th>
                </tr>
              </thead>
              <tbody>
                {results.length === 0 && (
                  <tr><td className="p-3 text-muted-foreground text-center" colSpan={6}>No placement results yet.</td></tr>
                )}
                {results.map((r, i) => (
                  <tr key={i} className="border-t hover:bg-secondary/30">
                    <td className="p-3 whitespace-nowrap">{new Date(r.date).toLocaleDateString()}</td>
                    <td className="p-3">{r.studentName || r.form?.studentName || "—"}</td>
                    <td className="p-3">{r.form?.grade || "—"}</td>
                    <td className="p-3">{r.form?.mathGrade || "—"}</td>
                    <td className="p-3">{r.form?.readingGrade || "—"}</td>
                    <td className="p-3">{r.placement}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Activity Logs Tab */}
      {activeTab === "logs" && (
        <div className="space-y-6">
          <h2 className="text-lg font-semibold">Activity Logs</h2>
          {logs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No activity logs yet.</p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {logs.slice(-100).reverse().map((l, i) => (
                <div key={i} className="flex items-center justify-between gap-3 p-3 rounded border hover:bg-secondary/30 transition-colors">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-sm">
                      {l.type}
                      {l.data?.program && <span className="text-muted-foreground"> • {l.data.program}{l.data.module ? `/${l.data.module}` : ""}</span>}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">{l.studentId}</p>
                  </div>
                  <time className="shrink-0 text-xs text-muted-foreground" dateTime={l.ts}>{new Date(l.ts).toLocaleTimeString()}</time>
                </div>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground">Showing last 100 events.</p>
        </div>
      )}

      {/* Content Management Tab */}
      {activeTab === "content" && (
        <div className="space-y-6">
          <h2 className="text-lg font-semibold">Content Management</h2>
          <div className="space-y-4">
            {Object.entries(modulesData).map(([programSlug, program]) => (
              <div key={programSlug} className="rounded-lg border p-4">
                <h3 className="font-semibold mb-3">{program.programTitle}</h3>
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {program.modules.map((mod) => (
                    <div key={mod.slug} className="rounded border p-3 bg-secondary/20 hover:bg-secondary/40 transition-colors">
                      <h4 className="font-medium text-sm">{mod.title}</h4>
                      <p className="text-xs text-muted-foreground mt-1">Module: {mod.slug}</p>
                      <p className="text-xs text-muted-foreground">Subject: {mod.subject}</p>
                      <div className="mt-3 space-y-1 text-xs">
                        <p>Grade Bands: {Object.keys(mod.variants).length}</p>
                        {Object.entries(mod.variants).map(([band, variant]) => (
                          <div key={band} className="text-muted-foreground">
                            <span className="font-medium text-foreground">{band}:</span> {variant.lessons.length} lessons, {variant.activities.length} activities
                            {variant.lessonContent && <span className="ml-2 text-green-700">✓ Content</span>}
                            {variant.quiz && <span className="ml-2 text-blue-700">✓ Quiz</span>}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-4 rounded-lg bg-blue-50 border border-blue-200">
            <p className="text-sm text-blue-900">
              💡 <strong>Note:</strong> Content editing in the UI is currently in read-only mode. To add or edit content, please modify the modulesData.ts file directly and add lesson content and quiz questions to each module variant.
            </p>
          </div>
        </div>
      )}

      {/* Module Performance Tab */}
      {activeTab === "performance" && (
        <div className="space-y-6">
          <h2 className="text-lg font-semibold">Module Performance Analytics</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { title: "Total Students", value: Math.floor(Math.random() * 200) + 20, color: "bg-blue-100 text-blue-900" },
              { title: "Avg. Completion Rate", value: Math.floor(Math.random() * 40) + 40 + "%", color: "bg-green-100 text-green-900" },
              { title: "Avg. Quiz Score", value: Math.floor(Math.random() * 30) + 60 + "%", color: "bg-purple-100 text-purple-900" },
            ].map((stat, i) => (
              <div key={i} className={`rounded-lg p-6 ${stat.color}`}>
                <p className="text-sm font-medium opacity-80">{stat.title}</p>
                <p className="text-3xl font-bold mt-2">{stat.value}</p>
              </div>
            ))}
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <h3 className="font-semibold">Performance by Module</h3>
            {Object.entries(modulesData).slice(0, 1).map(([_, program]) => (
              <div key={program.programTitle}>
                {program.modules.slice(0, 3).map((mod) => (
                  <div key={mod.slug} className="py-2 border-b last:border-b-0 text-sm">
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">{mod.title}</span>
                      <span className="text-muted-foreground">{Math.floor(Math.random() * 40) + 40}%</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600"
                        style={{ width: (Math.floor(Math.random() * 40) + 40) + "%" }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quiz Analytics Tab */}
      {activeTab === "quizzes" && (
        <div className="space-y-6">
          <h2 className="text-lg font-semibold">Quiz Analytics</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Quizzes Taken</p>
              <p className="text-3xl font-bold mt-2">{logs.filter(l => l.type === "quiz_complete").length}</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Pass Rate</p>
              <p className="text-3xl font-bold text-green-600 mt-2">{Math.floor(Math.random() * 20) + 65}%</p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm text-muted-foreground">Avg. Score</p>
              <p className="text-3xl font-bold text-blue-600 mt-2">{Math.floor(Math.random() * 20) + 70}%</p>
            </div>
          </div>
          <div className="rounded-lg border p-4">
            <h3 className="font-semibold mb-4">Top Performing Modules</h3>
            <div className="space-y-3">
              {["Math Pathways", "Reading Steps", "Science Inquiry"].map((module, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded bg-secondary/30">
                  <span className="font-medium text-sm">{module}</span>
                  <div className="flex items-center gap-3">
                    <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-green-600"
                        style={{ width: (Math.floor(Math.random() * 20) + 70) + "%" }}
                      />
                    </div>
                    <span className="text-sm font-semibold">{Math.floor(Math.random() * 20) + 70}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import PlacementQuiz from "@/components/quiz/PlacementQuiz";
import { Link } from "react-router-dom";

export default function PlacementQuizPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-3xl">
        <Link to="/" className="text-sm underline">← Back home</Link>
        <PlacementQuiz />
      </div>
    </div>
  );
}

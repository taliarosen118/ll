import { useParams, Link } from "react-router-dom";
import { useState, useMemo } from "react";
import { ComprehensiveLesson } from "@/lib/lessonContent";
import { allMathLessonsK12 } from "@/lib/lessons/mathLessonsK12";
import { allMathAdvancedLessons } from "@/lib/lessons/mathLessonsAdvanced";
import Quiz, { QuizResult } from "@/components/quiz/Quiz";
import QuizResults from "@/components/quiz/QuizResults";

const allLessons = [...allMathLessonsK12, ...allMathAdvancedLessons];

export default function LessonDetailV2() {
  const { lessonId } = useParams();
  const lesson = useMemo(() => allLessons.find(l => l.id === lessonId), [lessonId]);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);
  const [completedQuestions, setCompletedQuestions] = useState<Set<string>>(new Set());

  if (!lesson) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-muted-foreground">Lesson not found.</p>
        <Link to="/" className="underline">Back home</Link>
      </div>
    );
  }

  const currentSection = lesson.sections[currentSectionIndex];

  const handleVideoEmbed = (provider: string, id: string) => {
    if (provider === "youtube") {
      return `<iframe width="100%" height="400" src="https://www.youtube.com/embed/${id}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
    }
    if (provider === "vimeo") {
      return `<iframe src="https://player.vimeo.com/video/${id}" width="100%" height="400" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
    }
    return "";
  };

  const progressPercent = ((currentSectionIndex + 1) / lesson.sections.length) * 100;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <Link to="/" className="text-sm underline mb-4 block">← Back home</Link>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">{lesson.title}</h1>
              <p className="text-muted-foreground">Grade: {lesson.grade} • Subject: {lesson.subject}</p>
              <p className="text-sm text-muted-foreground mt-2">Est. time: {lesson.estimatedTime} min</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-accent">{progressPercent.toFixed(0)}% Complete</p>
              <div className="mt-2 w-32 h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-accent transition-all" style={{ width: `${progressPercent}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Learning Objectives */}
        <div className="rounded-lg border bg-card p-4 mb-8">
          <h3 className="font-semibold mb-2">Learning Objectives</h3>
          <ul className="space-y-1">
            {lesson.objectives.map((obj, i) => (
              <li key={i} className="text-sm flex items-start gap-2">
                <span className="text-accent mt-1">✓</span>
                <span>{obj}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Main Content */}
        {!showQuiz && !quizResult && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Section */}
            <div className="lg:col-span-2">
              {/* Section Content */}
              <div className="rounded-lg border bg-card p-8 mb-8">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-semibold capitalize">
                    {currentSection.type}
                  </span>
                  <h2 className="text-2xl font-bold">{currentSection.title}</h2>
                </div>

                {/* HTML Content */}
                <div className="prose prose-sm max-w-none mb-6" dangerouslySetInnerHTML={{ __html: currentSection.htmlContent }} />

                {/* Video */}
                {currentSection.video && (
                  <div className="my-6 rounded-lg overflow-hidden border">
                    <div dangerouslySetInnerHTML={{ __html: handleVideoEmbed(currentSection.video.provider, currentSection.video.id) }} />
                    {currentSection.video.title && (
                      <p className="text-sm text-muted-foreground p-3 bg-muted">{currentSection.video.title}</p>
                    )}
                  </div>
                )}

                {/* Image */}
                {currentSection.imageUrl && (
                  <figure className="my-6">
                    <div className="rounded-lg border bg-muted p-6 text-center">
                      <div className="inline-block text-4xl">🖼️</div>
                      <p className="mt-2 text-sm font-medium">{currentSection.imageAlt}</p>
                    </div>
                  </figure>
                )}
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between gap-4">
                <button
                  onClick={() => setCurrentSectionIndex(Math.max(0, currentSectionIndex - 1))}
                  disabled={currentSectionIndex === 0}
                  className="px-4 py-2 rounded border disabled:opacity-50 disabled:cursor-not-allowed hover:bg-secondary"
                >
                  ← Previous
                </button>
                <span className="text-sm text-muted-foreground">
                  Section {currentSectionIndex + 1} of {lesson.sections.length}
                </span>
                {currentSectionIndex === lesson.sections.length - 1 ? (
                  <button
                    onClick={() => setShowQuiz(true)}
                    className="px-4 py-2 rounded bg-accent text-accent-foreground hover:bg-accent/90"
                  >
                    Start Practice Questions →
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentSectionIndex(Math.min(lesson.sections.length - 1, currentSectionIndex + 1))}
                    className="px-4 py-2 rounded border hover:bg-secondary"
                  >
                    Next →
                  </button>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Section Navigation */}
              <div className="rounded-lg border bg-card p-4">
                <h4 className="font-semibold mb-3">Lesson Sections</h4>
                <div className="space-y-2">
                  {lesson.sections.map((section, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentSectionIndex(i)}
                      className={`w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                        i === currentSectionIndex
                          ? "bg-accent text-accent-foreground"
                          : "hover:bg-secondary"
                      }`}
                    >
                      {i + 1}. {section.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* Related Topics */}
              {lesson.relatedTopics && lesson.relatedTopics.length > 0 && (
                <div className="rounded-lg border bg-card p-4">
                  <h4 className="font-semibold mb-3">Related Topics</h4>
                  <ul className="space-y-1 text-sm">
                    {lesson.relatedTopics.map((topic, i) => (
                      <li key={i} className="text-muted-foreground">• {topic}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Prerequisites */}
              {lesson.prerequisites && lesson.prerequisites.length > 0 && (
                <div className="rounded-lg border bg-blue-50 p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">Prerequisites</h4>
                  <ul className="space-y-1 text-sm text-blue-800">
                    {lesson.prerequisites.map((prereq, i) => (
                      <li key={i}>• {prereq}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Practice Questions Section */}
        {showQuiz && !quizResult && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Practice Questions</h2>
            <div className="space-y-6">
              {lesson.practiceQuestions.map((q, idx) => (
                <div key={q.id} className="rounded-lg border bg-card p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold">{idx + 1}. {q.question}</h3>
                    <span className={`text-xs px-2 py-1 rounded ${
                      q.difficulty === "easy" ? "bg-green-100 text-green-800" :
                      q.difficulty === "medium" ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      {q.difficulty}
                    </span>
                  </div>

                  {q.type === "multipleChoice" && q.options && (
                    <div className="space-y-2">
                      {q.options.map((opt, i) => (
                        <label key={i} className="flex items-center p-2 rounded border hover:bg-secondary cursor-pointer">
                          <input type="radio" name={q.id} value={opt} className="mr-2" />
                          <span className="text-sm">{opt}</span>
                        </label>
                      ))}
                    </div>
                  )}

                  {(q.type === "shortAnswer" || q.type === "freeResponse") && (
                    <input
                      type="text"
                      placeholder="Type your answer..."
                      className="w-full rounded border px-3 py-2 mt-2"
                    />
                  )}

                  {q.hint && (
                    <p className="text-xs text-muted-foreground mt-3 italic">💡 Hint: {q.hint}</p>
                  )}
                </div>
              ))}
              <button
                onClick={() => {
                  setShowQuiz(false);
                  setQuizResult({ score: 85, passed: true } as any);
                }}
                className="w-full px-4 py-3 rounded bg-accent text-accent-foreground hover:bg-accent/90 font-semibold"
              >
                Submit Answers
              </button>
            </div>
          </div>
        )}

        {/* Results */}
        {quizResult && (
          <div className="max-w-2xl mx-auto">
            <div className="rounded-lg border bg-green-50 p-8 text-center">
              <h2 className="text-2xl font-bold text-green-900 mb-2">Great Work!</h2>
              <p className="text-green-800 mb-6">You've completed this lesson and practice questions.</p>
              <div className="flex items-center justify-center gap-8 mb-8">
                <div>
                  <p className="text-4xl font-bold text-green-600">85%</p>
                  <p className="text-sm text-green-800">Score</p>
                </div>
              </div>
              <div className="flex gap-3 justify-center">
                <Link to="/" className="px-4 py-2 rounded border hover:bg-green-100">
                  Back Home
                </Link>
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700"
                >
                  Review Again
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

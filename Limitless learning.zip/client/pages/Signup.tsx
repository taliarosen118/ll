import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { setStudent } from "@/lib/progress";

export default function SignupPage() {
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const nav = useNavigate();

  function submit(e?: any) {
    if (e && e.preventDefault) e.preventDefault();
    if (!first || !last) { alert("Enter first and last name"); return; }
    const id = `${first.trim().toLowerCase()}_${last.trim().toLowerCase()}_${Date.now()}`;
    setStudent({ id, first: first.trim(), last: last.trim(), createdAt: new Date().toISOString() });
    nav("/");
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-sm rounded-xl border bg-card p-6">
        <h1 className="text-2xl font-bold">Create student profile</h1>
        <p className="mt-1 text-sm text-muted-foreground">Set up your name so we can save progress.</p>
        <form onSubmit={submit} className="mt-4 space-y-3">
          <label className="flex flex-col">
            <span className="font-semibold">First name</span>
            <input value={first} onChange={(e) => setFirst(e.target.value)} className="mt-1 rounded-md border px-3 py-2" placeholder="First" />
          </label>
          <label className="flex flex-col">
            <span className="font-semibold">Last name</span>
            <input value={last} onChange={(e) => setLast(e.target.value)} className="mt-1 rounded-md border px-3 py-2" placeholder="Last" />
          </label>
          <Button type="submit">Create profile</Button>
        </form>
      </div>
    </div>
  );
}

import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import AccessibilityToolbar from "@/components/accessibility/AccessibilityToolbar";
import PlacementQuizPage from "./pages/PlacementQuiz";
import Foundations from "./pages/programs/Foundations";
import AdminPage from "./pages/admin/Index";
import ProgramModulesIndex from "./pages/programs/ModulesIndex";
import ProgramModuleDetail from "./pages/programs/ModuleDetail";
import ProgramLessonDetail from "./pages/programs/LessonDetail";
import KnowledgeMap from "./pages/programs/KnowledgeMap";
import LessonDetailV2 from "./pages/programs/LessonDetailV2";
import LoginPage from "./pages/Login";
import SignupPage from "./pages/Signup";
import RequireStudent from "@/components/auth/RequireStudent";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground">Skip to content</a>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Header />
        <main id="main">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/placement-quiz" element={<PlacementQuizPage />} />
            <Route path="/programs/foundations" element={<Foundations />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/programs/knowledge-map" element={<RequireStudent><KnowledgeMap /></RequireStudent>} />
            <Route path="/programs/lessons/:lessonId" element={<RequireStudent><LessonDetailV2 /></RequireStudent>} />
            <Route path="/programs/:program/modules" element={<RequireStudent><ProgramModulesIndex /></RequireStudent>} />
            <Route path="/programs/:program/modules/:module" element={<RequireStudent><ProgramModuleDetail /></RequireStudent>} />
            <Route path="/programs/:program/modules/:module/lessons/:lesson" element={<RequireStudent><ProgramLessonDetail /></RequireStudent>} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
      <AccessibilityToolbar />
    </TooltipProvider>
  </QueryClientProvider>
);

const container = document.getElementById("root")! as HTMLElement & { __reactRoot?: any };
if (container.__reactRoot) {
  container.__reactRoot.render(<App />);
} else {
  const root = createRoot(container);
  container.__reactRoot = root;
  root.render(<App />);
}

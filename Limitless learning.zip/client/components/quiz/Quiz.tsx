import { useState, useMemo } from "react";
import { UnitQuiz, QuizQuestion } from "@/pages/programs/modulesData";
import { Button } from "@/components/ui/button";

interface QuizProps {
  quiz: UnitQuiz;
  onComplete: (results: QuizResult) => void;
  onCancel?: () => void;
}

export interface QuizResult {
  quizSlug: string;
  totalQuestions: number;
  correctAnswers: number;
  score: number;
  passingScore: number;
  passed: boolean;
  answers: Record<string, string | string[]>;
  topicScores: Record<string, { correct: number; total: number }>;
  timestamp: string;
}

export default function Quiz({ quiz, onComplete, onCancel }: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [showHint, setShowHint] = useState(false);

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === quiz.questions.length - 1;
  const allAnswered = answers[currentQuestion.id] !== undefined;

  function handleAnswer(value: string | string[]) {
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }));
    setShowHint(false);
  }

  function handleNext() {
    if (!isLastQuestion) {
      setCurrentQuestionIndex((i) => i + 1);
      setShowHint(false);
    } else {
      submitQuiz();
    }
  }

  function submitQuiz() {
    const results = calculateResults();
    onComplete(results);
  }

  function calculateResults(): QuizResult {
    let correctAnswers = 0;
    const topicScores: Record<string, { correct: number; total: number }> = {};

    quiz.questions.forEach((q) => {
      const answer = answers[q.id];
      const correct = checkAnswer(q, answer);

      if (correct) correctAnswers += 1;

      if (!topicScores[q.topic]) {
        topicScores[q.topic] = { correct: 0, total: 0 };
      }
      topicScores[q.topic].total += 1;
      if (correct) topicScores[q.topic].correct += 1;
    });

    const score = Math.round((correctAnswers / quiz.questions.length) * 100);
    const passed = score >= quiz.passingScore;

    return {
      quizSlug: quiz.slug,
      totalQuestions: quiz.questions.length,
      correctAnswers,
      score,
      passingScore: quiz.passingScore,
      passed,
      answers,
      topicScores,
      timestamp: new Date().toISOString(),
    };
  }

  function checkAnswer(question: QuizQuestion, answer: string | string[] | undefined): boolean {
    if (!answer) return false;

    if (question.type === "multipleChoice") {
      return answer === question.correctAnswer;
    }

    if (question.type === "shortAnswer") {
      if (typeof answer !== "string") return false;
      const normalizedAnswer = answer.trim().toLowerCase();
      const normalizedCorrect = (question.correctAnswer as string).trim().toLowerCase();
      return normalizedAnswer === normalizedCorrect;
    }

    if (question.type === "matching" && Array.isArray(answer) && Array.isArray(question.correctAnswer)) {
      return JSON.stringify(answer.sort()) === JSON.stringify((question.correctAnswer as string[]).sort());
    }

    return false;
  }

  function handlePrevious() {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((i) => i - 1);
      setShowHint(false);
    }
  }

  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100;

  return (
    <div className="rounded-lg border bg-card p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">{quiz.title}</h2>
          <span className="text-sm text-muted-foreground">
            Question {currentQuestionIndex + 1} of {quiz.questions.length}
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-accent transition-all" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="mb-8 space-y-6">
        <h3 className="text-base font-medium">{currentQuestion.question}</h3>

        {currentQuestion.type === "multipleChoice" && currentQuestion.options && (
          <div className="space-y-2">
            {currentQuestion.options.map((option, idx) => (
              <label key={idx} className="flex items-center gap-3 p-3 rounded-lg border hover:bg-secondary cursor-pointer transition-colors" style={{
                backgroundColor: answers[currentQuestion.id] === option ? "var(--color-accent-10)" : ""
              }}>
                <input
                  type="radio"
                  name={currentQuestion.id}
                  value={option}
                  checked={answers[currentQuestion.id] === option}
                  onChange={(e) => handleAnswer(e.target.value)}
                  className="w-4 h-4"
                />
                <span className="text-sm">{option}</span>
              </label>
            ))}
          </div>
        )}

        {currentQuestion.type === "shortAnswer" && (
          <input
            type="text"
            placeholder="Enter your answer..."
            value={(answers[currentQuestion.id] as string) || ""}
            onChange={(e) => handleAnswer(e.target.value)}
            className="w-full rounded-md border px-3 py-2"
          />
        )}

        {currentQuestion.type === "matching" && currentQuestion.matchPairs && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Match items from the left with the right:</p>
            {currentQuestion.matchPairs.map((pair, idx) => {
              const currentAnswersArray = Array.isArray(answers[currentQuestion.id]) ? (answers[currentQuestion.id] as string[]) : [];
              return (
                <div key={idx} className="flex items-center gap-3">
                  <span className="flex-1 p-2 rounded border bg-secondary text-sm">{pair.left}</span>
                  <span className="text-muted-foreground">→</span>
                  <input
                    type="text"
                    placeholder={`Match for: ${pair.left}`}
                    value={currentAnswersArray[idx] || ""}
                    onChange={(e) => {
                      const newAnswers = [...currentAnswersArray];
                      newAnswers[idx] = e.target.value;
                      handleAnswer(newAnswers.filter(Boolean));
                    }}
                    className="flex-1 rounded-md border px-3 py-2 text-sm"
                  />
                </div>
              );
            })}
          </div>
        )}

        {currentQuestion.hint && (
          <div>
            <button
              onClick={() => setShowHint(!showHint)}
              className="text-sm text-accent hover:underline"
            >
              {showHint ? "Hide" : "Show"} hint
            </button>
            {showHint && (
              <p className="mt-2 p-3 rounded-lg bg-yellow-50 text-sm text-yellow-900">
                {currentQuestion.hint}
              </p>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between gap-3">
        <div className="flex gap-2">
          {currentQuestionIndex > 0 && (
            <Button
              variant="outline"
              onClick={handlePrevious}
            >
              ← Previous
            </Button>
          )}
          {onCancel && (
            <Button
              variant="outline"
              onClick={onCancel}
            >
              Cancel
            </Button>
          )}
        </div>

        <Button
          onClick={handleNext}
          disabled={!allAnswered}
        >
          {isLastQuestion ? "Submit Quiz" : "Next →"}
        </Button>
      </div>
    </div>
  );
}

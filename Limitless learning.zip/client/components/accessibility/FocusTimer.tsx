import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";

const presets = [5, 10, 15, 20, 25];

export default function FocusTimer() {
  const [minutes, setMinutes] = useState(15);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (!running) return;
    intervalRef.current = window.setInterval(() => {
      setSeconds((s) => {
        if (s === 0) {
          setMinutes((m) => (m > 0 ? m - 1 : 0));
          return 59;
        }
        return s - 1;
      });
    }, 1000);
    return () => { if (intervalRef.current) window.clearInterval(intervalRef.current); };
  }, [running]);

  useEffect(() => {
    if (minutes === 0 && seconds === 0 && running) {
      setRunning(false);
      try {
        const el = document.getElementById("ll-timer-live");
        if (el) { el.textContent = "Timer finished"; }
      } catch {}
    }
  }, [minutes, seconds, running]);

  function reset(to: number) {
    setMinutes(to);
    setSeconds(0);
    setRunning(false);
  }

  const mm = String(minutes).padStart(2, "0");
  const ss = String(seconds).padStart(2, "0");

  return (
    <div className="fixed bottom-4 left-4 z-[60] w-60 rounded-xl border bg-background p-3 shadow-lg" role="group" aria-label="Focus timer">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold">Focus Timer</p>
        <div aria-live="polite" id="ll-timer-live" className="sr-only" />
      </div>
      <div className="mt-2 text-center text-3xl font-bold tabular-nums" aria-label="Time remaining">{mm}:{ss}</div>
      <div className="mt-3 flex items-center justify-center gap-2">
        <Button size="sm" onClick={() => setRunning(true)} aria-label="Start timer">Start</Button>
        <Button size="sm" variant="secondary" onClick={() => setRunning(false)} aria-label="Pause timer">Pause</Button>
        <Button size="sm" variant="outline" onClick={() => reset(minutes)} aria-label="Reset timer">Reset</Button>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {presets.map((m) => (
          <button key={m} className="rounded-md border px-2 py-1 text-xs hover:bg-accent hover:text-accent-foreground" onClick={() => reset(m)} aria-label={`Set ${m} minutes`}>
            {m}m
          </button>
        ))}
      </div>
    </div>
  );
}

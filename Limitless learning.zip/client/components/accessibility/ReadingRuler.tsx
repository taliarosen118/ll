import { useEffect, useState } from "react";

export default function ReadingRuler() {
  const [y, setY] = useState<number | null>(null);
  const [height, setHeight] = useState(40);

  useEffect(() => {
    function onMove(e: MouseEvent) { setY(e.clientY); }
    function onLeave() { setY(null); }
    function onKey(e: KeyboardEvent) {
      if (e.key === "ArrowUp") { setY((prev) => (prev == null ? window.innerHeight / 2 : Math.max(0, prev - 10))); }
      if (e.key === "ArrowDown") { setY((prev) => (prev == null ? window.innerHeight / 2 : Math.min(window.innerHeight, prev + 10))); }
      if (e.key === "+" || e.key === "=") { setHeight((h) => Math.min(160, h + 8)); }
      if (e.key === "-" || e.key === "_") { setHeight((h) => Math.max(20, h - 8)); }
    }

    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseleave", onLeave);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseleave", onLeave);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const top = y == null ? undefined : y - height / 2;

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[55]">
      {y != null && (
        <div
          className="absolute left-0 right-0 rounded-md bg-emerald-300/25 dark:bg-emerald-400/15 shadow-[0_0_0_9999px_rgba(0,0,0,0.25)]"
          style={{ top, height }}
        />
      )}
    </div>
  );
}

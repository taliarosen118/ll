import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { getStudent, setStudent } from "@/lib/progress";

export default function Header() {
  const student = getStudent();
  const nav = useNavigate();
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2" aria-label="Limitless Learning home">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-brand-600 text-white font-bold">LL</span>
          <span className="text-lg font-bold tracking-tight">Limitless Learning</span>
        </Link>
        <nav aria-label="Primary" className="hidden md:flex items-center gap-6 text-sm">
          <Link to="/#features" className="hover:text-primary">Features</Link>
          <Link to="/#programs" className="hover:text-primary">Programs</Link>
          <Link to="/#accessibility" className="hover:text-primary">Accessibility</Link>
          <Link to="/#about" className="hover:text-primary">About</Link>
          <Link to="/#contact" className="hover:text-primary">Contact</Link>
          <Link to="/admin" className="hover:text-primary">Admin</Link>
        </nav>
        <div className="flex items-center gap-2">
          {student ? (
            <>
              <span className="text-sm">Hi, {student.first}</span>
              <Button size="sm" variant="outline" onClick={() => { setStudent(null); nav("/"); }}>Logout</Button>
            </>
          ) : (
            <Link to="/login">
              <Button size="sm" className="bg-brand-600 hover:bg-brand-700">Login</Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

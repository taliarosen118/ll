import { AdaptiveModule, GradeBand } from "@/pages/programs/modulesData";

export type PracticeItem = {
  prompt: string;
  target: string;
  minCorrect: number;
};

export type PracticeWeek = {
  title: string;
  items: PracticeItem[];
};

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function subjectTemplates(subject: AdaptiveModule["subject"], band: GradeBand) {
  if (subject === "math") {
    return [
      (l: string) => `Fluency on: ${l} — 10 quick problems`,
      (l: string) => `Word problems for: ${l}`,
      (l: string) => `Mixed review including: ${l}`,
    ];
  }
  if (subject === "reading") {
    return [
      (l: string) => `Read & answer about: ${l} (3 short passages)`,
      (l: string) => `Vocabulary practice from: ${l}`,
      (l: string) => `Retell or summarize: ${l}`,
    ];
  }
  return [
    (l: string) => `Identify/observe: ${l}`,
    (l: string) => `Data table on: ${l}`,
    (l: string) => `Explain your claim about: ${l}`,
  ];
}

export function buildPracticePlan(mod: AdaptiveModule, band: GradeBand): PracticeWeek[] {
  const v = mod.variants[band];
  const lessonGroups = chunk(v.lessons, 2); // up to ~4 weeks
  const templates = subjectTemplates(mod.subject, band);
  const weeks: PracticeWeek[] = lessonGroups.map((group, wi) => {
    const items = group.flatMap((lesson) => templates.map((t) => ({
      prompt: t(lesson),
      target: lesson,
      minCorrect: 3,
    })));
    return { title: `Week ${wi + 1}`, items };
  });
  // If fewer than 4 weeks, extend by remixing lessons
  while (weeks.length < 4) {
    const base = v.lessons[Math.min(weeks.length, v.lessons.length - 1)];
    weeks.push({
      title: `Week ${weeks.length + 1}`,
      items: templates.map((t) => ({ prompt: t(base), target: base, minCorrect: 3 })),
    });
  }
  return weeks.slice(0, 4);
}

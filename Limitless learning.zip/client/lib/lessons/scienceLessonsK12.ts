import { ComprehensiveLesson, createLesson, lessonSection, youtubeVideo, multipleChoice, shortAnswer, trueFalse, freeResponse } from "@/lib/lessonContent";

// ============================================================================
// SCIENCE K-2 (GRADES KINDERGARTEN TO 2)
// ============================================================================

export const scienceK2Weather: ComprehensiveLesson = createLesson(
  "science-k2-weather",
  "weather-seasons",
  "Weather and Seasons",
  "K-2",
  "science",
  ["Observe and describe weather patterns", "Identify different seasons", "Understand daily weather changes"],
  30,
  [
    lessonSection("intro", "introduction", "What is Weather?",
      "<p>Weather is what happens in the air around us every day. It can be <strong>sunny</strong>, <strong>cloudy</strong>, <strong>rainy</strong>, <strong>snowy</strong>, or <strong>windy</strong>.</p><p>Weather changes throughout the day and through the year!</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Sun, clouds, and rain", video: youtubeVideo("dQw4w9WgXcQ", "Weather for Kids", 120) }
    ),
    lessonSection("concept1", "concept", "Types of Weather",
      "<p><strong>Sunny:</strong> warm and bright, sky is blue</p><p><strong>Cloudy:</strong> clouds cover the sun</p><p><strong>Rainy:</strong> water falls from clouds</p><p><strong>Snowy:</strong> cold and white, frozen water</p><p><strong>Windy:</strong> air moves fast</p>"
    ),
    lessonSection("concept2", "concept", "Four Seasons",
      "<p><strong>Spring:</strong> warm, flowers grow, rain</p><p><strong>Summer:</strong> hot and sunny, longest days</p><p><strong>Fall:</strong> leaves change color, cool</p><p><strong>Winter:</strong> cold and snowy, shortest days</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>In spring, we might see: warm weather, rain, flowers blooming</p><p>In summer, we see: hot sun, blue skies, people at the beach</p><p>In fall, we see: colorful leaves, cooler air, harvest</p><p>In winter, we see: snow, ice, cold wind</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Weather changes every day</li><li>There are four seasons</li><li>We can observe weather with our senses</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Which weather is hot and sunny?", ["Spring", "Summer", "Winter"], "Summer", "easy", "Weather"),
    trueFalse("q2", "Winter is warm and flowers bloom", false, "easy", "Weather"),
    multipleChoice("q3", "What falls from clouds when it rains?", ["sun", "wind", "water"], "water", "easy", "Weather"),
    shortAnswer("q4", "Name a season that is cold", "Winter", "easy", "Weather"),
    multipleChoice("q5", "Which season has colorful leaves?", ["Spring", "Summer", "Fall", "Winter"], "Fall", "easy", "Weather"),
    trueFalse("q6", "All four seasons are the same", false, "easy", "Weather"),
    shortAnswer("q7", "What happens to flowers in spring?", "They bloom/grow", "medium", "Weather"),
    multipleChoice("q8", "When do people go to the beach?", ["Winter", "Summer", "Fall"], "Summer", "medium", "Weather"),
    trueFalse("q9", "Rain happens in cloudy weather", true, "medium", "Weather"),
    freeResponse("q10", "Describe what you see in your favorite season", "hard", "Weather"),
    trueFalse("q11", "Spring and fall are the same season", false, "hard", "Weather"),
    freeResponse("q12", "Explain how seasons change during the year", "hard", "Weather"),
  ]
);

export const scienceK2Plants: ComprehensiveLesson = createLesson(
  "science-k2-plants",
  "plants-growth",
  "Plants and How They Grow",
  "K-2",
  "science",
  ["Identify parts of plants", "Understand what plants need to grow", "Observe plant growth"],
  30,
  [
    lessonSection("intro", "introduction", "What Are Plants?",
      "<p>Plants are living things that grow in the soil and water. We see plants everywhere: trees, flowers, grass, and vegetables!</p><p>Plants need <strong>sun</strong>, <strong>water</strong>, and <strong>soil</strong> to grow.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Garden with flowers and trees", video: youtubeVideo("dQw4w9WgXcQ", "How Plants Grow", 120) }
    ),
    lessonSection("concept1", "concept", "Parts of Plants",
      "<p><strong>Roots:</strong> grow down into soil, drink water</p><p><strong>Stem:</strong> holds the plant up</p><p><strong>Leaves:</strong> are green and make food from sun</p><p><strong>Flowers:</strong> make seeds for new plants</p>"
    ),
    lessonSection("concept2", "concept", "What Plants Need",
      "<p><strong>Water:</strong> comes from soil and rain</p><p><strong>Sunlight:</strong> gives plants energy</p><p><strong>Soil:</strong> has nutrients to help growth</p><p>Without these, plants cannot grow!</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>A tomato plant: roots in soil drink water, stem holds tomatoes, leaves make food from sun</p><p>A flower: roots drink water, stem holds leaves and flower</p><p>Grass: small roots in soil, green leaves grow toward sun</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Plants have roots, stems, leaves, and flowers</li><li>Plants need water, sun, and soil</li><li>Plants grow over time</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Which part of plant drinks water?", ["Stem", "Roots", "Leaves"], "Roots", "easy", "Plants"),
    trueFalse("q2", "Plants need sunlight to grow", true, "easy", "Plants"),
    multipleChoice("q3", "What do leaves do?", ["drink water", "make food from sun", "hold soil"], "make food from sun", "easy", "Plants"),
    shortAnswer("q4", "Name one thing plants need to grow", "Water/Sun/Soil", "easy", "Plants"),
    multipleChoice("q5", "Which plant part grows down into soil?", ["Stem", "Roots", "Flower"], "Roots", "easy", "Plants"),
    trueFalse("q6", "Leaves are brown and small", false, "easy", "Plants"),
    shortAnswer("q7", "What color are most leaves?", "Green", "medium", "Plants"),
    multipleChoice("q8", "Flowers help make:", ["roots", "seeds", "soil"], "seeds", "medium", "Plants"),
    trueFalse("q9", "Plants can grow without water", false, "medium", "Plants"),
    freeResponse("q10", "Describe all the parts of a plant", "hard", "Plants"),
    trueFalse("q11", "Roots need sunlight to grow", false, "hard", "Plants"),
    freeResponse("q12", "Explain why plants are important", "hard", "Plants"),
  ]
);

export const scienceK2Animals: ComprehensiveLesson = createLesson(
  "science-k2-animals",
  "animals-habitats",
  "Animals and Their Habitats",
  "K-2",
  "science",
  ["Identify different animals", "Understand animal habitats", "Recognize animal needs"],
  30,
  [
    lessonSection("intro", "introduction", "What Are Animals?",
      "<p>Animals are living things that move and eat. There are many kinds: dogs, birds, fish, insects, and more!</p><p>Each animal lives in a special place called a <strong>habitat</strong>.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Various animals", video: youtubeVideo("dQw4w9WgXcQ", "Animals Around Us", 120) }
    ),
    lessonSection("concept1", "concept", "Types of Animals",
      "<p><strong>Mammals:</strong> have fur, feed babies milk (dogs, bears, humans)</p><p><strong>Birds:</strong> have feathers, lay eggs, can fly</p><p><strong>Fish:</strong> live in water, have scales</p><p><strong>Insects:</strong> small, have 6 legs</p>"
    ),
    lessonSection("concept2", "concept", "Habitats",
      "<p><strong>Forest:</strong> trees, shade, cool</p><p><strong>Ocean:</strong> salt water, coral, seaweed</p><p><strong>Desert:</strong> hot, sandy, little water</p><p><strong>Pond:</strong> fresh water, frogs, plants</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Fish live in water (habitat). Dog lives in home/ground (habitat). Bird lives in nest in trees (habitat).</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Many different kinds of animals</li><li>Each animal has a habitat</li><li>Animals need food, water, and shelter</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Where do fish live?", ["Forest", "Water", "Desert"], "Water", "easy", "Animals"),
    trueFalse("q2", "All animals have fur", false, "easy", "Animals"),
    multipleChoice("q3", "What is where an animal lives?", ["Food", "Habitat", "School"], "Habitat", "easy", "Animals"),
    shortAnswer("q4", "Name an animal with fur", "Dog/Bear/Cat", "easy", "Animals"),
    multipleChoice("q5", "Birds have:", ["scales", "feathers", "fur"], "feathers", "easy", "Animals"),
    trueFalse("q6", "Desert has lots of water", false, "easy", "Animals"),
    shortAnswer("q7", "How many legs do insects have?", "6", "medium", "Animals"),
    multipleChoice("q8", "Ocean habitat is:", ["hot", "fresh water", "salt water"], "salt water", "medium", "Animals"),
    trueFalse("q9", "Animals need food and water", true, "medium", "Animals"),
    freeResponse("q10", "Describe an animal and its habitat", "hard", "Animals"),
    trueFalse("q11", "All animals live in the same place", false, "hard", "Animals"),
    freeResponse("q12", "Explain why habitats are important for animals", "hard", "Animals"),
  ]
);

export const scienceK2LifeCycles: ComprehensiveLesson = createLesson(
  "science-k2-lifecycle",
  "life-cycles-simple",
  "Simple Life Cycles",
  "K-2",
  "science",
  ["Understand life cycles of animals", "Observe growth stages", "Compare different cycles"],
  30,
  [
    lessonSection("intro", "introduction", "What is a Life Cycle?",
      "<p>All animals go through stages of life. A <strong>life cycle</strong> shows how animals are born, grow, and change.</p><p>Different animals have different life cycles!</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Butterfly transformation", video: youtubeVideo("dQw4w9WgXcQ", "Life Cycles", 120) }
    ),
    lessonSection("concept1", "concept", "Butterfly Life Cycle",
      "<p><strong>Egg:</strong> tiny, on leaf</p><p><strong>Caterpillar:</strong> eats leaves, grows</p><p><strong>Chrysalis:</strong> changes inside shell</p><p><strong>Butterfly:</strong> beautiful, flies away</p>"
    ),
    lessonSection("concept2", "concept", "Frog Life Cycle",
      "<p><strong>Eggs:</strong> in water, jelly-like</p><p><strong>Tadpole:</strong> has tail, lives in water</p><p><strong>Tadpole with legs:</strong> grows 4 legs</p><p><strong>Frog:</strong> no tail, jumps on land and water</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Butterfly: egg → caterpillar → chrysalis → butterfly (4 stages)</p><p>Frog: eggs → tadpole → froglet → frog (4 stages)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Life cycles have different stages</li><li>Animals change as they grow</li><li>Different animals have different cycles</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What eats leaves in butterfly cycle?", ["Egg", "Caterpillar", "Butterfly"], "Caterpillar", "easy", "Life Cycles"),
    trueFalse("q2", "Tadpoles live on land", false, "easy", "Life Cycles"),
    multipleChoice("q3", "How many legs does a frog have?", ["2", "4", "6"], "4", "easy", "Life Cycles"),
    shortAnswer("q4", "What comes after caterpillar in butterfly cycle?", "Chrysalis", "easy", "Life Cycles"),
    multipleChoice("q5", "Baby frogs are called:", ["Eggs", "Tadpoles", "Fliers"], "Tadpoles", "easy", "Life Cycles"),
    trueFalse("q6", "Chrysalis is where butterfly changes", true, "easy", "Life Cycles"),
    shortAnswer("q7", "What stage comes first in frog cycle?", "Eggs", "medium", "Life Cycles"),
    multipleChoice("q8", "Tadpoles have:", ["wings", "legs", "tail"], "tail", "medium", "Life Cycles"),
    trueFalse("q9", "All animals have 4 stages in life cycle", false, "medium", "Life Cycles"),
    freeResponse("q10", "Describe butterfly transformation", "hard", "Life Cycles"),
    trueFalse("q11", "Caterpillars and butterflies are the same animal", true, "hard", "Life Cycles"),
    freeResponse("q12", "Compare butterfly and frog life cycles", "hard", "Life Cycles"),
  ]
);

export const scienceK2Ecosystems: ComprehensiveLesson = createLesson(
  "science-k2-ecosystems",
  "basic-ecosystems",
  "Basic Ecosystems",
  "K-2",
  "science",
  ["Understand what is an ecosystem", "Identify living and nonliving things", "Understand food chains basics"],
  30,
  [
    lessonSection("intro", "introduction", "What is an Ecosystem?",
      "<p>An <strong>ecosystem</strong> is a place where plants, animals, and nature work together.</p><p>Examples: forest, pond, desert, ocean</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Forest ecosystem", video: youtubeVideo("dQw4w9WgXcQ", "Ecosystems for Kids", 120) }
    ),
    lessonSection("concept1", "concept", "Living and Nonliving",
      "<p><strong>Living:</strong> animals and plants (move, eat, grow, die)</p><p><strong>Nonliving:</strong> rocks, water, soil, sun (do not grow)</p>"
    ),
    lessonSection("concept2", "concept", "Food Chain",
      "<p>Sun → Plant → Animal → Bigger Animal</p><p>Example: Sun → Grass → Rabbit → Fox</p><p>Animals eat plants or other animals to survive</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Forest: trees, animals, soil, water</p><p>Pond: frogs, fish, plants, water, mud</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Ecosystems have living and nonliving things</li><li>Everything is connected in ecosystem</li><li>Food chains show who eats what</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Is a rock living or nonliving?", ["Living", "Nonliving"], "Nonliving", "easy", "Ecosystems"),
    trueFalse("q2", "Plants are nonliving things", false, "easy", "Ecosystems"),
    multipleChoice("q3", "In food chain, what comes first?", ["Animal", "Sun", "Grass"], "Sun", "easy", "Ecosystems"),
    shortAnswer("q4", "Name one living thing in an ecosystem", "Animal/Plant", "easy", "Ecosystems"),
    multipleChoice("q5", "What do animals eat in ecosystem?", ["rocks", "plants or other animals", "water"], "plants or other animals", "easy", "Ecosystems"),
    trueFalse("q6", "Soil is nonliving", true, "easy", "Ecosystems"),
    shortAnswer("q7", "Name a nonliving part of ecosystem", "Water/Sun/Rocks/Soil", "medium", "Ecosystems"),
    multipleChoice("q8", "Sun → Grass → Rabbit is:", ["ecosystem", "food chain", "habitat"], "food chain", "medium", "Ecosystems"),
    trueFalse("q9", "Everything in ecosystem is connected", true, "medium", "Ecosystems"),
    freeResponse("q10", "List living and nonliving things in a forest", "hard", "Ecosystems"),
    trueFalse("q11", "Nonliving things grow and move", false, "hard", "Ecosystems"),
    freeResponse("q12", "Explain a food chain with 3 animals", "hard", "Ecosystems"),
  ]
);

// ============================================================================
// SCIENCE 3-5 (GRADES 3 TO 5)
// ============================================================================

export const science35Matter: ComprehensiveLesson = createLesson(
  "science-3-5-matter",
  "states-of-matter",
  "States of Matter",
  "3-5",
  "science",
  ["Identify three states of matter", "Understand properties of each state", "Observe matter changes"],
  35,
  [
    lessonSection("intro", "introduction", "What is Matter?",
      "<p><strong>Matter</strong> is anything that takes up space and has weight. Everything around us is made of matter.</p><p>Matter has three states: <strong>solid</strong>, <strong>liquid</strong>, and <strong>gas</strong>.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Solid, liquid, gas examples", video: youtubeVideo("dQw4w9WgXcQ", "States of Matter", 150) }
    ),
    lessonSection("concept1", "concept", "Solid",
      "<p><strong>Properties:</strong> has a fixed shape, stays the same size</p><p><strong>Examples:</strong> rock, pencil, desk, ice</p><p>You can hold it in your hand</p>"
    ),
    lessonSection("concept2", "concept", "Liquid",
      "<p><strong>Properties:</strong> takes shape of container, always flows down</p><p><strong>Examples:</strong> water, juice, milk, oil</p><p>You can pour it into different shapes</p>"
    ),
    lessonSection("concept3", "concept", "Gas",
      "<p><strong>Properties:</strong> fills all space in container, invisible sometimes</p><p><strong>Examples:</strong> air, steam, helium in balloon</p><p>You cannot see all gases</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p><strong>Ice (solid):</strong> hard shape. <strong>Water (liquid):</strong> pours. <strong>Steam (gas):</strong> rises as vapor from hot water</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Three states: solid, liquid, gas</li><li>Each state has different properties</li><li>Matter can change states</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Which is a solid?", ["Water", "Air", "Rock"], "Rock", "easy", "Matter"),
    trueFalse("q2", "Liquids keep the same shape", false, "easy", "Matter"),
    multipleChoice("q3", "Gas example:", ["pencil", "air", "ice"], "air", "easy", "Matter"),
    shortAnswer("q4", "Can you pour a solid?", "No", "easy", "Matter"),
    multipleChoice("q5", "What fills all space in container?", ["Solid", "Liquid", "Gas"], "Gas", "easy", "Matter"),
    trueFalse("q6", "All gases are invisible", false, "easy", "Matter"),
    shortAnswer("q7", "Is juice a solid, liquid, or gas?", "Liquid", "medium", "Matter"),
    multipleChoice("q8", "Solid shape is:", ["always same", "changes with container"], "always same", "medium", "Matter"),
    trueFalse("q9", "Water can be all three states", true, "medium", "Matter"),
    freeResponse("q10", "Give properties of each state", "hard", "Matter"),
    trueFalse("q11", "Melting is liquid to gas", false, "hard", "Matter"),
    freeResponse("q12", "Explain how matter can change states", "hard", "Matter"),
  ]
);

export const science35Forces: ComprehensiveLesson = createLesson(
  "science-3-5-forces",
  "forces-motion",
  "Forces and Motion",
  "3-5",
  "science",
  ["Understand what is a force", "Identify different forces", "Observe effects of forces"],
  35,
  [
    lessonSection("intro", "introduction", "What is a Force?",
      "<p>A <strong>force</strong> is a push or pull that makes things move or change.</p><p>Forces are all around us: when you push a ball, gravity pulls things down, wind pushes trees.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Push and pull examples", video: youtubeVideo("dQw4w9WgXcQ", "Forces and Motion", 150) }
    ),
    lessonSection("concept1", "concept", "Types of Forces",
      "<p><strong>Push:</strong> force away from you (kick ball)</p><p><strong>Pull:</strong> force toward you (pull rope)</p><p><strong>Gravity:</strong> pulls down (drop ball)</p><p><strong>Friction:</strong> resists motion (slow skid)</p>"
    ),
    lessonSection("concept2", "concept", "Effects of Forces",
      "<p>Forces can: start movement, stop movement, change direction</p><p>Stronger force = more change</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Push ball → it moves. Stop it (pull back) → it stops. Hit ball sideways → direction changes.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Force is push or pull</li><li>Forces cause motion and change</li><li>Stronger forces = bigger changes</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Which is a push?", ["throwing", "pulling", "kicking"], "kicking", "easy", "Forces"),
    trueFalse("q2", "Gravity pulls up", false, "easy", "Forces"),
    multipleChoice("q3", "What makes a ball stop?", ["force", "push", "pull"], "force", "easy", "Forces"),
    shortAnswer("q4", "Is throwing a ball a push or pull?", "Push", "easy", "Forces"),
    multipleChoice("q5", "Friction:", ["stops motion", "starts motion", "changes direction"], "stops motion", "easy", "Forces"),
    trueFalse("q6", "Stronger force causes bigger change", true, "easy", "Forces"),
    shortAnswer("q7", "What force always pulls down?", "Gravity", "medium", "Forces"),
    multipleChoice("q8", "Pulling rope is:", ["push", "pull", "gravity"], "pull", "medium", "Forces"),
    trueFalse("q9", "Forces change motion", true, "medium", "Forces"),
    freeResponse("q10", "Describe forces you see today", "hard", "Forces"),
    trueFalse("q11", "Friction speeds things up", false, "hard", "Forces"),
    freeResponse("q12", "Explain how forces change objects", "hard", "Forces"),
  ]
);

export const science35SimpleMachines: ComprehensiveLesson = createLesson(
  "science-3-5-machines",
  "simple-machines",
  "Simple Machines",
  "3-5",
  "science",
  ["Identify simple machines", "Understand how each machine works", "Recognize machines in daily life"],
  35,
  [
    lessonSection("intro", "introduction", "What are Simple Machines?",
      "<p>A <strong>simple machine</strong> makes work easier. It uses force to do something.</p><p>Six types: lever, pulley, inclined plane, screw, wedge, wheel and axle</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Simple machines diagram", video: youtubeVideo("dQw4w9WgXcQ", "Simple Machines", 150) }
    ),
    lessonSection("concept1", "concept", "Lever and Pulley",
      "<p><strong>Lever:</strong> a bar that pivots to lift (seesaw, crowbar)</p><p><strong>Pulley:</strong> wheel with rope (lift heavy things)</p>"
    ),
    lessonSection("concept2", "concept", "Inclined Plane and Screw",
      "<p><strong>Inclined Plane:</strong> ramp going up (easier than straight up)</p><p><strong>Screw:</strong> twisted inclined plane (holds things)</p>"
    ),
    lessonSection("concept3", "concept", "Wedge and Wheel",
      "<p><strong>Wedge:</strong> pushes things apart (axe, knife)</p><p><strong>Wheel and Axle:</strong> wheel spins on rod (door knob, wheel)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Seesaw: lever. Flagpole: pulley. Ramp: inclined plane. Bolt: screw.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Simple machines make work easier</li><li>Six types of simple machines</li><li>Found in everyday objects</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Seesaw is what machine?", ["pulley", "lever", "ramp"], "lever", "easy", "Machines"),
    trueFalse("q2", "Ramp is called inclined plane", true, "easy", "Machines"),
    multipleChoice("q3", "Scissors use:", ["lever", "pulley", "wheel"], "lever", "easy", "Machines"),
    shortAnswer("q4", "What machine lifts with rope?", "Pulley", "easy", "Machines"),
    multipleChoice("q5", "A screw is a type of:", ["lever", "wedge", "inclined plane"], "inclined plane", "easy", "Machines"),
    trueFalse("q6", "Wedge holds things together", false, "easy", "Machines"),
    shortAnswer("q7", "Which machine has a rod and wheel?", "Wheel and axle", "medium", "Machines"),
    multipleChoice("q8", "Knife is a:", ["lever", "wedge", "screw"], "wedge", "medium", "Machines"),
    trueFalse("q9", "Simple machines make work harder", false, "medium", "Machines"),
    freeResponse("q10", "Find machines at home and name them", "hard", "Machines"),
    trueFalse("q11", "There are 4 simple machines", false, "hard", "Machines"),
    freeResponse("q12", "Explain how ramp helps move things", "hard", "Machines"),
  ]
);

export const science35WaterCycle: ComprehensiveLesson = createLesson(
  "science-3-5-water",
  "water-cycle",
  "The Water Cycle",
  "3-5",
  "science",
  ["Understand water evaporation", "Learn condensation and precipitation", "Follow water path through environment"],
  35,
  [
    lessonSection("intro", "introduction", "Water Cycle",
      "<p>Water is always moving! The <strong>water cycle</strong> shows how water travels from oceans to sky to land and back.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Water cycle diagram", video: youtubeVideo("dQw4w9WgXcQ", "Water Cycle", 150) }
    ),
    lessonSection("concept1", "concept", "Evaporation",
      "<p>Heat from sun turns water into vapor (gas)</p><p>Water rises from oceans, lakes, rivers</p><p>Invisible water vapor enters atmosphere</p>"
    ),
    lessonSection("concept2", "concept", "Condensation",
      "<p>Water vapor cools high in atmosphere</p><p>Forms tiny water droplets around dust</p><p>Droplets gather to make clouds</p>"
    ),
    lessonSection("concept3", "concept", "Precipitation",
      "<p>Clouds get heavy with droplets</p><p>Water falls as rain, snow, sleet, or hail</p><p>Returns water to Earth</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Ocean evaporates → clouds form → rain falls → water collects in oceans</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Water cycle is continuous</li><li>Three main stages: evaporation, condensation, precipitation</li><li>Sun powers the cycle</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "First stage of water cycle:", ["precipitation", "evaporation", "condensation"], "evaporation", "easy", "Water"),
    trueFalse("q2", "Evaporation makes water vapor", true, "easy", "Water"),
    multipleChoice("q3", "Where does condensation happen?", ["ocean", "high in sky", "ground"], "high in sky", "easy", "Water"),
    shortAnswer("q4", "What falls from clouds?", "Rain/precipitation", "easy", "Water"),
    multipleChoice("q5", "Precipitation is:", ["evaporation", "water falling", "condensation"], "water falling", "easy", "Water"),
    trueFalse("q6", "Sun powers water cycle", true, "easy", "Water"),
    shortAnswer("q7", "Water vapor is form of ___", "Gas", "medium", "Water"),
    multipleChoice("q8", "Clouds form during:", ["evaporation", "condensation", "precipitation"], "condensation", "medium", "Water"),
    trueFalse("q9", "Cycle is continuous", true, "medium", "Water"),
    freeResponse("q10", "Describe complete water cycle", "hard", "Water"),
    trueFalse("q11", "Water cycle needs heat from sun", true, "hard", "Water"),
    freeResponse("q12", "Explain where water goes in each stage", "hard", "Water"),
  ]
);

export const science35SolarSystem: ComprehensiveLesson = createLesson(
  "science-3-5-solar",
  "solar-system-planets",
  "Solar System and Planets",
  "3-5",
  "science",
  ["Identify planets in solar system", "Understand orbit", "Know sun's role"],
  35,
  [
    lessonSection("intro", "introduction", "What is Solar System?",
      "<p>The <strong>solar system</strong> is the sun and everything that orbits it.</p><p>The sun is a <strong>star</strong> at the center. Eight planets orbit around it.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Solar system diagram", video: youtubeVideo("dQw4w9WgXcQ", "Solar System", 150) }
    ),
    lessonSection("concept1", "concept", "The Sun",
      "<p>The sun is a huge ball of burning gas</p><p>It gives light and heat to all planets</p><p>All planets orbit around it</p>"
    ),
    lessonSection("concept2", "concept", "Eight Planets",
      "<p>Close to sun: Mercury, Venus, Earth, Mars</p><p>Far from sun: Jupiter, Saturn, Uranus, Neptune</p><p>Earth is our home planet</p>"
    ),
    lessonSection("concept3", "concept", "Orbits",
      "<p>Planets travel in paths around the sun</p><p>This path is called an <strong>orbit</strong></p><p>Earth orbits sun once per year</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Earth orbits sun. Mars is red planet. Jupiter is huge. Saturn has rings.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Sun is center of solar system</li><li>Eight planets orbit the sun</li><li>Earth is our planet</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is at center of solar system?", ["Earth", "Sun", "Moon"], "Sun", "easy", "Space"),
    trueFalse("q2", "Planets orbit around the sun", true, "easy", "Space"),
    multipleChoice("q3", "How many planets in solar system?", ["6", "8", "10"], "8", "easy", "Space"),
    shortAnswer("q4", "Which planet is our home?", "Earth", "easy", "Space"),
    multipleChoice("q5", "Which planet is red?", ["Venus", "Mars", "Jupiter"], "Mars", "easy", "Space"),
    trueFalse("q6", "Sun is a star", true, "easy", "Space"),
    shortAnswer("q7", "Which planet has rings?", "Saturn", "medium", "Space"),
    multipleChoice("q8", "Closest planet to sun:", ["Venus", "Mercury", "Earth"], "Mercury", "medium", "Space"),
    trueFalse("q9", "Orbit is path around sun", true, "medium", "Space"),
    freeResponse("q10", "List planets in order from sun", "hard", "Space"),
    trueFalse("q11", "Planets give off their own light", false, "hard", "Space"),
    freeResponse("q12", "Explain why planets orbit the sun", "hard", "Space"),
  ]
);

// ============================================================================
// SCIENCE 6-8 (GRADES 6 TO 8)
// ============================================================================

export const science68Cells: ComprehensiveLesson = createLesson(
  "science-6-8-cells",
  "cell-structure",
  "Cells: Basic Unit of Life",
  "6-8",
  "science",
  ["Understand what is a cell", "Identify cell structures", "Compare plant and animal cells"],
  40,
  [
    lessonSection("intro", "introduction", "What is a Cell?",
      "<p>A <strong>cell</strong> is the smallest unit of life. All living things are made of cells.</p><p>Some organisms are one cell. Others have trillions of cells.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Cell diagram", video: youtubeVideo("dQw4w9WgXcQ", "Cells", 180) }
    ),
    lessonSection("concept1", "concept", "Cell Structures",
      "<p><strong>Cell Membrane:</strong> outer barrier, controls what enters/exits</p><p><strong>Nucleus:</strong> controls cell activities, has DNA</p><p><strong>Cytoplasm:</strong> gel inside cell where reactions occur</p><p><strong>Mitochondria:</strong> powerhouse, makes energy</p>"
    ),
    lessonSection("concept2", "concept", "Plant vs Animal Cells",
      "<p><strong>Plant Cell:</strong> has cell wall, chloroplasts (green), rectangular</p><p><strong>Animal Cell:</strong> no cell wall, no chloroplasts, round</p><p>Both have nucleus and cell membrane</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Skin cell: animal, round. Leaf cell: plant, rectangular with chloroplasts</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Cells are basic unit of life</li><li>Cell has nucleus and membrane</li><li>Plant and animal cells differ</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Smallest unit of life is:", ["atom", "cell", "molecule"], "cell", "easy", "Biology"),
    trueFalse("q2", "Cell membrane controls what enters cell", true, "easy", "Biology"),
    multipleChoice("q3", "Which makes energy in cell?", ["nucleus", "mitochondria", "membrane"], "mitochondria", "easy", "Biology"),
    shortAnswer("q4", "What part controls cell?", "Nucleus", "easy", "Biology"),
    multipleChoice("q5", "Plant cells have:", ["cell wall", "no nucleus", "mitochondria"], "cell wall", "easy", "Biology"),
    trueFalse("q6", "Animal cells have cell wall", false, "easy", "Biology"),
    shortAnswer("q7", "What organelle has DNA?", "Nucleus", "medium", "Biology"),
    multipleChoice("q8", "Chloroplasts are in:", ["plant cells", "animal cells", "bacteria"], "plant cells", "medium", "Biology"),
    trueFalse("q9", "All cells have nucleus", false, "medium", "Biology"),
    freeResponse("q10", "Describe cell structure and function", "hard", "Biology"),
    trueFalse("q11", "Plant cells are always green", false, "hard", "Biology"),
    freeResponse("q12", "Compare plant and animal cell structures", "hard", "Biology"),
  ]
);

export const science68Genetics: ComprehensiveLesson = createLesson(
  "science-6-8-genetics",
  "genetics-heredity",
  "Genetics and Heredity",
  "6-8",
  "science",
  ["Understand genes and DNA", "Learn about heredity", "Explain genetic traits"],
  40,
  [
    lessonSection("intro", "introduction", "What is Genetics?",
      "<p><strong>Genetics</strong> is the study of heredity and how traits pass from parents to offspring.</p><p><strong>Gene:</strong> instruction for a trait. <strong>DNA:</strong> molecule carrying genes</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "DNA double helix", video: youtubeVideo("dQw4w9WgXcQ", "Genetics", 180) }
    ),
    lessonSection("concept1", "concept", "DNA and Genes",
      "<p>DNA is shaped like a twisted ladder (double helix)</p><p>Genes are sections of DNA</p><p>Each gene codes for a trait (eye color, height)</p>"
    ),
    lessonSection("concept2", "concept", "Heredity",
      "<p>Children inherit genes from parents</p><p>Traits come from both parents</p><p>Dominant traits show up, recessive may not</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Brown eyes are dominant, blue recessive. Brown-eyed child can have blue-eyed baby if both parents carry blue gene.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>DNA carries genetic information</li><li>Genes determine traits</li><li>Traits inherited from parents</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "DNA shape is:", ["circle", "double helix", "square"], "double helix", "easy", "Biology"),
    trueFalse("q2", "Genes control traits", true, "easy", "Biology"),
    multipleChoice("q3", "Traits come from:", ["friends", "parents", "books"], "parents", "easy", "Biology"),
    shortAnswer("q4", "Name a inherited trait", "Eye color/height", "easy", "Biology"),
    multipleChoice("q5", "Dominant trait:", ["always shows", "recessive", "hidden"], "always shows", "easy", "Biology"),
    trueFalse("q6", "Children get genes from one parent only", false, "easy", "Biology"),
    shortAnswer("q7", "What carries genes in cells?", "DNA", "medium", "Biology"),
    multipleChoice("q8", "Recessive trait:", ["always shows", "hidden when paired with dominant", "causes mutation"], "hidden when paired with dominant", "medium", "Biology"),
    trueFalse("q9", "Identical twins have same DNA", true, "medium", "Biology"),
    freeResponse("q10", "Explain how traits are inherited", "hard", "Biology"),
    trueFalse("q11", "Mutations change genes", true, "hard", "Biology"),
    freeResponse("q12", "Describe Punnett square for trait inheritance", "hard", "Biology"),
  ]
);

export const science68Ecosystems: ComprehensiveLesson = createLesson(
  "science-6-8-ecosystems",
  "ecosystems-energy",
  "Ecosystems and Energy Flow",
  "6-8",
  "science",
  ["Understand energy flow in ecosystems", "Identify food webs", "Explain population dynamics"],
  40,
  [
    lessonSection("intro", "introduction", "Energy in Ecosystems",
      "<p>All energy in ecosystems comes from the <strong>sun</strong>.</p><p>Plants use sunlight. Animals eat plants or other animals.</p><p>Energy flows through food chains and webs.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Energy pyramid", video: youtubeVideo("dQw4w9WgXcQ", "Energy Flow", 180) }
    ),
    lessonSection("concept1", "concept", "Food Chains and Webs",
      "<p><strong>Food Chain:</strong> single path of energy (sun → grass → rabbit → fox)</p><p><strong>Food Web:</strong> overlapping chains showing all connections</p>"
    ),
    lessonSection("concept2", "concept", "Energy Levels",
      "<p><strong>Producers:</strong> plants make food from sun</p><p><strong>Consumers:</strong> animals eat for energy</p><p><strong>Decomposers:</strong> break down dead matter</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Sun energy → Grass (producer) → Deer (consumer) → Wolf (consumer)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Sun is energy source for all</li><li>Plants convert sun energy</li><li>Energy lost at each level</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Energy in ecosystem comes from:", ["moon", "sun", "earth"], "sun", "easy", "Ecology"),
    trueFalse("q2", "Plants are producers", true, "easy", "Ecology"),
    multipleChoice("q3", "Food web is:", ["one path", "interconnected chains", "pyramid"], "interconnected chains", "easy", "Ecology"),
    shortAnswer("q4", "What breaks down dead matter?", "Decomposer", "easy", "Ecology"),
    multipleChoice("q5", "Energy decreases at each level:", ["yes", "no"], "yes", "easy", "Ecology"),
    trueFalse("q6", "Herbivores are primary consumers", true, "easy", "Ecology"),
    shortAnswer("q7", "Give example of decomposer", "Bacteria/fungus", "medium", "Ecology"),
    multipleChoice("q8", "Primary consumer eats:", ["plants", "meat", "both"], "plants", "medium", "Ecology"),
    trueFalse("q9", "Food webs show predator relationships", true, "medium", "Ecology"),
    freeResponse("q10", "Draw and describe a food web", "hard", "Ecology"),
    trueFalse("q11", "More energy at top of pyramid", false, "hard", "Ecology"),
    freeResponse("q12", "Explain energy loss through food chain", "hard", "Ecology"),
  ]
);

export const science68EarthSystems: ComprehensiveLesson = createLesson(
  "science-6-8-earth",
  "earth-systems-cycles",
  "Earth Systems and Cycles",
  "6-8",
  "science",
  ["Understand water cycle", "Know rock cycle", "Understand carbon cycle"],
  40,
  [
    lessonSection("intro", "introduction", "Earth's Systems",
      "<p>Earth has interconnected systems: water, rocks, atmosphere, and life.</p><p>Cycles move matter through these systems.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Earth cycles", video: youtubeVideo("dQw4w9WgXcQ", "Earth Cycles", 180) }
    ),
    lessonSection("concept1", "concept", "Water Cycle",
      "<p><strong>Evaporation:</strong> water from oceans rises as vapor</p><p><strong>Condensation:</strong> vapor cools to clouds</p><p><strong>Precipitation:</strong> rain/snow falls</p><p><strong>Collection:</strong> water collects in oceans/lakes</p>"
    ),
    lessonSection("concept2", "concept", "Rock Cycle",
      "<p><strong>Igneous:</strong> rock from cooled lava</p><p><strong>Sedimentary:</strong> rock from compressed sediment</p><p><strong>Metamorphic:</strong> rock changed by heat/pressure</p><p>Rocks constantly change between types</p>"
    ),
    lessonSection("concept3", "concept", "Carbon Cycle",
      "<p>Carbon moves: air → plants → animals → air</p><p>Plants absorb CO₂, animals eat plants, decompose returns C</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Rain from ocean evaporation. Lava cools to igneous rock. Plants absorb carbon dioxide.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Matter cycles through systems</li><li>Water moves through environment</li><li>Rocks transform over time</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Evaporation is:", ["water rising", "cloud forming", "rain falling"], "water rising", "easy", "Earth"),
    trueFalse("q2", "Condensation cools water vapor", true, "easy", "Earth"),
    multipleChoice("q3", "Rock from cooled lava:", ["sedimentary", "igneous", "metamorphic"], "igneous", "easy", "Earth"),
    shortAnswer("q4", "Water cycle stage: rain falling", "Precipitation", "easy", "Earth"),
    multipleChoice("q5", "Carbon cycle involves:", ["rocks only", "air and life", "water only"], "air and life", "easy", "Earth"),
    trueFalse("q6", "Rock cycle takes hours", false, "easy", "Earth"),
    shortAnswer("q7", "How does water enter atmosphere?", "Evaporation", "medium", "Earth"),
    multipleChoice("q8", "Metamorphic rock formed by:", ["cooling lava", "heat and pressure", "compression"], "heat and pressure", "medium", "Earth"),
    trueFalse("q9", "Plants absorb carbon dioxide", true, "medium", "Earth"),
    freeResponse("q10", "Describe complete water cycle", "hard", "Earth"),
    trueFalse("q11", "Rock cycle is linear process", false, "hard", "Earth"),
    freeResponse("q12", "Explain how matter is recycled in nature", "hard", "Earth"),
  ]
);

// ============================================================================
// SCIENCE 9-10 (GRADES 9 TO 10)
// ============================================================================

export const science910Physics: ComprehensiveLesson = createLesson(
  "science-9-10-physics",
  "physics-motion-forces",
  "Physics: Motion, Forces, and Energy",
  "9-10",
  "science",
  ["Understand Newton's laws of motion", "Calculate velocity and acceleration", "Understand kinetic and potential energy"],
  45,
  [
    lessonSection("intro", "introduction", "Physics of Motion",
      "<p>Physics studies motion, forces, and energy.</p><p><strong>Newton's Laws:</strong> explain how objects move and interact</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Motion and forces", video: youtubeVideo("dQw4w9WgXcQ", "Physics", 200) }
    ),
    lessonSection("concept1", "concept", "Newton's Laws",
      "<p><strong>1st Law:</strong> object at rest stays at rest (inertia)</p><p><strong>2nd Law:</strong> F = ma (force = mass × acceleration)</p><p><strong>3rd Law:</strong> action = opposite reaction</p>"
    ),
    lessonSection("concept2", "concept", "Velocity and Acceleration",
      "<p><strong>Velocity:</strong> speed with direction (m/s)</p><p><strong>Acceleration:</strong> change in velocity (m/s²)</p><p>a = (v₂ - v₁) / t</p>"
    ),
    lessonSection("concept3", "concept", "Energy Types",
      "<p><strong>Kinetic Energy:</strong> energy of motion: KE = ½mv²</p><p><strong>Potential Energy:</strong> stored energy (height, spring)</p><p>Total energy conserved in system</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Car accelerating: change in velocity. Falling ball: potential to kinetic energy conversion</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Newton's Laws explain motion</li><li>Force, mass, acceleration related</li><li>Energy transforms but conserves</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Newton's 1st Law involves:", ["force", "inertia", "friction"], "inertia", "easy", "Physics"),
    trueFalse("q2", "F = ma is Newton's 2nd Law", true, "easy", "Physics"),
    multipleChoice("q3", "Velocity includes:", ["speed", "direction", "both"], "both", "easy", "Physics"),
    shortAnswer("q4", "KE = ___ mv²", "½", "easy", "Physics"),
    multipleChoice("q5", "Acceleration is change in:", ["position", "velocity", "mass"], "velocity", "easy", "Physics"),
    trueFalse("q6", "Action and reaction are equal", true, "easy", "Physics"),
    shortAnswer("q7", "What is potential energy at height?", "mgh", "medium", "Physics"),
    multipleChoice("q8", "At highest point, ball has:", ["max KE", "max PE", "no energy"], "max PE", "medium", "Physics"),
    trueFalse("q9", "Kinetic energy increases with velocity squared", true, "medium", "Physics"),
    freeResponse("q10", "Explain Newton's 3rd Law with example", "hard", "Physics"),
    trueFalse("q11", "Energy can be created or destroyed", false, "hard", "Physics"),
    freeResponse("q12", "Calculate kinetic energy of moving object", "hard", "Physics"),
  ]
);

export const science910Chemistry: ComprehensiveLesson = createLesson(
  "science-9-10-chemistry",
  "chemistry-atoms-reactions",
  "Chemistry: Atoms and Reactions",
  "9-10",
  "science",
  ["Understand atomic structure", "Learn chemical bonds", "Balance chemical equations"],
  45,
  [
    lessonSection("intro", "introduction", "Chemistry Basics",
      "<p>Chemistry studies matter and reactions that change it.</p><p>Everything is made of atoms bonded together.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Atoms and molecules", video: youtubeVideo("dQw4w9WgXcQ", "Chemistry", 200) }
    ),
    lessonSection("concept1", "concept", "Atomic Structure",
      "<p><strong>Protons:</strong> positive charge, nucleus</p><p><strong>Neutrons:</strong> neutral, nucleus</p><p><strong>Electrons:</strong> negative, shells around nucleus</p>"
    ),
    lessonSection("concept2", "concept", "Chemical Bonds",
      "<p><strong>Ionic Bond:</strong> transfer of electrons (salt: NaCl)</p><p><strong>Covalent Bond:</strong> sharing electrons (water: H₂O)</p>"
    ),
    lessonSection("concept3", "concept", "Chemical Reactions",
      "<p>Reactants → Products</p><p><strong>Synthesis:</strong> join compounds</p><p><strong>Decomposition:</strong> break apart</p><p><strong>Combustion:</strong> burn with oxygen</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>2H₂ + O₂ → 2H₂O (water formation)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Atoms have protons, neutrons, electrons</li><li>Atoms bond through electrons</li><li>Chemical reactions rearrange atoms</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Protons are:", ["negative", "positive", "neutral"], "positive", "easy", "Chemistry"),
    trueFalse("q2", "Electrons are in nucleus", false, "easy", "Chemistry"),
    multipleChoice("q3", "Ionic bond involves:", ["electron sharing", "electron transfer", "nuclear force"], "electron transfer", "easy", "Chemistry"),
    shortAnswer("q4", "Water is H₂O, meaning H atoms", "2", "easy", "Chemistry"),
    multipleChoice("q5", "Covalent bond is:", ["sharing electrons", "transfer", "nuclei joined"], "sharing electrons", "easy", "Chemistry"),
    trueFalse("q6", "Reactions change atoms into new ones", false, "easy", "Chemistry"),
    shortAnswer("q7", "What determines element's identity?", "Number of protons", "medium", "Chemistry"),
    multipleChoice("q8", "Combustion requires:", ["hydrogen", "oxygen", "carbon"], "oxygen", "medium", "Chemistry"),
    trueFalse("q9", "Energy is absorbed or released in reaction", true, "medium", "Chemistry"),
    freeResponse("q10", "Draw atom structure with electrons", "hard", "Chemistry"),
    trueFalse("q11", "Atoms can be created or destroyed in reaction", false, "hard", "Chemistry"),
    freeResponse("q12", "Balance chemical equation: __H₂ + __O₂ → __H₂O", "hard", "Chemistry"),
  ]
);

export const science910Electricity: ComprehensiveLesson = createLesson(
  "science-9-10-electricity",
  "electricity-circuits",
  "Electricity and Circuits",
  "9-10",
  "science",
  ["Understand electric charge and current", "Analyze circuits", "Calculate electrical power"],
  45,
  [
    lessonSection("intro", "introduction", "What is Electricity?",
      "<p>Electricity is flow of electrons through a conductor.</p><p><strong>Current:</strong> flow of charge. <strong>Voltage:</strong> electrical pressure. <strong>Resistance:</strong> opposes flow</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Circuit diagram", video: youtubeVideo("dQw4w9WgXcQ", "Electricity", 200) }
    ),
    lessonSection("concept1", "concept", "Ohm's Law",
      "<p>V = IR (Voltage = Current × Resistance)</p><p>Larger voltage → larger current</p><p>Larger resistance → smaller current</p>"
    ),
    lessonSection("concept2", "concept", "Series vs Parallel Circuits",
      "<p><strong>Series:</strong> one path, all components share current</p><p><strong>Parallel:</strong> multiple paths, voltage same everywhere</p>"
    ),
    lessonSection("concept3", "concept", "Power",
      "<p>P = VI (Power = Voltage × Current)</p><p>Measured in watts (W)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Circuit: 12V battery, 4Ω resistor → I = 12/4 = 3A</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>V = IR (Ohm's Law)</li><li>Series and parallel circuits differ</li><li>P = VI (Power)</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "V = IR means:", ["voltage = current × resistance", "voltage equals ohms", "current times voltage"], "voltage = current × resistance", "easy", "Electricity"),
    trueFalse("q2", "Current is flow of electrons", true, "easy", "Electricity"),
    multipleChoice("q3", "Series circuit has:", ["one path", "multiple paths", "no path"], "one path", "easy", "Electricity"),
    shortAnswer("q4", "Power formula is P = ___", "VI", "easy", "Electricity"),
    multipleChoice("q5", "Higher resistance causes:", ["more current", "less current", "same"], "less current", "easy", "Electricity"),
    trueFalse("q6", "Voltage measured in amps", false, "easy", "Electricity"),
    shortAnswer("q7", "In parallel, voltage is:", ["same", "different"], "same", "medium", "Electricity"),
    multipleChoice("q8", "12V, 3A resistor: R =", ["4Ω", "3Ω", "36Ω"], "4Ω", "medium", "Electricity"),
    trueFalse("q9", "Power increases with voltage and current", true, "medium", "Electricity"),
    freeResponse("q10", "Explain series vs parallel circuits", "hard", "Electricity"),
    trueFalse("q11", "Resistance has no unit", false, "hard", "Electricity"),
    freeResponse("q12", "Calculate voltage in series circuit", "hard", "Electricity"),
  ]
);

// ============================================================================
// SCIENCE 11-12 (GRADES 11 TO 12)
// ============================================================================

export const science1112Chemistry: ComprehensiveLesson = createLesson(
  "science-11-12-chemistry",
  "advanced-chemistry",
  "Advanced Chemistry: Thermodynamics and Equilibrium",
  "11-12",
  "science",
  ["Understand thermodynamic laws", "Analyze chemical equilibrium", "Calculate reaction rates"],
  50,
  [
    lessonSection("intro", "introduction", "Advanced Chemistry",
      "<p>Thermodynamics studies energy in chemical reactions.</p><p>Equilibrium: reactions reach balance point</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Energy diagrams", video: youtubeVideo("dQw4w9WgXcQ", "Thermodynamics", 220) }
    ),
    lessonSection("concept1", "concept", "Laws of Thermodynamics",
      "<p><strong>1st Law:</strong> energy conserved in system</p><p><strong>2nd Law:</strong> entropy increases (disorder)</p><p>ΔH = ΔU + PΔV (enthalpy change)</p>"
    ),
    lessonSection("concept2", "concept", "Chemical Equilibrium",
      "<p>K = [products]/[reactants] (equilibrium constant)</p><p>K > 1: favors products</p><p>K < 1: favors reactants</p>"
    ),
    lessonSection("concept3", "concept", "Reaction Rates",
      "<p>Rate = change in concentration / time</p><p>Factors: temperature, concentration, catalyst</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Exothermic reaction releases heat. Endothermic absorbs heat.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Thermodynamics: energy changes</li><li>Equilibrium: constant ratio</li><li>Rate depends on conditions</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "First law of thermodynamics:", ["energy conserved", "entropy increases", "enthalpy fixed"], "energy conserved", "easy", "Chemistry"),
    trueFalse("q2", "Entropy measures disorder", true, "easy", "Chemistry"),
    multipleChoice("q3", "Exothermic reaction:", ["releases heat", "absorbs heat", "no heat"], "releases heat", "easy", "Chemistry"),
    shortAnswer("q4", "K in equilibrium constant is:", "products/reactants", "easy", "Chemistry"),
    multipleChoice("q5", "K > 1 favors:", ["products", "reactants", "neither"], "products", "easy", "Chemistry"),
    trueFalse("q6", "Catalyst changes equilibrium position", false, "easy", "Chemistry"),
    shortAnswer("q7", "What is reaction rate unit?", "M/s or mol/L·s", "medium", "Chemistry"),
    multipleChoice("q8", "Higher temperature causes:", ["faster rate", "slower rate", "no change"], "faster rate", "medium", "Chemistry"),
    trueFalse("q9", "Equilibrium is static state", false, "medium", "Chemistry"),
    freeResponse("q10", "Explain Le Chatelier's Principle", "hard", "Chemistry"),
    trueFalse("q11", "Reversible reactions reach equilibrium", true, "hard", "Chemistry"),
    freeResponse("q12", "Calculate equilibrium constant from data", "hard", "Chemistry"),
  ]
);

export const science1112Physics: ComprehensiveLesson = createLesson(
  "science-11-12-physics",
  "advanced-physics",
  "Advanced Physics: Waves and Modern Physics",
  "11-12",
  "science",
  ["Understand wave properties", "Study light and sound", "Explore modern physics concepts"],
  50,
  [
    lessonSection("intro", "introduction", "Waves and Modern Physics",
      "<p>Waves transfer energy without moving matter.</p><p>Light and sound are waves. Modern physics: relativity, quantum mechanics</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Wave diagram", video: youtubeVideo("dQw4w9WgXcQ", "Waves", 220) }
    ),
    lessonSection("concept1", "concept", "Wave Properties",
      "<p><strong>Wavelength:</strong> distance between waves (λ)</p><p><strong>Frequency:</strong> waves per second (f)</p><p><strong>v = fλ</strong> (velocity = frequency × wavelength)</p>"
    ),
    lessonSection("concept2", "concept", "Sound and Light",
      "<p><strong>Sound:</strong> mechanical wave, needs medium</p><p><strong>Light:</strong> electromagnetic wave, travels through vacuum</p><p>Speed of light: c = 3×10⁸ m/s</p>"
    ),
    lessonSection("concept3", "concept", "Modern Physics",
      "<p><strong>Relativity:</strong> E = mc² (energy-mass equivalence)</p><p><strong>Quantum:</strong> particles and waves dual nature</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Sound frequency: 440 Hz (A note). Light wavelength: 700 nm (red)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>v = fλ for all waves</li><li>Sound vs light properties differ</li><li>E = mc² relates mass and energy</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Wave velocity equation:", ["v = f + λ", "v = fλ", "v = f/λ"], "v = f��", "easy", "Physics"),
    trueFalse("q2", "Sound needs medium to travel", true, "easy", "Physics"),
    multipleChoice("q3", "Speed of light:", ["3×10⁸ m/s", "3×10⁶ m/s", "3×10¹⁰ m/s"], "3×10⁸ m/s", "easy", "Physics"),
    shortAnswer("q4", "What is wavelength symbol?", "λ", "easy", "Physics"),
    multipleChoice("q5", "Light is:", ["mechanical", "electromagnetic", "acoustic"], "electromagnetic", "easy", "Physics"),
    trueFalse("q6", "Einstein's E = mc² shows mass-energy relation", true, "easy", "Physics"),
    shortAnswer("q7", "Frequency unit is:", "Hz or s⁻¹", "medium", "Physics"),
    multipleChoice("q8", "Higher frequency means:", ["longer wavelength", "shorter wavelength", "same wavelength"], "shorter wavelength", "medium", "Physics"),
    trueFalse("q9", "Light travels through vacuum", true, "medium", "Physics"),
    freeResponse("q10", "Explain wave and particle duality", "hard", "Physics"),
    trueFalse("q11", "Photoelectric effect explained by quantum theory", true, "hard", "Physics"),
    freeResponse("q12", "Calculate frequency from wavelength", "hard", "Physics"),
  ]
);

export const science1112Astronomy: ComprehensiveLesson = createLesson(
  "science-11-12-astronomy",
  "astronomy-universe",
  "Astronomy: Universe and Cosmology",
  "11-12",
  "science",
  ["Understand stellar evolution", "Analyze galaxy types", "Explore cosmology and Big Bang"],
  50,
  [
    lessonSection("intro", "introduction", "Astronomy",
      "<p>Astronomy studies celestial objects: stars, galaxies, universe.</p><p>Universe began with Big Bang 13.8 billion years ago</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Galaxy image", video: youtubeVideo("dQw4w9WgXcQ", "Astronomy", 220) }
    ),
    lessonSection("concept1", "concept", "Star Life Cycle",
      "<p><strong>Nebula:</strong> gas cloud</p><p><strong>Star:</strong> fuses hydrogen</p><p><strong>White Dwarf/Neutron Star/Black Hole:</strong> remnant</p><p>Hertzsprung-Russell diagram shows star types</p>"
    ),
    lessonSection("concept2", "concept", "Galaxies",
      "<p><strong>Spiral:</strong> arms with bulge (Milky Way)</p><p><strong>Elliptical:</strong> smooth, no arms</p><p><strong>Irregular:</strong> no clear shape</p>"
    ),
    lessonSection("concept3", "concept", "Cosmology",
      "<p><strong>Big Bang:</strong> universe began hot and dense</p><p><strong>Expansion:</strong> universe still expanding</p><p><strong>Dark Matter/Energy:</strong> most of universe</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Sun: mid-life main sequence star. Andromeda: nearest spiral galaxy. Cosmic background radiation: evidence of Big Bang</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Stars form, live, die</li><li>Galaxies contain billions of stars</li><li>Universe expanding from Big Bang</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Big Bang happened:", ["13.8 billion years ago", "4.5 billion years ago", "1 billion years ago"], "13.8 billion years ago", "easy", "Astronomy"),
    trueFalse("q2", "Stars fuse hydrogen to helium", true, "easy", "Astronomy"),
    multipleChoice("q3", "Spiral galaxy example:", ["Milky Way", "Andromeda", "both"], "both", "easy", "Astronomy"),
    shortAnswer("q4", "What is black hole remnant of?", "Massive star", "easy", "Astronomy"),
    multipleChoice("q5", "White dwarf is:", ["hot star", "star remnant", "new star"], "star remnant", "easy", "Astronomy"),
    trueFalse("q6", "Universe is expanding", true, "easy", "Astronomy"),
    shortAnswer("q7", "Galaxy with arms: ___ galaxy", "Spiral", "medium", "Astronomy"),
    multipleChoice("q8", "H-R diagram plots:", ["temperature vs luminosity", "distance vs mass", "age vs size"], "temperature vs luminosity", "medium", "Astronomy"),
    trueFalse("q9", "Dark matter is visible", false, "medium", "Astronomy"),
    freeResponse("q10", "Explain stellar evolution sequence", "hard", "Astronomy"),
    trueFalse("q11", "Red shift indicates galaxy moving away", true, "hard", "Astronomy"),
    freeResponse("q12", "Describe Big Bang and cosmic inflation", "hard", "Astronomy"),
  ]
);

export const science1112Environmental: ComprehensiveLesson = createLesson(
  "science-11-12-environmental",
  "environmental-science",
  "Environmental Science: Climate and Conservation",
  "11-12",
  "science",
  ["Understand climate change", "Analyze human impact", "Explore conservation solutions"],
  50,
  [
    lessonSection("intro", "introduction", "Environmental Science",
      "<p>Environmental science studies interactions between organisms and environment.</p><p>Climate change, pollution, biodiversity loss are major issues</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Earth and climate", video: youtubeVideo("dQw4w9WgXcQ", "Environmental", 220) }
    ),
    lessonSection("concept1", "concept", "Climate Change",
      "<p><strong>Greenhouse gases:</strong> CO₂, CH₄ trap heat</p><p><strong>Global warming:</strong> average temperature rising</p><p><strong>Feedback loops:</strong> melting ice reduces reflection</p>"
    ),
    lessonSection("concept2", "concept", "Human Impact",
      "<p><strong>Pollution:</strong> air, water, soil contamination</p><p><strong>Deforestation:</strong> reduces CO₂ absorption</p><p><strong>Biodiversity loss:</strong> extinction from habitat loss</p>"
    ),
    lessonSection("concept3", "concept", "Solutions",
      "<p><strong>Renewable energy:</strong> solar, wind, hydro</p><p><strong>Conservation:</strong> protect habitats, reduce consumption</p><p><strong>Sustainable practices:</strong> balance use with recovery</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>Paris Agreement: reduce emissions. Carbon sequestration: capture CO₂. Marine reserves: protect fish populations</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Climate warming from greenhouse gases</li><li>Humans impact environment significantly</li><li>Renewable energy and conservation help</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Main greenhouse gas:", ["nitrogen", "carbon dioxide", "oxygen"], "carbon dioxide", "easy", "Environmental"),
    trueFalse("q2", "Global temperatures are rising", true, "easy", "Environmental"),
    multipleChoice("q3", "Renewable energy:", ["depletes", "infinite", "pollutes"], "infinite", "easy", "Environmental"),
    shortAnswer("q4", "Name a greenhouse gas", "CO₂/CH₄/N₂O", "easy", "Environmental"),
    multipleChoice("q5", "Deforestation causes:", ["CO₂ absorption", "CO₂ release", "no change"], "CO₂ release", "easy", "Environmental"),
    trueFalse("q6", "Biodiversity increases with habitat loss", false, "easy", "Environmental"),
    shortAnswer("q7", "Feedback loop in climate: ice melts, reflection ___", "decreases", "medium", "Environmental"),
    multipleChoice("q8", "Best renewable energy:", ["coal", "natural gas", "solar/wind"], "solar/wind", "medium", "Environmental"),
    trueFalse("q9", "Conservation protects ecosystems", true, "medium", "Environmental"),
    freeResponse("q10", "Explain carbon cycle and climate change", "hard", "Environmental"),
    trueFalse("q11", "Ocean acidification from CO₂ dissolution", true, "hard", "Environmental"),
    freeResponse("q12", "Design sustainable solution for environment", "hard", "Environmental"),
  ]
);

// Export all science lessons
export const allScienceLessons = [
  scienceK2Weather,
  scienceK2Plants,
  scienceK2Animals,
  scienceK2LifeCycles,
  scienceK2Ecosystems,
  science35Matter,
  science35Forces,
  science35SimpleMachines,
  science35SolarSystem,
  science35WaterCycle,
  science68Cells,
  science68Genetics,
  science68Ecosystems,
  science68EarthSystems,
  science910Physics,
  science910Chemistry,
  science910Electricity,
  science1112Chemistry,
  science1112Physics,
  science1112Astronomy,
  science1112Environmental,
];

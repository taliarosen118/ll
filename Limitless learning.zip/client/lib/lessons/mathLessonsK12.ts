import { ComprehensiveLesson, createLesson, lessonSection, youtubeVideo, multipleChoice, shortAnswer, trueFalse, freeResponse, matching } from "@/lib/lessonContent";

// ============================================================================
// MATH K-2 (GRADES KINDERGARTEN TO 2)
// ============================================================================

export const mathK2Counting: ComprehensiveLesson = createLesson(
  "math-k2-counting",
  "counting-to-20",
  "Counting to 20",
  "K-2",
  "math",
  [
    "Count numbers 1-20 in sequence",
    "Identify number names and symbols",
    "Use one-to-one correspondence",
  ],
  25,
  [
    lessonSection(
      "intro",
      "introduction",
      "Welcome to Counting!",
      "<p>Counting is one of the most important skills in math! Today, we'll learn to count from 1 to 20. We'll practice saying the numbers, pointing to each one, and understanding that each number is one more than the number before it.</p><p><strong>Why is counting important?</strong> We use counting every day — counting toys, snacks, friends, and more!</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Ten colorful blocks numbered 1-10",
        video: youtubeVideo("dQw4w9WgXcQ", "Counting to 20 Song", 120),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Numbers 1-10",
      "<p>Let's start with 1 to 10. Each number is just one more than the last:</p><ul><li><strong>1</strong> - one item</li><li><strong>2</strong> - one more (one + one)</li><li><strong>3</strong> - one more (two + one)</li></ul><p>We can see this with our fingers! Hold up one finger, then two, then three.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Hands showing 1, 2, 3 fingers",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Numbers 11-20",
      "<p>Now let's count from 11 to 20:</p><p><strong>11, 12, 13, 14, 15, 16, 17, 18, 19, 20</strong></p><p>Notice that 11-19 have a special pattern. They all have 'teen' in their name, which means 'ten + more':</p><ul><li><strong>13</strong> = thir-<strong>teen</strong> (ten + three)</li><li><strong>15</strong> = fif-<strong>teen</strong> (ten + five)</li><li><strong>20</strong> = twenty (two tens)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Number line from 1 to 20",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Example: Counting Objects",
      "<p><strong>Example 1:</strong> You have a pile of blocks. How many are there?</p><p>Point to each block and count: 1, 2, 3, 4, 5. You have 5 blocks!</p><p><strong>Example 2:</strong> How many fingers do you have on both hands?</p><p>Count on your left hand: 1, 2, 3, 4, 5. Count on your right hand: 6, 7, 8, 9, 10. You have 10 fingers!</p><p>This is called <strong>one-to-one correspondence</strong> — each object gets counted exactly once.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Cartoon hands counting fingers",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Key Points to Remember",
      "<ul><li>Count in order: 1, 2, 3... 20</li><li>Each number is one more than the one before</li><li>Point to each object once when counting</li><li>The last number you say is how many there are</li><li>Practice counting every day!</li></ul><p><strong>Try this:</strong> Count the toys in your room, the stairs in your house, or the people in your family. See how high you can count!</p>"
    ),
  ],
  [
    multipleChoice("q1", "What comes after 5?", ["3", "4", "6", "7"], "6", "easy", "Counting", "Use your fingers!"),
    multipleChoice("q2", "How many fingers on one hand?", ["3", "5", "8", "10"], "5", "easy", "Counting"),
    multipleChoice("q3", "What number is between 14 and 16?", ["13", "15", "17", "18"], "15", "easy", "Counting"),
    shortAnswer("q4", "Count these: * * * * How many stars?", ["4", "four"], "easy", "Counting", "Point to each star"),
    trueFalse("q5", "17 is bigger than 12", true, "easy", "Counting"),
    multipleChoice("q6", "What comes next? 16, 17, 18, ___", ["19", "17", "16", "20"], "19", "medium", "Counting"),
    shortAnswer("q7", "Say all the numbers from 1 to 10 out loud. How many numbers did you say?", ["10", "ten"], "medium", "Counting"),
    trueFalse("q8", "The number 11 has 'teen' in it", true, "medium", "Counting"),
    shortAnswer("q9", "If you have 8 blocks and I give you 2 more, how many will you have?", "10", "medium", "Counting + Addition"),
    multipleChoice("q10", "Count: 1, 2, 3, 4, 5, 6, 7, 8, 9, ___ What's next?", ["8", "9", "10", "11"], "10", "medium", "Counting"),
    shortAnswer("q11", "Write the number that comes after 19", "20", "medium", "Counting"),
    freeResponse("q12", "Tell a story about counting. What did you count today?", "hard", "Counting"),
  ]
);

export const mathK2Addition: ComprehensiveLesson = createLesson(
  "math-k2-addition",
  "addition-within-10",
  "Addition Within 10",
  "K-2",
  "math",
  [
    "Understand addition as 'putting together'",
    "Add numbers within 10",
    "Use the + and = symbols",
  ],
  25,
  [
    lessonSection(
      "intro",
      "introduction",
      "What is Addition?",
      "<p>Addition means putting groups together to find how many in all!</p><p>If you have 2 apples and I give you 3 more apples, how many apples do you have now?</p><p><strong>2 + 3 = 5</strong></p><p>The <strong>+</strong> sign means 'add together' or 'put together'. The <strong>=</strong> sign means 'equals' or 'the answer is'.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Two apples plus three apples equals five apples",
        video: youtubeVideo("dQw4w9WgXcQ", "Addition for Kids", 150),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Putting Groups Together",
      "<p>Think of addition like this:</p><ul><li>You have a group of objects (like blocks, toys, or dots)</li><li>You add another group to it</li><li>You count how many there are in total</li></ul><p><strong>Example:</strong> You have 3 red blocks and 2 blue blocks.</p><p>Put them together: red, red, red, blue, blue</p><p>Count: 1, 2, 3, 4, 5</p><p>So 3 + 2 = 5</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "3 red blocks and 2 blue blocks arranged in a line",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Using a Number Line",
      "<p>A number line is a line with numbers on it. We can use it to add!</p><p><strong>Example: 4 + 2</strong></p><p>Start at 4 on the number line. Jump 2 spaces to the right: 5, 6. You land on 6!</p><p>So 4 + 2 = 6</p><p>The number line helps us see how addition works!</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Number line from 0 to 10 with a jump from 4 to 6",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Addition Examples",
      "<p><strong>Example 1: 5 + 1</strong></p><p>I have 5 cookies. My friend gives me 1 more cookie. Now I have 6 cookies. So 5 + 1 = 6</p><p><strong>Example 2: 2 + 3</strong></p><p>There are 2 birds in a tree. Then 3 more birds fly in. Now there are 5 birds. So 2 + 3 = 5</p><p><strong>Example 3: 4 + 4</strong></p><p>You have 4 fingers on your left hand and 4 fingers on your right hand. That's 4 + 4 = 8 fingers total! (Plus two thumbs!)</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Cartoon children with fingers counting",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Remember Addition",
      "<ul><li>Addition means putting groups together</li><li>The + sign means 'add' or 'put together'</li><li>The = sign means 'equals'</li><li>You can use fingers, blocks, pictures, or a number line</li><li>Start with the bigger number and count on!</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is 2 + 1?", ["1", "2", "3", "4"], "3", "easy", "Addition"),
    multipleChoice("q2", "What is 3 + 2?", ["3", "5", "6", "7"], "5", "easy", "Addition"),
    shortAnswer("q3", "Complete: 4 + ___ = 5", "1", "easy", "Addition"),
    multipleChoice("q4", "I have 2 toys and get 2 more. How many now?", ["2", "3", "4", "5"], "4", "easy", "Addition"),
    trueFalse("q5", "5 + 2 = 7", true, "easy", "Addition"),
    multipleChoice("q6", "What is 1 + 1 + 1?", ["1", "2", "3", "4"], "3", "medium", "Addition"),
    shortAnswer("q7", "Complete: 3 + 3 = ___", "6", "medium", "Addition"),
    multipleChoice("q8", "Maria has 4 stickers. Tom gives her 3 more. How many stickers does Maria have?", ["4", "6", "7", "8"], "7", "medium", "Addition"),
    trueFalse("q9", "4 + 4 = 8", true, "medium", "Addition"),
    shortAnswer("q10", "If you add 5 + 5, what do you get?", "10", "medium", "Addition"),
    freeResponse("q11", "Show me an addition problem using your fingers", "hard", "Addition"),
    multipleChoice("q12", "What is 2 + 3 + 2?", ["5", "6", "7", "8"], "7", "hard", "Addition"),
  ]
);

export const mathK2Subtraction: ComprehensiveLesson = createLesson(
  "math-k2-subtraction",
  "subtraction-within-10",
  "Subtraction Within 10",
  "K-2",
  "math",
  [
    "Understand subtraction as 'taking away'",
    "Subtract numbers within 10",
    "Use the - and = symbols",
  ],
  25,
  [
    lessonSection(
      "intro",
      "introduction",
      "What is Subtraction?",
      "<p>Subtraction means taking away or removing objects!</p><p>If you have 5 cookies and eat 2, how many cookies are left?</p><p><strong>5 - 2 = 3</strong></p><p>The <strong>-</strong> sign means 'subtract' or 'take away'. The <strong>=</strong> sign means 'equals' or 'the answer is'.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Five cookies with two crossed out, leaving three",
        video: youtubeVideo("dQw4w9WgXcQ", "Subtraction for Kids", 150),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Taking Away",
      "<p>Subtraction is when we start with a group and remove some:</p><ul><li>You start with a number (like 7 toys)</li><li>You take away some (like 3 toys)</li><li>You count how many are left</li></ul><p><strong>Example:</strong> Start with 7 blocks. Take away 2 blocks.</p><p>7 - 2 = 5 blocks left</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Seven blocks with two removed, five remaining",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Using a Number Line for Subtraction",
      "<p>We can use a number line to subtract too!</p><p><strong>Example: 8 - 3</strong></p><p>Start at 8. Jump back 3 spaces: 7, 6, 5. You land on 5!</p><p>So 8 - 3 = 5</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Number line from 0 to 10 with a jump from 8 back to 5",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Subtraction Examples",
      "<p><strong>Example 1: 6 - 1</strong></p><p>You have 6 apples. You eat 1 apple. You have 5 apples left. So 6 - 1 = 5</p><p><strong>Example 2: 9 - 4</strong></p><p>There are 9 birds on a branch. 4 birds fly away. 5 birds are left. So 9 - 4 = 5</p><p><strong>Example 3: 10 - 10</strong></p><p>You have 10 pennies. You spend all 10 pennies. You have 0 pennies left. So 10 - 10 = 0</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Cartoon apples and birds showing subtraction",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Remember Subtraction",
      "<ul><li>Subtraction means taking away</li><li>The - sign means 'subtract' or 'take away'</li><li>The = sign means 'equals'</li><li>You can use fingers, blocks, pictures, or a number line</li><li>Count how many are left after taking away</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is 5 - 1?", ["3", "4", "5", "6"], "4", "easy", "Subtraction"),
    multipleChoice("q2", "What is 7 - 2?", ["4", "5", "6", "7"], "5", "easy", "Subtraction"),
    shortAnswer("q3", "Complete: 6 - 2 = ___", "4", "easy", "Subtraction"),
    multipleChoice("q4", "I have 8 crayons and lose 3. How many do I have now?", ["4", "5", "6", "7"], "5", "easy", "Subtraction"),
    trueFalse("q5", "9 - 3 = 6", true, "easy", "Subtraction"),
    multipleChoice("q6", "What is 10 - 5?", ["3", "4", "5", "6"], "5", "medium", "Subtraction"),
    shortAnswer("q7", "Complete: 8 - 3 = ___", "5", "medium", "Subtraction"),
    multipleChoice("q8", "Ben has 9 stickers and gives 4 to his sister. How many does he have left?", ["4", "5", "6", "7"], "5", "medium", "Subtraction"),
    trueFalse("q9", "6 - 4 = 2", true, "medium", "Subtraction"),
    shortAnswer("q10", "If you subtract 7 - 7, what do you get?", "0", "medium", "Subtraction"),
    freeResponse("q11", "Tell a story about subtraction. What did you take away?", "hard", "Subtraction"),
    multipleChoice("q12", "What is 10 - 2 - 3?", ["4", "5", "6", "7"], "5", "hard", "Subtraction"),
  ]
);

export const mathK2Shapes: ComprehensiveLesson = createLesson(
  "math-k2-shapes",
  "shapes-and-patterns",
  "Shapes and Patterns",
  "K-2",
  "math",
  [
    "Identify basic shapes (circle, square, triangle, rectangle)",
    "Count sides and corners of shapes",
    "Recognize and create patterns",
  ],
  25,
  [
    lessonSection(
      "intro",
      "introduction",
      "Welcome to Shapes!",
      "<p>Shapes are all around us! Circles, squares, triangles, and rectangles are basic shapes we see every day.</p><p><strong>Where do we see shapes?</strong></p><ul><li>Circles: wheels, plates, balls</li><li>Squares: tiles, blocks, windows</li><li>Triangles: pizza slices, roofs, mountains</li><li>Rectangles: doors, books, tables</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Four basic shapes: circle, square, triangle, rectangle",
        video: youtubeVideo("dQw4w9WgXcQ", "Shapes for Kids", 120),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Basic Shapes",
      "<p><strong>Circle:</strong> Round with no sides or corners. Like a pizza or a ball.</p><p><strong>Square:</strong> 4 sides that are all the same length. 4 corners. Like a tile on the floor.</p><p><strong>Triangle:</strong> 3 sides. 3 corners. Like a slice of pizza.</p><p><strong>Rectangle:</strong> 4 sides. 4 corners. Sides go in pairs. Like a door or a book.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Detailed view of each basic shape with labels",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Sides and Corners",
      "<p>When we talk about shapes, we count <strong>sides</strong> and <strong>corners</strong>.</p><ul><li><strong>Sides</strong> are the straight lines that make up the shape</li><li><strong>Corners</strong> (or angles) are where two sides meet</li></ul><p><strong>Examples:</strong></p><ul><li>Triangle: 3 sides, 3 corners</li><li>Square: 4 sides, 4 corners</li><li>Rectangle: 4 sides, 4 corners</li><li>Circle: 0 sides, 0 corners</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Shapes with sides and corners labeled",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Shapes Examples",
      "<p><strong>Example 1:</strong> Look at this shape. It has 4 equal sides and 4 corners. This is a <strong>square</strong>!</p><p><strong>Example 2:</strong> This shape is round with no corners. This is a <strong>circle</strong>!</p><p><strong>Example 3:</strong> This shape has 3 sides and 3 corners. This is a <strong>triangle</strong>!</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Examples of each shape with labels",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Shape Facts",
      "<ul><li>Circle: round, 0 sides, 0 corners</li><li>Triangle: 3 sides, 3 corners</li><li>Square: 4 equal sides, 4 corners</li><li>Rectangle: 4 sides, 4 corners (opposite sides equal)</li><li>Shapes are everywhere!</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "How many sides does a square have?", ["2", "3", "4", "5"], "4", "easy", "Shapes"),
    multipleChoice("q2", "How many corners does a triangle have?", ["2", "3", "4", "5"], "3", "easy", "Shapes"),
    multipleChoice("q3", "Which shape is round?", ["square", "triangle", "circle", "rectangle"], "circle", "easy", "Shapes"),
    shortAnswer("q4", "How many sides does a triangle have?", "3", "easy", "Shapes"),
    trueFalse("q5", "A rectangle has 4 corners", true, "easy", "Shapes"),
    multipleChoice("q6", "What shape is a pizza slice?", ["circle", "square", "triangle", "rectangle"], "triangle", "medium", "Shapes"),
    shortAnswer("q7", "A circle has ___ sides", "0", "medium", "Shapes"),
    multipleChoice("q8", "Which shape is a door?", ["circle", "square", "triangle", "rectangle"], "rectangle", "medium", "Shapes"),
    trueFalse("q9", "A square is the same as a rectangle", false, "medium", "Shapes"),
    shortAnswer("q10", "How many corners does a square have?", "4", "medium", "Shapes"),
    multipleChoice("q11", "A wheel is shaped like a ___", ["square", "triangle", "circle", "rectangle"], "circle", "hard", "Shapes"),
    freeResponse("q12", "Look around your room. Name 3 objects and tell what shapes they are", "hard", "Shapes"),
  ]
);

export const mathK2Money: ComprehensiveLesson = createLesson(
  "math-k2-money",
  "coins-and-money",
  "Coins and Money",
  "K-2",
  "math",
  [
    "Identify coins (penny, nickel, dime, quarter)",
    "Count money",
    "Understand the value of coins",
  ],
  25,
  [
    lessonSection(
      "intro",
      "introduction",
      "Learning About Money",
      "<p>Money is what we use to buy things! In the United States, we use coins and bills.</p><p>Let's learn about coins:</p><ul><li>Penny (1¢)</li><li>Nickel (5¢)</li><li>Dime (10¢)</li><li>Quarter (25¢)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Penny, nickel, dime, and quarter coins",
        video: youtubeVideo("dQw4w9WgXcQ", "Coins for Kids", 120),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Know Your Coins",
      "<p><strong>Penny:</strong> Brown color. Worth 1¢. Shows Abraham Lincoln.</p><p><strong>Nickel:</strong> Silver color. Worth 5¢. Shows Thomas Jefferson.</p><p><strong>Dime:</strong> Silver, smaller than a nickel. Worth 10¢. Shows Franklin D. Roosevelt.</p><p><strong>Quarter:</strong> Silver, largest coin. Worth 25¢. Shows George Washington.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Detailed view of each coin with labels and values",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Counting Money",
      "<p>When we count coins, we add up all their values:</p><p><strong>Example:</strong> If I have 1 dime and 5 pennies, how much money do I have?</p><ul><li>Dime = 10¢</li><li>5 Pennies = 5 × 1¢ = 5¢</li><li>Total = 10¢ + 5¢ = 15¢</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Coins arranged and counted with values shown",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Money Examples",
      "<p><strong>Example 1:</strong> You have 2 quarters. How much money is that?</p><p>25¢ + 25¢ = 50¢</p><p><strong>Example 2:</strong> You have 1 dime, 1 nickel, and 3 pennies. How much?</p><p>10¢ + 5¢ + 3¢ = 18¢</p><p><strong>Example 3:</strong> A toy costs 25¢. You have 1 quarter. Can you buy it?</p><p>Yes! You have exactly 25¢!</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Toy with price tag and coins shown",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Coin Facts",
      "<ul><li>Penny = 1¢</li><li>Nickel = 5¢</li><li>Dime = 10¢</li><li>Quarter = 25¢</li><li>To count money, add up all the coin values</li><li>Money helps us buy things we need and want</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "How much is a penny worth?", ["1¢", "5¢", "10¢", "25¢"], "1¢", "easy", "Money"),
    multipleChoice("q2", "How much is a dime worth?", ["1¢", "5¢", "10¢", "25¢"], "10¢", "easy", "Money"),
    shortAnswer("q3", "A quarter is worth ___¢", "25", "easy", "Money"),
    multipleChoice("q4", "What coin is brown?", ["penny", "nickel", "dime", "quarter"], "penny", "easy", "Money"),
    trueFalse("q5", "A nickel is worth 5¢", true, "easy", "Money"),
    multipleChoice("q6", "You have 2 dimes. How much money do you have?", ["10¢", "15¢", "20¢", "25¢"], "20¢", "medium", "Money"),
    shortAnswer("q7", "You have 1 quarter and 2 dimes. How much money? ___¢", "45", "medium", "Money"),
    multipleChoice("q8", "A candy costs 10¢. You have 1 dime. Can you buy it?", ["yes", "no", "maybe"], "yes", "medium", "Money"),
    trueFalse("q9", "5 pennies equal 1 nickel", true, "medium", "Money"),
    shortAnswer("q10", "You have 1 nickel and 3 pennies. How much? ___¢", "8", "medium", "Money"),
    multipleChoice("q11", "Which is worth the most?", ["penny", "nickel", "dime", "quarter"], "quarter", "hard", "Money"),
    freeResponse("q12", "Draw the coins you need to make 30¢", "hard", "Money"),
  ]
);

// ============================================================================
// MATH 3-5 (GRADES 3 TO 5)
// ============================================================================

export const math35Fractions: ComprehensiveLesson = createLesson(
  "math-3-5-fractions",
  "fractions-basics",
  "Fractions: Parts of a Whole",
  "3-5",
  "math",
  [
    "Understand fractions as parts of a whole",
    "Identify numerators and denominators",
    "Compare and order fractions",
  ],
  30,
  [
    lessonSection(
      "intro",
      "introduction",
      "What Are Fractions?",
      "<p>A <strong>fraction</strong> is a part of a whole thing. When we divide something into equal parts, each part is a fraction of the whole.</p><p><strong>Examples:</strong></p><ul><li>If you cut a pizza into 4 equal slices, each slice is 1/4 (one-fourth) of the pizza</li><li>If you eat 2 slices, you've eaten 2/4 (two-fourths) of the pizza</li><li>1/2 means the same as 2/4 (one-half equals two-fourths)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Pizza divided into 4 slices with fractions labeled",
        video: youtubeVideo("dQw4w9WgXcQ", "Fractions Explained", 150),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Numerator and Denominator",
      "<p>Every fraction has two parts:</p><p><strong>The Numerator (top number)</strong> tells how many parts we have.</p><p><strong>The Denominator (bottom number)</strong> tells how many equal parts the whole is divided into.</p><p>In the fraction 3/4:</p><ul><li><strong>3</strong> is the numerator (we have 3 parts)</li><li><strong>4</strong> is the denominator (the whole is divided into 4 parts)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Fraction 3/4 with numerator and denominator labeled",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Common Fractions",
      "<p><strong>1/2 (one-half)</strong> = the whole divided into 2 equal parts. You have 1 part.</p><p><strong>1/3 (one-third)</strong> = the whole divided into 3 equal parts. You have 1 part.</p><p><strong>1/4 (one-fourth)</strong> = the whole divided into 4 equal parts. You have 1 part.</p><p><strong>3/4 (three-fourths)</strong> = the whole divided into 4 equal parts. You have 3 parts.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Bar models showing 1/2, 1/3, 1/4, and 3/4",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Fraction Examples",
      "<p><strong>Example 1: Apple Slices</strong></p><p>You have an apple cut into 8 equal slices. You eat 3 slices. You ate 3/8 of the apple.</p><p><strong>Example 2: Chocolate Bar</strong></p><p>A chocolate bar has 10 pieces. You eat 4 pieces. You ate 4/10 of the chocolate bar.</p><p><strong>Example 3: Class Attendance</strong></p><p>There are 20 students in class. 15 are here. That's 15/20 of the class.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Apple, chocolate bar, and classroom examples",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Fraction Facts",
      "<ul><li>A fraction is part of a whole</li><li>The numerator (top) tells how many parts</li><li>The denominator (bottom) tells how many equal parts total</li><li>1/2 means half</li><li>1/4 means one-fourth or one quarter</li><li>More numerator = bigger fraction</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What fraction is shaded? (1/4 shaded)", ["1/2", "1/3", "1/4", "1/5"], "1/4", "easy", "Fractions"),
    shortAnswer("q2", "In the fraction 3/8, what is the numerator?", "3", "easy", "Fractions"),
    multipleChoice("q3", "Which fraction means 'half'?", ["1/3", "1/2", "1/4", "1/5"], "1/2", "easy", "Fractions"),
    trueFalse("q4", "In 5/6, the denominator is 5", false, "easy", "Fractions"),
    multipleChoice("q5", "Which is bigger, 2/4 or 3/4?", ["2/4", "3/4", "same"], "3/4", "easy", "Fractions"),
    shortAnswer("q6", "If a pizza has 6 slices and you eat 2, you ate ___/6 of the pizza", "2", "medium", "Fractions"),
    multipleChoice("q7", "What fraction is shaded? (3/8 shaded)", ["1/4", "2/8", "3/8", "5/8"], "3/8", "medium", "Fractions"),
    trueFalse("q8", "1/2 equals 2/4", true, "medium", "Fractions"),
    shortAnswer("q9", "Which is bigger: 1/3 or 1/2?", "1/2", "medium", "Fractions"),
    multipleChoice("q10", "If you divide a cake into 10 equal pieces and take 7, you have ___/10", ["3/10", "7/10", "10/7", "7/3"], "7/10", "medium", "Fractions"),
    trueFalse("q11", "3/4 is less than 1/2", false, "hard", "Fractions"),
    freeResponse("q12", "Draw a rectangle divided into 6 equal parts and shade 4/6", "hard", "Fractions"),
  ]
);

export const math35Decimals: ComprehensiveLesson = createLesson(
  "math-3-5-decimals",
  "decimals-basics",
  "Decimals: Understanding Tenths and Hundredths",
  "3-5",
  "math",
  [
    "Understand decimals as parts of a whole",
    "Connect fractions and decimals",
    "Read and write decimal numbers",
  ],
  30,
  [
    lessonSection(
      "intro",
      "introduction",
      "What Are Decimals?",
      "<p>A <strong>decimal</strong> is another way to show a part of a whole, just like a fraction!</p><p>Decimals use a <strong>decimal point</strong> (a dot) to separate the whole number from the parts.</p><p><strong>Examples:</strong></p><ul><li>0.5 (zero point five) = 1/2 (one-half)</li><li>0.25 (zero point two five) = 1/4 (one-fourth)</li><li>1.5 (one point five) = 1 1/2 (one and one-half)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Decimal examples with fractions",
        video: youtubeVideo("dQw4w9WgXcQ", "Decimals for Kids", 150),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Tenths and Hundredths",
      "<p>Decimals can show tenths and hundredths:</p><p><strong>Tenths:</strong> 0.1, 0.2, 0.3, ... 0.9</p><ul><li>0.1 = 1/10 (one-tenth)</li><li>0.5 = 5/10 = 1/2 (five-tenths)</li></ul><p><strong>Hundredths:</strong> 0.01, 0.02, ... 0.99</p><ul><li>0.01 = 1/100 (one-hundredth)</li><li>0.25 = 25/100 = 1/4 (twenty-five hundredths)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Grid showing tenths and hundredths",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Reading Decimals",
      "<p>How to read a decimal number:</p><p>0.7 = \"zero point seven\" = seven-tenths</p><p>1.25 = \"one point two five\" = one and twenty-five hundredths</p><p>3.08 = \"three point zero eight\" = three and eight hundredths</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Decimal numbers with pronunciation guide",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Decimal Examples",
      "<p><strong>Example 1: Money</strong></p><p>$1.50 (one dollar and fifty cents) = 1.5 as a decimal</p><p><strong>Example 2: Measurement</strong></p><p>A pencil is 7.5 inches long (seven and five-tenths inches)</p><p><strong>Example 3: Fractions to Decimals</strong></p><p>1/4 of a dollar = $0.25 (twenty-five cents)</p><p>3/10 of something = 0.3 (three-tenths)</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Money, pencil, and grid examples with decimals",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Decimal Facts",
      "<ul><li>Decimals are parts of a whole</li><li>The decimal point separates whole numbers from parts</li><li>One decimal place = tenths (0.1 = 1/10)</li><li>Two decimal places = hundredths (0.01 = 1/100)</li><li>Decimals and fractions are connected</li><li>Money uses decimals (dollars and cents)</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is 0.5 as a fraction?", ["1/4", "1/2", "1/10", "1/100"], "1/2", "easy", "Decimals"),
    shortAnswer("q2", "0.3 means ___ tenths", "3", "easy", "Decimals"),
    multipleChoice("q3", "How do you read 0.7?", ["zero point seven", "seven point zero", "seven tenths", "zero sevenths"], "zero point seven", "easy", "Decimals"),
    trueFalse("q4", "0.25 is bigger than 0.5", false, "easy", "Decimals"),
    multipleChoice("q5", "What is 1/4 as a decimal?", ["0.25", "0.5", "0.75", "1.4"], "0.25", "easy", "Decimals"),
    shortAnswer("q6", "0.6 + 0.2 = ___", "0.8", "medium", "Decimals"),
    multipleChoice("q7", "Which is bigger, 0.4 or 0.7?", ["0.4", "0.7", "same"], "0.7", "medium", "Decimals"),
    trueFalse("q8", "0.10 equals 0.1", true, "medium", "Decimals"),
    shortAnswer("q9", "If you have $0.75, you have ___ quarters", "3", "medium", "Decimals"),
    multipleChoice("q10", "What is 3/10 as a decimal?", ["0.3", "0.03", "3.0", "0.13"], "0.3", "medium", "Decimals"),
    trueFalse("q11", "0.99 is less than 1.0", true, "hard", "Decimals"),
    freeResponse("q12", "Show 0.5 as a fraction and draw it", "hard", "Decimals"),
  ]
);

export const math35LongDivision: ComprehensiveLesson = createLesson(
  "math-3-5-long-division",
  "long-division",
  "Long Division",
  "3-5",
  "math",
  [
    "Understand the concept of division",
    "Perform long division with 2-digit divisors",
    "Check division with multiplication",
  ],
  35,
  [
    lessonSection(
      "intro",
      "introduction",
      "What is Division?",
      "<p>Division means sharing equally or splitting into groups.</p><p>If you have 12 cookies and want to share them equally with 3 friends, each friend gets 4 cookies.</p><p><strong>12 ÷ 3 = 4</strong></p><p>We write division problems in two ways:</p><ul><li><strong>12 ÷ 3 = 4</strong> (horizontal)</li><li><strong>12 ÷ 3 = 4</strong> (with division symbol)</li></ul>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Twelve cookies divided among 3 friends",
        video: youtubeVideo("dQw4w9WgXcQ", "Long Division Explained", 180),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "The Parts of Division",
      "<p>In a division problem, we have three parts:</p><p><strong>Dividend</strong> = the number being divided (12)</p><p><strong>Divisor</strong> = the number we're dividing by (3)</p><p><strong>Quotient</strong> = the answer (4)</p><p>12 ÷ 3 = 4</p><p>Dividend ÷ Divisor = Quotient</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Division problem with parts labeled",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Long Division Steps",
      "<p><strong>To divide 456 ÷ 12:</strong></p><p><strong>Step 1:</strong> Look at the first digits. 45 ÷ 12 = 3 (12 goes into 45 three times)</p><p><strong>Step 2:</strong> Multiply: 3 × 12 = 36</p><p><strong>Step 3:</strong> Subtract: 45 - 36 = 9</p><p><strong>Step 4:</strong> Bring down the next digit: 96</p><p><strong>Step 5:</strong> Divide: 96 ÷ 12 = 8</p><p><strong>Step 6:</strong> Multiply: 8 × 12 = 96</p><p><strong>Step 7:</strong> Subtract: 96 - 96 = 0</p><p><strong>Answer: 456 ÷ 12 = 38</strong></p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Long division worked out step by step",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Division Examples",
      "<p><strong>Example 1: 84 ÷ 7</strong></p><p>7 goes into 84 twelve times. 84 ÷ 7 = 12</p><p><strong>Example 2: 144 ÷ 12</strong></p><p>12 goes into 144 twelve times. 144 ÷ 12 = 12</p><p><strong>Example 3: Real World</strong></p><p>You have 96 stickers and want to put them equally in 8 packs. 96 ÷ 8 = 12 stickers per pack</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Long division examples with answers",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Division Facts",
      "<ul><li>Division means sharing equally</li><li>12 ÷ 3 = 4 means \"12 divided by 3 equals 4\"</li><li>Dividend ÷ Divisor = Quotient</li><li>To check: Quotient × Divisor = Dividend</li><li>Practice long division steps carefully</li><li>Division and multiplication are opposites</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What is 20 ÷ 4?", ["4", "5", "6", "7"], "5", "easy", "Division"),
    shortAnswer("q2", "Complete: 24 ÷ 6 = ___", "4", "easy", "Division"),
    multipleChoice("q3", "In 35 ÷ 5 = 7, what is the quotient?", ["35", "5", "7", "0"], "7", "easy", "Division"),
    trueFalse("q4", "32 ÷ 8 = 4", true, "easy", "Division"),
    multipleChoice("q5", "What is 56 ÷ 7?", ["6", "7", "8", "9"], "8", "easy", "Division"),
    shortAnswer("q6", "Complete: 72 ÷ 9 = ___", "8", "medium", "Division"),
    multipleChoice("q7", "What is 144 ÷ 12?", ["10", "11", "12", "13"], "12", "medium", "Division"),
    trueFalse("q8", "60 ÷ 10 = 6", true, "medium", "Division"),
    shortAnswer("q9", "To check 48 ÷ 6 = 8, I would calculate ___ × 6", "8", "medium", "Division"),
    multipleChoice("q10", "If you share 96 stickers equally among 8 friends, each gets ___ stickers", ["10", "11", "12", "13"], "12", "medium", "Division"),
    trueFalse("q11", "100 ÷ 5 = 20", true, "hard", "Division"),
    multipleChoice("q12", "What is 256 ÷ 16?", ["12", "14", "16", "18"], "16", "hard", "Division"),
  ]
);

export const math35WordProblems: ComprehensiveLesson = createLesson(
  "math-3-5-word-problems",
  "word-problems",
  "Solving Word Problems",
  "3-5",
  "math",
  [
    "Read and understand word problems",
    "Identify the operation needed",
    "Solve multi-step word problems",
  ],
  30,
  [
    lessonSection(
      "intro",
      "introduction",
      "What Are Word Problems?",
      "<p>A <strong>word problem</strong> tells a story using math. Instead of just seeing \"5 + 3 = ?\", we read: \"Maria had 5 apples. Her friend gave her 3 more apples. How many apples does Maria have now?\"</p><p>Word problems help us use math in real life!</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Maria with apples illustration",
        video: youtubeVideo("dQw4w9WgXcQ", "Solving Word Problems", 150),
      }
    ),
    lessonSection(
      "concept1",
      "concept",
      "Four Steps to Solve Word Problems",
      "<p><strong>Step 1: READ</strong> the problem carefully. Understand the story.</p><p><strong>Step 2: IDENTIFY</strong> what we know and what we need to find.</p><p><strong>Step 3: CHOOSE</strong> the right operation (add, subtract, multiply, or divide).</p><p><strong>Step 4: SOLVE</strong> and CHECK your answer.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Four steps listed with examples",
      }
    ),
    lessonSection(
      "concept2",
      "concept",
      "Which Operation to Use?",
      "<p><strong>Use ADDITION when:</strong> You're putting things together or combining groups.</p><p><strong>Use SUBTRACTION when:</strong> You're taking away, removing, or finding the difference.</p><p><strong>Use MULTIPLICATION when:</strong> You have equal groups and want the total.</p><p><strong>Use DIVISION when:</strong> You're sharing equally or splitting into groups.</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Operations guide with examples and keywords",
      }
    ),
    lessonSection(
      "example",
      "example",
      "Word Problem Examples",
      "<p><strong>Example 1: Addition</strong></p><p>Tom has 15 baseball cards. His sister gives him 12 more. How many does he have now?</p><p>15 + 12 = 27 cards</p><p><strong>Example 2: Subtraction</strong></p><p>There are 48 students in the cafeteria. 13 leave. How many are still there?</p><p>48 - 13 = 35 students</p><p><strong>Example 3: Multiplication</strong></p><p>There are 6 bags with 8 apples in each. How many apples total?</p><p>6 × 8 = 48 apples</p><p><strong>Example 4: Division</strong></p><p>You have 24 cookies to share equally with 4 friends. How many does each friend get?</p><p>24 ÷ 4 = 6 cookies each</p>",
      {
        imageUrl: "/placeholder.svg",
        imageAlt: "Pictures for each word problem example",
      }
    ),
    lessonSection(
      "summary",
      "summary",
      "Word Problem Tips",
      "<ul><li>Read the problem carefully</li><li>Underline the question</li><li>Circle the numbers</li><li>Identify what operation to use</li><li>Solve step by step</li><li>Check if your answer makes sense</li><li>Write your answer with units (like 'apples' or 'dollars')</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Sarah has 8 markers. She buys 5 more. How many does she have now?", ["3", "8", "13", "40"], "13", "easy", "Word Problems"),
    shortAnswer("q2", "There are 12 students. 3 leave. How many are left?", "9", "easy", "Word Problems"),
    multipleChoice("q3", "You buy 4 packs of gum with 5 pieces each. How many pieces total?", ["9", "20", "1", "4"], "20", "easy", "Word Problems"),
    trueFalse("q4", "To find 'how many are left', use subtraction", true, "easy", "Word Problems"),
    multipleChoice("q5", "Mom has $50. She spends $15. How much does she have left?", ["$35", "$65", "$15", "$50"], "$35", "easy", "Word Problems"),
    shortAnswer("q6", "There are 24 desks in a classroom. They're arranged in 6 rows equally. How many desks per row?", "4", "medium", "Word Problems"),
    multipleChoice("q7", "A recipe needs 3 cups of flour. You're making the recipe 5 times. How much flour total?", ["8", "15", "2", "3"], "15", "medium", "Word Problems"),
    trueFalse("q8", "To find 'how many are there in total', use multiplication", true, "medium", "Word Problems"),
    shortAnswer("q9", "Jason reads 12 pages on Monday and 15 pages on Tuesday. How many pages total?", "27", "medium", "Word Problems"),
    multipleChoice("q10", "A toy costs $18. You have $50. How much change do you get?", ["$32", "$68", "$18", "$50"], "$32", "medium", "Word Problems"),
    trueFalse("q11", "In word problems, always add the numbers together", false, "hard", "Word Problems"),
    freeResponse("q12", "Write your own word problem and solve it", "hard", "Word Problems"),
  ]
);

// Export all Math lessons
export const allMathLessonsK12 = [
  mathK2Counting,
  mathK2Addition,
  mathK2Subtraction,
  mathK2Shapes,
  mathK2Money,
  math35Fractions,
  math35Decimals,
  math35LongDivision,
  math35WordProblems,
];

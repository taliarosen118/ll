import { ComprehensiveLesson, createLesson, lessonSection, youtubeVideo, multipleChoice, shortAnswer, trueFalse, freeResponse } from "@/lib/lessonContent";

// ============================================================================
// ENGLISH K-2 (GRADES KINDERGARTEN TO 2)
// ============================================================================

export const englishK2Phonics: ComprehensiveLesson = createLesson(
  "english-k2-phonics",
  "phonics-sounds",
  "Phonics: Letter Sounds",
  "K-2",
  "english",
  ["Identify letter sounds", "Blend sounds into words", "Begin reading simple words"],
  25,
  [
    lessonSection("intro", "introduction", "Learning Letter Sounds",
      "<p>Each letter makes a sound. When we blend sounds together, we make words!</p><p><strong>Example:</strong> /c/ /a/ /t/ = cat</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Letter sound cards", video: youtubeVideo("dQw4w9WgXcQ", "Phonics Song", 120) }
    ),
    lessonSection("concept1", "concept", "Consonants",
      "<p>Consonants: b, c, d, f, g, h, j, k, l, m, n, p, r, s, t, v, w, y, z</p><p>Each has a special sound</p>"
    ),
    lessonSection("concept2", "concept", "Vowels",
      "<p>Vowels: a, e, i, o, u</p><p>Vowel sounds are open sounds</p>"
    ),
    lessonSection("example", "example", "Sound Examples",
      "<p>/b/ = bat, ball, big</p><p>/c/ = cat, car, cup</p><p>/a/ = apple, at, and</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Letters make sounds</li><li>Consonants and vowels</li><li>Blend sounds to read words</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "What sound does 'c' make?", ["/k/", "/s/", "/ch/"], "/k/", "easy", "Phonics"),
    trueFalse("q2", "Vowels include a, e, i, o, u", true, "easy", "Phonics"),
    multipleChoice("q3", "'bat' has sounds:", ["/b/ /a/ /t/", "/b/ /at/"], "/b/ /a/ /t/", "easy", "Phonics"),
    shortAnswer("q4", "What sound does 'm' make?", "/m/", "easy", "Phonics"),
    trueFalse("q6", "'cat' is /c/ /a/ /t/", true, "easy", "Phonics"),
    shortAnswer("q7", "Say sounds in 'sit'", "/s/ /i/ /t/", "medium", "Phonics"),
    multipleChoice("q8", "Vowel sounds are:", ["closed", "open", "hard"], "open", "medium", "Phonics"),
    freeResponse("q9", "Give words starting with /d/", "hard", "Phonics"),
    trueFalse("q10", "All letters are vowels", false, "easy", "Phonics"),
    freeResponse("q11", "Blend sounds to make a word", "hard", "Phonics"),
    trueFalse("q12", "Consonants and vowels work together", true, "medium", "Phonics"),
  ]
);

export const englishK2SightWords: ComprehensiveLesson = createLesson(
  "english-k2-sight",
  "sight-words",
  "Sight Words",
  "K-2",
  "english",
  ["Recognize common sight words", "Read sight words fluently", "Use sight words in sentences"],
  25,
  [
    lessonSection("intro", "introduction", "Sight Words",
      "<p><strong>Sight words</strong> are words we recognize quickly without sounding them out.</p><p>Examples: the, and, is, a, to, in</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Sight word cards", video: youtubeVideo("dQw4w9WgXcQ", "Sight Words", 120) }
    ),
    lessonSection("concept1", "concept", "Common Words",
      "<p>the, and, is, a, to, in, it, you, of, for</p><p>These appear in many books</p>"
    ),
    lessonSection("concept2", "concept", "More Sight Words",
      "<p>he, she, we, be, have, has, are, was, on, at</p>"
    ),
    lessonSection("example", "example", "Sentences",
      "<p>'The cat is in the house.'</p><p>'She and he are happy.'</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Sight words are common</li><li>Memorize them</li><li>Makes reading faster</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Which is a sight word?", ["cat", "the", "dog"], "the", "easy", "Sight Words"),
    trueFalse("q2", "'and' is a sight word", true, "easy", "Sight Words"),
    multipleChoice("q3", "Sight word means:", ["common word", "tricky word", "long word"], "common word", "easy", "Sight Words"),
    shortAnswer("q4", "Complete: 'The ___ is red' (use sight word)", "cat/dog", "easy", "Sight Words"),
    trueFalse("q6", "We sound out sight words", false, "easy", "Sight Words"),
    shortAnswer("q7", "Name a sight word", "the/and/is", "medium", "Sight Words"),
    multipleChoice("q8", "Sight words help:", ["read faster", "spell better", "talk more"], "read faster", "medium", "Sight Words"),
    freeResponse("q9", "Write sentence with sight words", "hard", "Sight Words"),
    trueFalse("q10", "All words are sight words", false, "easy", "Sight Words"),
    freeResponse("q11", "List 5 sight words", "hard", "Sight Words"),
    trueFalse("q12", "Sight words must be memorized", true, "medium", "Sight Words"),
  ]
);

export const englishK2CVC: ComprehensiveLesson = createLesson(
  "english-k2-cvc",
  "cvc-words",
  "CVC Words: Consonant-Vowel-Consonant",
  "K-2",
  "english",
  ["Recognize CVC pattern", "Read CVC words", "Write simple CVC words"],
  25,
  [
    lessonSection("intro", "introduction", "CVC Words",
      "<p><strong>CVC</strong> = Consonant-Vowel-Consonant</p><p>Examples: cat, dog, sit, big, run</p><p>These are basic words kids learn first</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "CVC word examples", video: youtubeVideo("dQw4w9WgXcQ", "CVC Words", 120) }
    ),
    lessonSection("concept1", "concept", "Pattern",
      "<p>Consonant + Vowel + Consonant = CVC</p><p>c + a + t = cat</p><p>d + o + g = dog</p>"
    ),
    lessonSection("concept2", "concept", "More Examples",
      "<p>sit, bit, fit, hit, lit</p><p>run, sun, fun, bun, gun</p><p>bed, led, red, wed, fed</p>"
    ),
    lessonSection("example", "example", "Reading CVC",
      "<p>'The cat sat on the mat.'</p><p>'The dog ran in the sun.'</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>CVC = 3 letter pattern</li><li>Easy to read and spell</li><li>Important for early reading</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "CVC means:", ["consonant-vowel-consonant", "consonant-consonant-vowel", "vowel-consonant-vowel"], "consonant-vowel-consonant", "easy", "CVC"),
    trueFalse("q2", "'cat' is a CVC word", true, "easy", "CVC"),
    multipleChoice("q3", "'sit' = s + i + t:", ["yes", "no"], "yes", "easy", "CVC"),
    shortAnswer("q4", "Is 'dog' CVC?", "Yes", "easy", "CVC"),
    trueFalse("q6", "CVC words are easy to learn", true, "easy", "CVC"),
    shortAnswer("q7", "Give a CVC word", "cat/dog/sit", "medium", "CVC"),
    multipleChoice("q8", "Which is CVC?", ["cat", "string", "apple"], "cat", "medium", "CVC"),
    freeResponse("q9", "Write 3 CVC words", "hard", "CVC"),
    trueFalse("q10", "All 3-letter words are CVC", false, "easy", "CVC"),
    freeResponse("q11", "Write CVC sentence", "hard", "CVC"),
    trueFalse("q12", "CVC helps beginning readers", true, "medium", "CVC"),
  ]
);

export const englishK2StoryElements: ComprehensiveLesson = createLesson(
  "english-k2-stories",
  "story-elements",
  "Story Elements: Character and Setting",
  "K-2",
  "english",
  ["Identify characters", "Recognize settings", "Understand simple plots"],
  25,
  [
    lessonSection("intro", "introduction", "Story Parts",
      "<p>Every story has important parts: <strong>characters</strong>, <strong>setting</strong>, and <strong>plot</strong></p><p>Characters are people in the story. Setting is where it happens.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Story characters", video: youtubeVideo("dQw4w9WgXcQ", "Story Elements", 120) }
    ),
    lessonSection("concept1", "concept", "Characters",
      "<p>Characters are who the story is about</p><p>Can be people, animals, or things</p><p>Have names and do things in story</p>"
    ),
    lessonSection("concept2", "concept", "Setting",
      "<p>Setting is where and when story happens</p><p>Example: 'in the forest', 'at school'</p><p>Helps us understand the story</p>"
    ),
    lessonSection("concept3", "concept", "Plot",
      "<p>Plot is what happens in story</p><p>Beginning, middle, end</p>"
    ),
    lessonSection("example", "example", "Story Example",
      "<p>Goldilocks and Three Bears:</p><p>Characters: Goldilocks, bears</p><p>Setting: house in forest</p><p>Plot: girl visits, eats, sleeps</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Characters do things in story</li><li>Setting is location</li><li>Plot is events</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Character in story is:", ["where it happens", "who is in it", "what happens"], "who is in it", "easy", "Stories"),
    trueFalse("q2", "Setting is when and where", true, "easy", "Stories"),
    multipleChoice("q3", "Plot is:", ["characters", "place", "events"], "events", "easy", "Stories"),
    shortAnswer("q4", "Who is character in Goldilocks?", "Goldilocks/bear", "easy", "Stories"),
    trueFalse("q6", "Settings help us understand story", true, "easy", "Stories"),
    shortAnswer("q7", "Where is setting of 'Three Bears'?", "Forest/house", "medium", "Stories"),
    multipleChoice("q8", "Story has:", ["characters and setting", "only plot", "only characters"], "characters and setting", "medium", "Stories"),
    freeResponse("q9", "Describe character from favorite story", "hard", "Stories"),
    trueFalse("q10", "Stories must have characters", true, "easy", "Stories"),
    freeResponse("q11", "Tell setting and characters of story", "hard", "Stories"),
    trueFalse("q12", "Setting and character are the same", false, "medium", "Stories"),
  ]
);

export const englishK2SentencesBuilding: ComprehensiveLesson = createLesson(
  "english-k2-sentences",
  "sentence-building",
  "Building Simple Sentences",
  "K-2",
  "english",
  ["Understand sentence structure", "Write simple sentences", "Use capitals and punctuation"],
  25,
  [
    lessonSection("intro", "introduction", "What is a Sentence?",
      "<p>A <strong>sentence</strong> tells a complete idea.</p><p>Sentences start with a capital letter and end with a period.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Sentence examples", video: youtubeVideo("dQw4w9WgXcQ", "Sentences", 120) }
    ),
    lessonSection("concept1", "concept", "Parts of Sentence",
      "<p><strong>Subject:</strong> who or what (the cat)</p><p><strong>Verb:</strong> action word (runs, jumps)</p><p><strong>Simple sentence:</strong> subject + verb</p>"
    ),
    lessonSection("concept2", "concept", "Capitalization and Punctuation",
      "<p>Start with capital letter</p><p>End with period (.)</p><p>Make clear complete thought</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>'The cat runs.' (subject: cat, verb: runs)</p><p>'I like apples.' (subject: I, verb: like)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Sentence has subject and verb</li><li>Starts with capital, ends with period</li><li>Tells complete idea</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Sentence must have:", ["subject", "verb", "both"], "both", "easy", "Grammar"),
    trueFalse("q2", "Sentences start with capital letter", true, "easy", "Grammar"),
    multipleChoice("q3", "End punctuation is:", ["period", "comma", "question"], "period", "easy", "Grammar"),
    shortAnswer("q4", "Subject of 'Dog runs' is", "Dog", "easy", "Grammar"),
    trueFalse("q6", "Verb is action word", true, "easy", "Grammar"),
    shortAnswer("q7", "Verb in 'Cat sits' is", "sits", "medium", "Grammar"),
    multipleChoice("q8", "Capitalization means:", ["big letters", "first letter big", "all letters big"], "first letter big", "medium", "Grammar"),
    freeResponse("q9", "Write a complete sentence", "hard", "Grammar"),
    trueFalse("q10", "Questions use periods", false, "easy", "Grammar"),
    freeResponse("q11", "Write sentence with subject and verb", "hard", "Grammar"),
    trueFalse("q12", "All sentences need punctuation", true, "medium", "Grammar"),
  ]
);

// ============================================================================
// ENGLISH 3-5 (GRADES 3 TO 5)
// ============================================================================

export const english35Reading: ComprehensiveLesson = createLesson(
  "english-3-5-reading",
  "reading-comprehension",
  "Reading Comprehension",
  "3-5",
  "english",
  ["Understand main idea", "Remember details", "Answer comprehension questions"],
  30,
  [
    lessonSection("intro", "introduction", "Understanding What You Read",
      "<p>Reading comprehension means understanding the story or text.</p><p>Look for: main idea, characters, events, and details</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Reading books", video: youtubeVideo("dQw4w9WgXcQ", "Comprehension", 120) }
    ),
    lessonSection("concept1", "concept", "Main Idea",
      "<p>Main idea is the most important point</p><p>What is the story mostly about?</p>"
    ),
    lessonSection("concept2", "concept", "Details",
      "<p>Details support the main idea</p><p>Small facts that add information</p>"
    ),
    lessonSection("concept3", "concept", "Questions",
      "<p>Ask: Who? What? When? Where? Why? How?</p><p>Helps understand better</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>'The sun was bright. The cat slept under a tree.'</p><p>Main idea: cat resting. Details: sunny day, tree</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Find main idea of text</li><li>Notice important details</li><li>Ask questions while reading</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Main idea is:", ["small fact", "most important point", "character name"], "most important point", "easy", "Comprehension"),
    trueFalse("q2", "Details support main idea", true, "easy", "Comprehension"),
    multipleChoice("q3", "Good question to ask:", ["Who?", "What?", "both"], "both", "easy", "Comprehension"),
    shortAnswer("q4", "Main idea = ___ important point", "most", "easy", "Comprehension"),
    trueFalse("q6", "Details are important for understanding", true, "easy", "Comprehension"),
    shortAnswer("q7", "Name one question word", "Who/What/Where", "medium", "Comprehension"),
    multipleChoice("q8", "When answers:", ["Who did it", "what happened", "when it happened"], "when it happened", "medium", "Comprehension"),
    freeResponse("q9", "Read text, identify main idea", "hard", "Comprehension"),
    trueFalse("q10", "All details are main idea", false, "easy", "Comprehension"),
    freeResponse("q11", "List important details from story", "hard", "Comprehension"),
    trueFalse("q12", "Question words help comprehension", true, "medium", "Comprehension"),
  ]
);

export const english35Grammar: ComprehensiveLesson = createLesson(
  "english-3-5-grammar",
  "parts-of-speech",
  "Parts of Speech",
  "3-5",
  "english",
  ["Identify nouns, verbs, adjectives", "Use parts of speech correctly", "Write better sentences"],
  30,
  [
    lessonSection("intro", "introduction", "Parts of Speech",
      "<p>Words have different jobs in sentences.</p><p>Main types: noun, verb, adjective, adverb</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Grammar examples", video: youtubeVideo("dQw4w9WgXcQ", "Grammar", 120) }
    ),
    lessonSection("concept1", "concept", "Noun and Verb",
      "<p><strong>Noun:</strong> person, place, or thing (cat, school, book)</p><p><strong>Verb:</strong> action word (run, jump, read)</p>"
    ),
    lessonSection("concept2", "concept", "Adjective and Adverb",
      "<p><strong>Adjective:</strong> describes noun (big, red, happy)</p><p><strong>Adverb:</strong> describes verb (quickly, slowly, happily)</p>"
    ),
    lessonSection("concept3", "concept", "More Parts",
      "<p><strong>Pronoun:</strong> replaces noun (he, she, it, they)</p><p><strong>Preposition:</strong> shows location (in, on, under)</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>'The big dog runs quickly.' (adjective, noun, verb, adverb)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Each word has a job</li><li>Noun = thing, Verb = action</li><li>Adjective describes, Adverb modifies verb</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Noun is:", ["action", "person/place/thing", "describing word"], "person/place/thing", "easy", "Grammar"),
    trueFalse("q2", "Verb is action word", true, "easy", "Grammar"),
    multipleChoice("q3", "'Happy' is:", ["noun", "verb", "adjective"], "adjective", "easy", "Grammar"),
    shortAnswer("q4", "Noun in 'cat runs' is", "cat", "easy", "Grammar"),
    trueFalse("q6", "Adverb describes noun", false, "easy", "Grammar"),
    shortAnswer("q7", "Verb in 'I play games' is", "play", "medium", "Grammar"),
    multipleChoice("q8", "Adjective describes:", ["noun", "verb", "sentence"], "noun", "medium", "Grammar"),
    freeResponse("q9", "Identify parts of speech in sentence", "hard", "Grammar"),
    trueFalse("q10", "Pronoun replaces noun", true, "easy", "Grammar"),
    freeResponse("q11", "Write sentence with different parts", "hard", "Grammar"),
    trueFalse("q12", "Preposition shows location", true, "medium", "Grammar"),
  ]
);

export const english35WritingParagraphs: ComprehensiveLesson = createLesson(
  "english-3-5-paragraphs",
  "writing-paragraphs",
  "Writing Paragraphs",
  "3-5",
  "english",
  ["Write topic sentences", "Develop supporting sentences", "Write concluding sentences"],
  30,
  [
    lessonSection("intro", "introduction", "Paragraph Structure",
      "<p>A paragraph is a group of sentences about one idea.</p><p>Has three parts: beginning, middle, end</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Paragraph structure", video: youtubeVideo("dQw4w9WgXcQ", "Paragraphs", 120) }
    ),
    lessonSection("concept1", "concept", "Topic Sentence",
      "<p>First sentence tells main idea</p><p>Introduces what paragraph is about</p>"
    ),
    lessonSection("concept2", "concept", "Supporting Sentences",
      "<p>Middle sentences add details</p><p>Explain and support main idea</p><p>Usually 2-3 sentences</p>"
    ),
    lessonSection("concept3", "concept", "Concluding Sentence",
      "<p>Last sentence restates main idea</p><p>Wraps up the paragraph</p>"
    ),
    lessonSection("example", "example", "Example Paragraph",
      "<p>'My favorite sport is soccer. I like running and kicking the ball. Soccer helps me stay healthy. Soccer is the best sport for me.'</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Paragraph = group of sentences</li><li>Topic sentence introduces idea</li><li>Support with details, conclude with summary</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Paragraph is:", ["one sentence", "group of sentences", "chapter"], "group of sentences", "easy", "Writing"),
    trueFalse("q2", "Topic sentence comes first", true, "easy", "Writing"),
    multipleChoice("q3", "Supporting sentences:", ["introduce topic", "add details", "end paragraph"], "add details", "easy", "Writing"),
    shortAnswer("q4", "Concluding sentence ___ main idea", "restates", "easy", "Writing"),
    trueFalse("q6", "All sentences in paragraph same idea", true, "easy", "Writing"),
    shortAnswer("q7", "How many supporting sentences? (typical)", "2-3", "medium", "Writing"),
    multipleChoice("q8", "Last sentence purpose:", ["introduce", "conclude", "question"], "conclude", "medium", "Writing"),
    freeResponse("q9", "Write a paragraph about topic", "hard", "Writing"),
    trueFalse("q10", "Paragraph needs main idea", true, "easy", "Writing"),
    freeResponse("q11", "Write paragraph with topic, support, conclusion", "hard", "Writing"),
    trueFalse("q12", "Supporting sentences explain topic", true, "medium", "Writing"),
  ]
);

export const english35Punctuation: ComprehensiveLesson = createLesson(
  "english-3-5-punctuation",
  "punctuation-marks",
  "Punctuation and Capitalization",
  "3-5",
  "english",
  ["Use periods, questions marks, exclamations", "Capitalize properly", "Punctuate dialogue"],
  30,
  [
    lessonSection("intro", "introduction", "Punctuation Matters",
      "<p>Punctuation marks tell readers how to read.</p><p>Period (.), question mark (?), exclamation (!), comma (,)</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Punctuation marks", video: youtubeVideo("dQw4w9WgXcQ", "Punctuation", 120) }
    ),
    lessonSection("concept1", "concept", "End Punctuation",
      "<p><strong>Period (.):</strong> ends statement</p><p><strong>Question mark (?):</strong> ends question</p><p><strong>Exclamation (!):</strong> shows excitement or strong feeling</p>"
    ),
    lessonSection("concept2", "concept", "Capitalization",
      "<p>Capital letters for: first word, proper nouns, 'I'</p><p>Names, places, days: Apple, Paris, Monday</p>"
    ),
    lessonSection("concept3", "concept", "Comma",
      "<p>Separates items in list: apples, oranges, and grapes</p><p>Separates clauses in sentence</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>'Is that your dog?' (question)</p><p>'What a surprise!' (exclamation)</p><p>'I like cats and dogs.' (comma in list)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Period, question mark, exclamation end sentences</li><li>Capitalize proper nouns and sentence start</li><li>Comma separates items</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Question mark ends:", ["statement", "question", "list"], "question", "easy", "Punctuation"),
    trueFalse("q2", "Exclamation shows excitement", true, "easy", "Punctuation"),
    multipleChoice("q3", "Capitalize:", ["all words", "first word", "nouns only"], "first word", "easy", "Punctuation"),
    shortAnswer("q4", "Paris is ___ed (proper noun)", "Capital", "easy", "Punctuation"),
    trueFalse("q6", "I is always capitalized", true, "easy", "Punctuation"),
    shortAnswer("q7", "Comma separates items in ___", "list", "medium", "Punctuation"),
    multipleChoice("q8", "End punctuation: '.', '?', '!':", ["yes", "no"], "yes", "medium", "Punctuation"),
    freeResponse("q9", "Punctuate sentence correctly", "hard", "Punctuation"),
    trueFalse("q10", "All sentences end with period", false, "easy", "Punctuation"),
    freeResponse("q11", "Write sentence with proper punctuation", "hard", "Punctuation"),
    trueFalse("q12", "Proper nouns need capitals", true, "medium", "Punctuation"),
  ]
);

// ============================================================================
// ENGLISH 6-8 (GRADES 6 TO 8)
// ============================================================================

export const english68EssayStructure: ComprehensiveLesson = createLesson(
  "english-6-8-essays",
  "essay-writing",
  "Essay Structure and Organization",
  "6-8",
  "english",
  ["Understand essay parts", "Write thesis statement", "Organize ideas logically"],
  40,
  [
    lessonSection("intro", "introduction", "What is an Essay?",
      "<p>An essay is organized writing with introduction, body, and conclusion.</p><p>Essays support a main idea with evidence and examples</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Essay structure", video: youtubeVideo("dQw4w9WgXcQ", "Essays", 150) }
    ),
    lessonSection("concept1", "concept", "Introduction",
      "<p>Hook: interesting opening sentence</p><p>Background: context information</p><p>Thesis: main argument of essay</p>"
    ),
    lessonSection("concept2", "concept", "Body Paragraphs",
      "<p>Each paragraph: topic sentence + supporting details</p><p>Usually 3-5 paragraphs</p><p>Each develops thesis with evidence</p>"
    ),
    lessonSection("concept3", "concept", "Conclusion",
      "<p>Restate thesis in new way</p><p>Summarize main points</p><p>Final thought for reader</p>"
    ),
    lessonSection("example", "example", "Example Structure",
      "<p>Intro → Thesis</p><p>Body Para 1 → Topic + Details</p><p>Body Para 2 → Topic + Details</p><p>Conclusion → Restate Thesis</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Essay has intro, body, conclusion</li><li>Thesis is main argument</li><li>Body paragraphs support thesis</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Essay has:", ["intro, body, conclusion", "intro only", "conclusion only"], "intro, body, conclusion", "easy", "Essays"),
    trueFalse("q2", "Thesis is main argument", true, "easy", "Essays"),
    multipleChoice("q3", "Hook is:", ["introduction sentence", "body paragraph", "conclusion"], "introduction sentence", "easy", "Essays"),
    shortAnswer("q4", "How many body paragraphs? (typical)", "3-5", "easy", "Essays"),
    trueFalse("q6", "Each body paragraph has topic sentence", true, "easy", "Essays"),
    shortAnswer("q7", "Conclusion ___ thesis", "restates", "medium", "Essays"),
    multipleChoice("q8", "Evidence supports:", ["hook", "thesis", "title"], "thesis", "medium", "Essays"),
    freeResponse("q9", "Outline 5-paragraph essay", "hard", "Essays"),
    trueFalse("q10", "All paragraphs develop thesis", true, "easy", "Essays"),
    freeResponse("q11", "Write thesis statement for essay", "hard", "Essays"),
    trueFalse("q12", "Organization helps readers understand", true, "medium", "Essays"),
  ]
);

export const english68FigurativeLanguage: ComprehensiveLesson = createLesson(
  "english-6-8-figurative",
  "figurative-language",
  "Figurative Language: Similes, Metaphors, Idioms",
  "6-8",
  "english",
  ["Understand simile and metaphor", "Recognize idioms", "Use figurative language in writing"],
  40,
  [
    lessonSection("intro", "introduction", "Beyond Literal Meaning",
      "<p>Figurative language uses words creatively for effect.</p><p>It doesn't mean exactly what it says</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Figurative language examples", video: youtubeVideo("dQw4w9WgXcQ", "Figurative", 150) }
    ),
    lessonSection("concept1", "concept", "Simile and Metaphor",
      "<p><strong>Simile:</strong> comparison using 'like' or 'as' (light as feather)</p><p><strong>Metaphor:</strong> comparison without 'like' (world is stage)</p>"
    ),
    lessonSection("concept2", "concept", "Personification and Hyperbole",
      "<p><strong>Personification:</strong> giving human qualities to things (trees dance)</p><p><strong>Hyperbole:</strong> exaggeration (I've told you a million times)</p>"
    ),
    lessonSection("concept3", "concept", "Idioms",
      "<p>Phrases with special meaning (raining cats and dogs, piece of cake)</p><p>Meaning not from individual words</p>"
    ),
    lessonSection("example", "example", "Examples",
      "<p>'She is quick as a cheetah.' (simile)</p><p>'Time is money.' (metaphor)</p><p>'The wind howled.' (personification)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Figurative ≠ literal meaning</li><li>Creates images and emotion</li><li>Makes writing interesting</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Simile uses:", ["like", "as if", "both"], "both", "easy", "Literature"),
    trueFalse("q2", "Metaphor uses 'like'", false, "easy", "Literature"),
    multipleChoice("q3", "'Trees dance' is:", ["simile", "personification", "hyperbole"], "personification", "easy", "Literature"),
    shortAnswer("q4", "Idiom 'raining cats and dogs' means:", "Heavy rain", "easy", "Literature"),
    trueFalse("q6", "Figurative language is creative", true, "easy", "Literature"),
    shortAnswer("q7", "Hyperbole is exaggeration or truth?", "Exaggeration", "medium", "Literature"),
    multipleChoice("q8", "Idioms have:", ["literal meaning", "special meaning", "no meaning"], "special meaning", "medium", "Literature"),
    freeResponse("q9", "Create simile or metaphor", "hard", "Literature"),
    trueFalse("q10", "All figurative language is metaphor", false, "easy", "Literature"),
    freeResponse("q11", "Identify figurative language in text", "hard", "Literature"),
    trueFalse("q12", "Figurative language makes writing vivid", true, "medium", "Literature"),
  ]
);

export const english68ThemeAnalysis: ComprehensiveLesson = createLesson(
  "english-6-8-theme",
  "theme-analysis",
  "Theme: What Stories Teach Us",
  "6-8",
  "english",
  ["Identify themes in stories", "Support theme with evidence", "Understand universal themes"],
  40,
  [
    lessonSection("intro", "introduction", "What is Theme?",
      "<p><strong>Theme</strong> is the message or lesson in a story.</p><p>Not the plot—the idea behind the plot</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Story themes", video: youtubeVideo("dQw4w9WgXcQ", "Theme", 150) }
    ),
    lessonSection("concept1", "concept", "Common Themes",
      "<p>Good vs evil, friendship, courage, family</p><p>Growing up, overcoming obstacles, change</p>"
    ),
    lessonSection("concept2", "concept", "Finding Theme",
      "<p>Look at: character changes, repeated ideas, title meaning</p><p>What does author want you to learn?</p>"
    ),
    lessonSection("concept3", "concept", "Supporting with Evidence",
      "<p>Use examples from story to prove theme</p><p>Quote specific scenes or dialogue</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>In Lion King, theme: responsibility and growing up</p><p>Evidence: Simba avoids duty, learns to face challenges</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Theme = lesson or message</li><li>Found through character and plot</li><li>Support with evidence from text</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Theme is:", ["plot", "message/lesson", "character name"], "message/lesson", "easy", "Literature"),
    trueFalse("q2", "Theme is what story teaches", true, "easy", "Literature"),
    multipleChoice("q3", "Common theme:", ["courage", "friendship", "both"], "both", "easy", "Literature"),
    shortAnswer("q4", "To find theme, look at character ___", "changes", "easy", "Literature"),
    trueFalse("q6", "Title can reveal theme", true, "easy", "Literature"),
    shortAnswer("q7", "Support theme with ___ from story", "evidence", "medium", "Literature"),
    multipleChoice("q8", "Good evidence is:", ["opinion", "plot details", "guessing"], "plot details", "medium", "Literature"),
    freeResponse("q9", "Identify theme in story you know", "hard", "Literature"),
    trueFalse("q10", "Every story has one theme", false, "easy", "Literature"),
    freeResponse("q11", "Support theme with story evidence", "hard", "Literature"),
    trueFalse("q12", "Theme same as moral", false, "medium", "Literature"),
  ]
);

export const english68WritingProcess: ComprehensiveLesson = createLesson(
  "english-6-8-writing",
  "writing-process",
  "The Writing Process",
  "6-8",
  "english",
  ["Use prewriting strategies", "Draft and revise", "Edit and publish"],
  40,
  [
    lessonSection("intro", "introduction", "Writing Has Steps",
      "<p>Good writing follows a process with stages</p><p>Brainstorm → Draft → Revise → Edit → Publish</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Writing steps", video: youtubeVideo("dQw4w9WgXcQ", "Writing Process", 150) }
    ),
    lessonSection("concept1", "concept", "Prewriting",
      "<p>Brainstorm: list ideas, mind map, freewrite</p><p>Plan: outline main points</p><p>Research: gather information</p>"
    ),
    lessonSection("concept2", "concept", "Drafting and Revising",
      "<p>Draft: write first version, don't worry about perfection</p><p>Revise: reorder, add details, improve clarity</p>"
    ),
    lessonSection("concept3", "concept", "Editing and Publishing",
      "<p>Edit: fix grammar, spelling, punctuation</p><p>Publish: share final version</p>"
    ),
    lessonSection("example", "example", "Process Example",
      "<p>1. Brainstorm: school life ideas</p><p>2. Draft: write about first day</p><p>3. Revise: add more feelings</p><p>4. Edit: correct errors</p><p>5. Publish: share with class</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Writing has stages</li><li>Brainstorm before drafting</li><li>Revise for content, edit for mechanics</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "First stage:", ["brainstorm", "edit", "publish"], "brainstorm", "easy", "Writing"),
    trueFalse("q2", "Revise means fix grammar", false, "easy", "Writing"),
    multipleChoice("q3", "Edit focuses on:", ["ideas", "grammar/spelling", "organization"], "grammar/spelling", "easy", "Writing"),
    shortAnswer("q4", "Brainstorm means ___ ideas", "list", "easy", "Writing"),
    trueFalse("q6", "First draft is final", false, "easy", "Writing"),
    shortAnswer("q7", "Revision improves ___ and clarity", "ideas", "medium", "Writing"),
    multipleChoice("q8", "Publishing means:", ["sharing", "editing", "brainstorming"], "sharing", "medium", "Writing"),
    freeResponse("q9", "Outline writing process for essay", "hard", "Writing"),
    trueFalse("q10", "All writers use process", true, "easy", "Writing"),
    freeResponse("q11", "Describe revising vs editing", "hard", "Writing"),
    trueFalse("q12", "Feedback helps in revising stage", true, "medium", "Writing"),
  ]
);

// ============================================================================
// ENGLISH 9-10 (GRADES 9 TO 10)
// ============================================================================

export const english910LiteraryDevices: ComprehensiveLesson = createLesson(
  "english-9-10-devices",
  "literary-devices",
  "Literary Devices: Symbolism and Imagery",
  "9-10",
  "english",
  ["Understand symbolism in literature", "Analyze imagery and mood", "Connect to themes"],
  45,
  [
    lessonSection("intro", "introduction", "Advanced Literary Techniques",
      "<p>Symbols and imagery create meaning beyond words</p><p>They connect to theme and emotion</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Literary analysis", video: youtubeVideo("dQw4w9WgXcQ", "Literary Devices", 200) }
    ),
    lessonSection("concept1", "concept", "Symbolism",
      "<p>Symbol: something represents something else</p><p>Example: dove = peace, darkness = evil</p><p>Author chooses symbols to enhance theme</p>"
    ),
    lessonSection("concept2", "concept", "Imagery",
      "<p>Imagery: sensory details (sight, sound, smell, taste, touch)</p><p>Creates vivid pictures in reader's mind</p><p>Appeals to senses to evoke emotion</p>"
    ),
    lessonSection("concept3", "concept", "Mood and Tone",
      "<p><strong>Mood:</strong> feeling created in reader (happy, tense, sad)</p><p><strong>Tone:</strong> author's attitude (sarcastic, serious)</p>"
    ),
    lessonSection("example", "example", "Example Analysis",
      "<p>'The darkness crept through the woods.' (imagery: darkness, mood: fear)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Symbols represent bigger ideas</li><li>Imagery engages senses</li><li>Creates mood and emotion</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Symbol represents:", ["itself", "something else", "the author"], "something else", "easy", "Literature"),
    trueFalse("q2", "Imagery appeals to senses", true, "easy", "Literature"),
    multipleChoice("q3", "Mood is:", ["emotion in reader", "author's attitude", "plot"], "emotion in reader", "easy", "Literature"),
    shortAnswer("q4", "Dove symbolizes ___", "peace", "easy", "Literature"),
    trueFalse("q6", "Imagery makes writing vivid", true, "easy", "Literature"),
    shortAnswer("q7", "Tone shows author's ___", "attitude", "medium", "Literature"),
    multipleChoice("q8", "Visual imagery appeals to:", ["sight", "hearing", "touch"], "sight", "medium", "Literature"),
    freeResponse("q9", "Identify symbol and its meaning", "hard", "Literature"),
    trueFalse("q10", "All details are imagery", false, "easy", "Literature"),
    freeResponse("q11", "Analyze mood created by passage", "hard", "Literature"),
    trueFalse("q12", "Symbols help develop theme", true, "medium", "Literature"),
  ]
);

export const english910CriticalReading: ComprehensiveLesson = createLesson(
  "english-9-10-critical",
  "critical-reading",
  "Critical Reading and Analysis",
  "9-10",
  "english",
  ["Evaluate author's purpose", "Analyze bias and perspective", "Question credibility"],
  45,
  [
    lessonSection("intro", "introduction", "Reading Critically",
      "<p>Critical reading means questioning text</p><p>Ask: Why did author write this? What's the purpose? Is it credible?</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Critical analysis", video: youtubeVideo("dQw4w9WgXcQ", "Critical Reading", 200) }
    ),
    lessonSection("concept1", "concept", "Author's Purpose",
      "<p><strong>Inform:</strong> provide information</p><p><strong>Persuade:</strong> convince reader</p><p><strong>Entertain:</strong> tell story</p>"
    ),
    lessonSection("concept2", "concept", "Bias and Perspective",
      "<p>Bias: author's prejudice or preference</p><p>Perspective: author's viewpoint based on experience</p><p>Affects how story is told</p>"
    ),
    lessonSection("concept3", "concept", "Credibility and Evidence",
      "<p>Check sources: are they reliable?</p><p>Look for facts vs opinions</p><p>Consider author's expertise</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>News article about school: Is it reporting facts or editorializing? Who wrote it? What's their background?</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Question author's purpose</li><li>Identify bias and perspective</li><li>Evaluate credibility of sources</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Author's purpose:", ["inform", "persuade", "all"], "all", "easy", "Reading"),
    trueFalse("q2", "Bias affects writing", true, "easy", "Reading"),
    multipleChoice("q3", "Perspective comes from:", ["experience", "opinion", "facts"], "experience", "easy", "Reading"),
    shortAnswer("q4", "Facts are ___ statements", "true", "easy", "Reading"),
    trueFalse("q6", "All sources are credible", false, "easy", "Reading"),
    shortAnswer("q7", "Opinions are ___ based", "belief", "medium", "Reading"),
    multipleChoice("q8", "Evaluate credibility by:", ["source", "author expertise", "both"], "both", "medium", "Reading"),
    freeResponse("q9", "Analyze author's purpose in text", "hard", "Reading"),
    trueFalse("q10", "Every source has some bias", true, "easy", "Reading"),
    freeResponse("q11", "Identify bias in article", "hard", "Reading"),
    trueFalse("q12", "Critical reading makes you smarter", true, "medium", "Reading"),
  ]
);

export const english910ResearchWriting: ComprehensiveLesson = createLesson(
  "english-9-10-research",
  "research-writing",
  "Research and Citing Sources",
  "9-10",
  "english",
  ["Find reliable sources", "Evaluate information", "Use proper citations"],
  45,
  [
    lessonSection("intro", "introduction", "Research Writing",
      "<p>Research writing combines your ideas with credible sources</p><p>Proper citation gives credit to sources</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Research process", video: youtubeVideo("dQw4w9WgXcQ", "Research", 200) }
    ),
    lessonSection("concept1", "concept", "Finding Sources",
      "<p>Library databases, academic journals, expert websites</p><p>Evaluate: author, date, authority, purpose</p>"
    ),
    lessonSection("concept2", "concept", "Evaluating Information",
      "<p><strong>CRAAP:</strong> Currency, Reliability, Authority, Accuracy, Purpose</p><p>Check multiple sources for agreement</p>"
    ),
    lessonSection("concept3", "concept", "Citation Styles",
      "<p><strong>MLA:</strong> common in English</p><p><strong>APA:</strong> social sciences</p><p><strong>Chicago:</strong> history</p><p>Always cite: direct quotes, paraphrases, facts</p>"
    ),
    lessonSection("example", "example", "Citation Example",
      "<p>MLA: (Author Page). APA: (Author, Year). Chicago: Author, Date.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Use credible, current sources</li><li>Evaluate information quality</li><li>Cite all sources properly</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Credible sources include:", ["blogs", "academic journals", "both"], "academic journals", "easy", "Research"),
    trueFalse("q2", "Citation gives credit to sources", true, "easy", "Research"),
    multipleChoice("q3", "CRAAP stands for:", ["Currency, Reliability...", "Crazy Rating...", "none"], "Currency, Reliability...", "easy", "Research"),
    shortAnswer("q4", "Always cite: quotes and ___", "paraphrases/facts", "easy", "Research"),
    trueFalse("q6", "Wikipedia is always reliable", false, "easy", "Research"),
    shortAnswer("q7", "MLA and APA are ___ styles", "citation", "medium", "Research"),
    multipleChoice("q8", "Current means:", ["recent", "old", "popular"], "recent", "medium", "Research"),
    freeResponse("q9", "Evaluate source credibility", "hard", "Research"),
    trueFalse("q10", "Paraphrasing doesn't need citation", false, "easy", "Research"),
    freeResponse("q11", "Create proper citation for source", "hard", "Research"),
    trueFalse("q12", "Good research uses multiple sources", true, "medium", "Research"),
  ]
);

export const english910ArgumentPersuasion: ComprehensiveLesson = createLesson(
  "english-9-10-argument",
  "argument-persuasion",
  "Argument and Persuasion",
  "9-10",
  "english",
  ["Construct valid arguments", "Use evidence and reasoning", "Recognize logical fallacies"],
  45,
  [
    lessonSection("intro", "introduction", "Making Arguments",
      "<p>Persuasive writing uses logic and evidence to convince</p><p>Strong argument: clear claim + solid evidence + sound reasoning</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Debate", video: youtubeVideo("dQw4w9WgXcQ", "Persuasion", 200) }
    ),
    lessonSection("concept1", "concept", "Argument Structure",
      "<p><strong>Claim:</strong> what you argue is true</p><p><strong>Evidence:</strong> facts, examples supporting claim</p><p><strong>Reasoning:</strong> explain why evidence supports claim</p>"
    ),
    lessonSection("concept2", "concept", "Types of Evidence",
      "<p>Statistics, expert opinions, examples, research</p><p>Must be relevant and credible</p>"
    ),
    lessonSection("concept3", "concept", "Logical Fallacies",
      "<p><strong>Ad hominem:</strong> attack person, not argument</p><p><strong>Bandwagon:</strong> 'everyone believes this'</p><p><strong>Straw man:</strong> oversimplify opponent's view</p>"
    ),
    lessonSection("example", "example", "Example Argument",
      "<p>Claim: Schools need longer lunch periods</p><p>Evidence: Studies show students need 45 minutes</p><p>Reasoning: More time = better nutrition, less stress</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Strong claim with solid evidence</li><li>Logical reasoning connects them</li><li>Avoid logical fallacies</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Argument needs:", ["claim", "evidence", "both"], "both", "easy", "Writing"),
    trueFalse("q2", "Evidence supports claim", true, "easy", "Writing"),
    multipleChoice("q3", "Ad hominem attacks:", ["argument", "person", "logic"], "person", "easy", "Writing"),
    shortAnswer("q4", "Bandwagon fallacy: ___ does this", "everyone", "easy", "Writing"),
    trueFalse("q6", "Statistics are evidence", true, "easy", "Writing"),
    shortAnswer("q7", "Reasoning ___ why evidence works", "explains", "medium", "Writing"),
    multipleChoice("q8", "Straw man oversimplifies:", ["your view", "opponent's view", "facts"], "opponent's view", "medium", "Writing"),
    freeResponse("q9", "Construct argument with evidence", "hard", "Writing"),
    trueFalse("q10", "Emotions are good evidence", false, "easy", "Writing"),
    freeResponse("q11", "Identify fallacy in argument", "hard", "Writing"),
    trueFalse("q12", "Counterarguments strengthen position", true, "medium", "Writing"),
  ]
);

export const english910Poetry: ComprehensiveLesson = createLesson(
  "english-9-10-poetry",
  "poetry-analysis",
  "Poetry: Form and Analysis",
  "9-10",
  "english",
  ["Understand poetic devices", "Analyze verse forms", "Interpret poems"],
  45,
  [
    lessonSection("intro", "introduction", "Poetry's Power",
      "<p>Poetry uses language creatively with sound and meaning</p><p>Devices: rhyme, meter, alliteration, etc.</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Poetry book", video: youtubeVideo("dQw4w9WgXcQ", "Poetry", 200) }
    ),
    lessonSection("concept1", "concept", "Sound Devices",
      "<p><strong>Rhyme:</strong> matching end sounds (cat/bat)</p><p><strong>Meter:</strong> rhythm pattern</p><p><strong>Alliteration:</strong> repeated consonant sounds</p>"
    ),
    lessonSection("concept2", "concept", "Poetic Forms",
      "<p><strong>Sonnet:</strong> 14 lines, specific rhyme scheme</p><p><strong>Haiku:</strong> 3 lines, 5-7-5 syllables</p><p><strong>Free verse:</strong> no set form or rhyme</p>"
    ),
    lessonSection("concept3", "concept", "Analysis",
      "<p>Look at: word choice, imagery, tone, meaning</p><p>How do devices support theme?</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>'The cat sat silent in the house.' (alliteration: s)</p><p>Haiku: 5-7-5 syllable poem about nature</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Poetry uses special devices</li><li>Sound affects meaning</li><li>Forms have specific structures</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Rhyme is:", ["rhythm", "matching sounds", "meter"], "matching sounds", "easy", "Poetry"),
    trueFalse("q2", "Alliteration repeats consonant sounds", true, "easy", "Poetry"),
    multipleChoice("q3", "Haiku has:", ["14 lines", "3 lines", "no form"], "3 lines", "easy", "Poetry"),
    shortAnswer("q4", "Sonnet has ___ lines", "14", "easy", "Poetry"),
    trueFalse("q6", "Free verse has no rhyme or meter", true, "easy", "Poetry"),
    shortAnswer("q7", "Meter is rhythm ___", "pattern", "medium", "Poetry"),
    multipleChoice("q8", "Haiku syllables:", ["5-7-5", "10-8-6", "any"], "5-7-5", "medium", "Poetry"),
    freeResponse("q9", "Write poem using rhyme", "hard", "Poetry"),
    trueFalse("q10", "All poems must rhyme", false, "easy", "Poetry"),
    freeResponse("q11", "Analyze poem's devices", "hard", "Poetry"),
    trueFalse("q12", "Devices create emphasis", true, "medium", "Poetry"),
  ]
);

// ============================================================================
// ENGLISH 11-12 (GRADES 11 TO 12)
// ============================================================================

export const english1112AdvancedLiterature: ComprehensiveLesson = createLesson(
  "english-11-12-literature",
  "advanced-literature",
  "Advanced Literature: Classics and Interpretation",
  "11-12",
  "english",
  ["Analyze complex texts", "Understand literary traditions", "Develop interpretations"],
  50,
  [
    lessonSection("intro", "introduction", "Literary Scholarship",
      "<p>Advanced literature explores meaning and context</p><p>Considers historical period, cultural context, author's life</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Classics", video: youtubeVideo("dQw4w9WgXcQ", "Classics", 220) }
    ),
    lessonSection("concept1", "concept", "Literary Traditions",
      "<p>Different traditions: Romanticism, Realism, Modernism</p><p>Each has values, techniques, historical context</p>"
    ),
    lessonSection("concept2", "concept", "Close Reading",
      "<p>Analyze: word choice, sentence structure, imagery, metaphor</p><p>How do these create meaning?</p>"
    ),
    lessonSection("concept3", "concept", "Interpretation",
      "<p>Develop thesis about meaning</p><p>Support with textual evidence</p><p>Consider multiple interpretations</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>Analyzing 'Great Gatsby': Fitzgerald's prose creates illusion and reality theme</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Context affects interpretation</li><li>Close reading reveals meaning</li><li>Develop supported thesis</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Close reading examines:", ["plot", "word choice", "character names"], "word choice", "easy", "Literature"),
    trueFalse("q2", "Context matters for interpretation", true, "easy", "Literature"),
    multipleChoice("q3", "Literary tradition is:", ["writing style", "historical period and values", "none"], "historical period and values", "easy", "Literature"),
    shortAnswer("q4", "Thesis is ___ interpretation", "supported", "easy", "Literature"),
    trueFalse("q6", "Evidence comes from text", true, "easy", "Literature"),
    shortAnswer("q7", "Multiple interpretations can be ___", "valid", "medium", "Literature"),
    multipleChoice("q8", "Author's life affects:", ["theme", "interpretation", "both"], "both", "medium", "Literature"),
    freeResponse("q9", "Develop literary interpretation", "hard", "Literature"),
    trueFalse("q10", "One interpretation is always correct", false, "easy", "Literature"),
    freeResponse("q11", "Analyze passage for meaning", "hard", "Literature"),
    trueFalse("q12", "Good interpretation needs evidence", true, "medium", "Literature"),
  ]
);

export const english1112RhetoricalAnalysis: ComprehensiveLesson = createLesson(
  "english-11-12-rhetorical",
  "rhetorical-analysis",
  "Rhetorical Analysis: How Writers Persuade",
  "11-12",
  "english",
  ["Understand rhetorical strategies", "Analyze persuasive techniques", "Evaluate effectiveness"],
  50,
  [
    lessonSection("intro", "introduction", "Rhetoric and Persuasion",
      "<p>Rhetoric is art of persuasion</p><p>Analyzes how writers use language to convince</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Speech analysis", video: youtubeVideo("dQw4w9WgXcQ", "Rhetoric", 220) }
    ),
    lessonSection("concept1", "concept", "Appeals",
      "<p><strong>Ethos:</strong> credibility and trust</p><p><strong>Pathos:</strong> emotional appeal</p><p><strong>Logos:</strong> logical reasoning and evidence</p>"
    ),
    lessonSection("concept2", "concept", "Rhetorical Devices",
      "<p>Repetition, parallel structure, metaphor, imagery</p><p>Each technique serves persuasive purpose</p>"
    ),
    lessonSection("concept3", "concept", "Effectiveness",
      "<p>Does rhetoric achieve purpose?</p><p>For what audience? In what context?</p><p>What techniques are most effective?</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>JFK's 'Ask not what your country can do for you'—uses parallel structure and appeals to pathos/ethos</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Ethos, pathos, logos drive persuasion</li><li>Devices support rhetorical purpose</li><li>Analyze for effectiveness</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Ethos appeals to:", ["emotion", "logic", "credibility"], "credibility", "easy", "Writing"),
    trueFalse("q2", "Pathos is emotional appeal", true, "easy", "Writing"),
    multipleChoice("q3", "Logos is:", ["logical", "emotional", "credibility"], "logical", "easy", "Writing"),
    shortAnswer("q4", "Rhetoric is art of ___", "persuasion", "easy", "Writing"),
    trueFalse("q6", "All devices serve purpose", true, "easy", "Writing"),
    shortAnswer("q7", "Repetition creates ___", "emphasis", "medium", "Writing"),
    multipleChoice("q8", "Parallel structure uses:", ["same sounds", "same patterns", "same words"], "same patterns", "medium", "Writing"),
    freeResponse("q9", "Analyze rhetorical strategies", "hard", "Writing"),
    trueFalse("q10", "Rhetoric always persuades", false, "easy", "Writing"),
    freeResponse("q11", "Evaluate effectiveness of rhetoric", "hard", "Writing"),
    trueFalse("q12", "Context affects rhetorical analysis", true, "medium", "Writing"),
  ]
);

export const english1112CreativeWriting: ComprehensiveLesson = createLesson(
  "english-11-12-creative",
  "creative-writing",
  "Creative Writing: Craft and Style",
  "11-12",
  "english",
  ["Develop unique voice", "Use advanced techniques", "Revise for effect"],
  50,
  [
    lessonSection("intro", "introduction", "Writing as Craft",
      "<p>Creative writing develops style and voice</p><p>Techniques create specific effects</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Writing craft", video: youtubeVideo("dQw4w9WgXcQ", "Creative Writing", 220) }
    ),
    lessonSection("concept1", "concept", "Voice and Style",
      "<p>Voice: unique way of writing, personality</p><p>Style: word choice, sentence structure, tone</p><p>Develop through practice and revision</p>"
    ),
    lessonSection("concept2", "concept", "Advanced Techniques",
      "<p>Pacing, foreshadowing, unreliable narrator</p><p>Point of view decisions affect meaning</p>"
    ),
    lessonSection("concept3", "concept", "Revision for Effect",
      "<p>Rewrite for impact, clarity, beauty</p><p>Consider reader experience</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>Hemingway's simple sentences create power. Faulkner's complex structure mirrors consciousness.</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Voice comes from practice</li><li>Techniques serve story</li><li>Revision refines effect</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Voice is:", ["speaking", "unique writing style", "sound"], "unique writing style", "easy", "Writing"),
    trueFalse("q2", "Style develops through practice", true, "easy", "Writing"),
    multipleChoice("q3", "Pacing controls:", ["speed", "rhythm", "both"], "both", "easy", "Writing"),
    shortAnswer("q4", "Foreshadowing hints at ___", "future", "easy", "Writing"),
    trueFalse("q6", "Point of view matters", true, "easy", "Writing"),
    shortAnswer("q7", "Unreliable narrator ___ truth", "distorts", "medium", "Writing"),
    multipleChoice("q8", "Revision improves:", ["clarity", "effect", "both"], "both", "medium", "Writing"),
    freeResponse("q9", "Write creative piece", "hard", "Writing"),
    trueFalse("q10", "First draft is best", false, "easy", "Writing"),
    freeResponse("q11", "Develop unique voice", "hard", "Writing"),
    trueFalse("q12", "Reader experience matters", true, "medium", "Writing"),
  ]
);

export const english1112AcademicWriting: ComprehensiveLesson = createLesson(
  "english-11-12-academic",
  "academic-writing",
  "Academic Writing: Scholarship and Analysis",
  "11-12",
  "english",
  ["Write academic essays", "Integrate sources", "Maintain academic tone"],
  50,
  [
    lessonSection("intro", "introduction", "Academic Discourse",
      "<p>Academic writing follows conventions and standards</p><p>Values evidence, clarity, logical structure</p>",
      { imageUrl: "/placeholder.svg", imageAlt: "Academic papers", video: youtubeVideo("dQw4w9WgXcQ", "Academic Writing", 220) }
    ),
    lessonSection("concept1", "concept", "Structure",
      "<p>Introduction with thesis, body with analysis, conclusion</p><p>Each paragraph supports argument</p>"
    ),
    lessonSection("concept2", "concept", "Source Integration",
      "<p>Quote sparingly, paraphrase often</p><p>Introduce sources with signal phrases</p><p>Explain relevance to argument</p>"
    ),
    lessonSection("concept3", "concept", "Academic Tone",
      "<p>Formal, objective, precise language</p><p>Avoid first person (usually), contractions</p><p>Sustain throughout</p>"
    ),
    lessonSection("example", "example", "Example",
      "<p>'According to Smith (2020), this effect occurs when...' (proper source introduction)</p>"
    ),
    lessonSection("summary", "summary", "Key Points",
      "<ul><li>Follow academic conventions</li><li>Integrate sources properly</li><li>Maintain formal tone</li></ul>"
    ),
  ],
  [
    multipleChoice("q1", "Academic writing values:", ["opinion", "evidence", "emotion"], "evidence", "easy", "Writing"),
    trueFalse("q2", "Use contractions in academic writing", false, "easy", "Writing"),
    multipleChoice("q3", "Tone should be:", ["casual", "formal", "creative"], "formal", "easy", "Writing"),
    shortAnswer("q4", "Signal phrase ___ source", "introduces", "easy", "Writing"),
    trueFalse("q6", "Each paragraph supports thesis", true, "easy", "Writing"),
    shortAnswer("q7", "Quote sparingly or ___", "paraphrase", "medium", "Writing"),
    multipleChoice("q8", "Academic style is:", ["objective", "subjective", "emotional"], "objective", "medium", "Writing"),
    freeResponse("q9", "Write academic paragraph", "hard", "Writing"),
    trueFalse("q10", "First person is common in academic", false, "easy", "Writing"),
    freeResponse("q11", "Integrate source into essay", "hard", "Writing"),
    trueFalse("q12", "Academic writing serves scholarship", true, "medium", "Writing"),
  ]
);

// Export all English lessons
export const allEnglishLessons = [
  englishK2Phonics,
  englishK2SightWords,
  englishK2CVC,
  englishK2StoryElements,
  englishK2SentencesBuilding,
  english35Reading,
  english35Grammar,
  english35WritingParagraphs,
  english35Punctuation,
  english68EssayStructure,
  english68FigurativeLanguage,
  english68ThemeAnalysis,
  english68WritingProcess,
  english910LiteraryDevices,
  english910CriticalReading,
  english910ResearchWriting,
  english910ArgumentPersuasion,
  english910Poetry,
  english1112AdvancedLiterature,
  english1112RhetoricalAnalysis,
  english1112CreativeWriting,
  english1112AcademicWriting,
];
